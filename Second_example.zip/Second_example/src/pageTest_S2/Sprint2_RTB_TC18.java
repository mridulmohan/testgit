package pageTest_S2;
 
     import java.io.File;
     import java.io.IOException;
     import java.util.concurrent.TimeUnit; 
     import org.openqa.selenium.WebDriver;
     import org.openqa.selenium.WebElement;
     import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.HomePage;
import pageObjects.Leads_NewCreate;
import pageObjects.LoginPage;
import pageObjects.Opportunity_NewCreate;
import pageTest.Sprint1_RTB_TC5;
import pageObjects.All_Edit_Clone;
import pageObjects.Contacts_NewCreate;

 
     public class Sprint2_RTB_TC18{
    	 
    	/* @AfterTest
    	 public void tearDown() throws Exception { 
    		 driver.close();
    	   driver.quit();
    	     }  
    	 */
         private static WebDriver driver = null;        
         
                  
    @Test(enabled=true)
       public void testcase18() {   	
    	
    	
//  Sprint-1-1	AG-131//
//Test case for verifying create and edit-Location-West//    	
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get("https://aggreko--CI2.cs82.my.salesforce.com");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click(); 
        LoginPage.txtbx_UserName(driver).sendKeys("sf.systestmanager@aggreko.trial.ci2"); 
        LoginPage.txtbx_Password(driver).sendKeys("Mercury@123");        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint2_RTB_TC18.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
        HomePage.clk_Account(driver).click();    
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint2_RTB_TC18.captureScreenShot(driver);
            
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }               
            WebElement accelement=AccountsPage.fnd_recentaccount(driver);
            System.out.println("The text "+ accelement.getAttribute("innerHTML"));             
             String accelementtext=accelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(accelementtext.contains("Recent Accounts"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint2_RTB_TC18.captureScreenShot(driver);
              
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            Account_NewCreate.typ_actname(driver).sendKeys("TC18_AC_T1");
            Select a=new Select(Account_NewCreate.sel_aggloc(driver));
            a.selectByVisibleText("Bristol UK"); 
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            Select b=new Select(Account_NewCreate.typ_acsegmnt(driver));
            b.selectByVisibleText("Transactional Customer");
            		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS); 
            Account_NewCreate.typ_acPhyst(driver).sendKeys("No72 3 Street");
            Account_NewCreate.typ_acPhycty(driver).sendKeys("Glasgow");	
            Account_NewCreate.typ_acPhystate(driver).sendKeys("Glasgow");			
            Account_NewCreate.typ_acPhyzipcode(driver).sendKeys("G1 1DT");			
            Account_NewCreate.typ_acPhyctry(driver).sendKeys("United Kingdom");				
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint2_RTB_TC18.captureScreenShot(driver);
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }    
            WebElement x=Account_NewCreate.fnd_savebtn(driver);
            x.click(); 
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint2_RTB_TC18.captureScreenShot(driver);
                     
    //Edit-Created Account//
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }  
    		WebElement actedit=All_Edit_Clone.fnd_accountdetail(driver);
    	     System.out.println("The text "+ actedit.getAttribute("innerHTML"));    	      
    	      String actedittext=actedit.getAttribute("innerHTML");    	  
    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);     	      
    	      if(actedittext.contains("Account Detail"))
    	      {
    	    	  All_Edit_Clone.fnd_editbtn(driver).click();
    	      }
    	      
    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
              Sprint2_RTB_TC18.captureScreenShot(driver);
    	       	      
    	      //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);   
    	      //Assert.assertEquals("Account Edit", driver.getTitle());//Expected-Account Edit//
    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	      
    	      Account_NewCreate.typ_actwsite(driver).sendKeys("www.mmkample.com");
    	      Account_NewCreate.typ_actprimphno(driver).sendKeys("3454883453");
    	      //Account_NewCreate.sel_aggloc(driver).sendKeys("London UK");
    	      //Account_NewCreate.sel_actst(driver).sendKeys("Active");
    	      //Click for drop down to be added here//
    	      //Account_NewCreate.sel_actaic(driver).sendKeys("1109");
    	      
    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
              Sprint2_RTB_TC18.captureScreenShot(driver);
    	          
    	      try {
                  //System.out.println("Thread Sleep: " + getName());
                  Thread.sleep(3000);
              } catch (InterruptedException ex) { }   
              WebElement y=Account_NewCreate.fnd_savebtn(driver);
              y.click();
              
              try {
                  //System.out.println("Thread Sleep: " + getName());
                  Thread.sleep(5000);
              } catch (InterruptedException ex) { }  
              Sprint2_RTB_TC18.captureScreenShot(driver);
              
              System.out.println("Account validation successful"); 
              
              
//---------------------------------------------------------------------------------------------------------//
//Contact creation and edit//              
              
              try {
                  //System.out.println("Thread Sleep: " + getName());
                  Thread.sleep(5000);
              } catch (InterruptedException ex) { }  
                  HomePage.clk_Contacts(driver).click();
                  
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                  Sprint2_RTB_TC18.captureScreenShot(driver);
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  WebElement conelement=AccountsPage.fnd_recentcontact(driver);
                  System.out.println("The text "+ conelement.getAttribute("innerHTML"));             
                   String conelementtext=conelement.getAttribute("innerHTML");         
                   driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
                   if(conelementtext.contains("Recent Contacts"))
                   {
                  	AccountsPage.clk_nwbtn(driver).click();
                   }
                  
                   driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                   Sprint2_RTB_TC18.captureScreenShot(driver);
                   driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);           
                  
                  Contacts_NewCreate.clk_cntfnamedrpdwn(driver).sendKeys("Mr");
                  Contacts_NewCreate.typ_cntfname(driver).sendKeys("131_CONT");
                  Contacts_NewCreate.typ_cntlname(driver).sendKeys("131_CONT");
                  Contacts_NewCreate.typ_cntaccno(driver).sendKeys("TC18_AC_T1"); 
                  Contacts_NewCreate.typ_cntphno(driver).sendKeys("7282820646");
                  Contacts_NewCreate.typ_cntemail(driver).sendKeys("contactautomat32ion@aggmail.com");
                  Select c=new Select(Contacts_NewCreate.sel_cntseg(driver));
                  c.selectByVisibleText("Transactional Customer");
                  
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                  Sprint2_RTB_TC18.captureScreenShot(driver);
                  
                  Contacts_NewCreate.typ_cntmailstreet(driver).sendKeys("3 Alexandra Parade");
                  Contacts_NewCreate.typ_cntmailcty(driver).sendKeys("Glasgow");
                  Contacts_NewCreate.typ_cntmailstate(driver).sendKeys("Scotland");
                  Contacts_NewCreate.typ_cntmailpcode(driver).sendKeys("G4 R4S");
                  Contacts_NewCreate.typ_cntmailctry(driver).sendKeys("United Kingdom");
                  
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                  Sprint2_RTB_TC18.captureScreenShot(driver);     
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { }    
                  WebElement x1=Account_NewCreate.fnd_savebtn(driver);
                  x1.click(); 
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }   
                  Sprint2_RTB_TC18.captureScreenShot(driver); 
              
    //Edit-Contact
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }  
                  WebElement conedit=All_Edit_Clone.fnd_contactdetail(driver);
         	     System.out.println("The text "+ conedit.getAttribute("innerHTML"));    	      
         	      String conedittext=actedit.getAttribute("innerHTML");    	  
         	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);     	      
         	      if(conedittext.contains("Contact Detail"))
         	      {
         	    	  All_Edit_Clone.fnd_editbtn(driver).click();
         	      }
              
         	     Contacts_NewCreate.typ_cntmailstreet(driver).sendKeys("9 Alexandra Parade");
              
         	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                WebElement y1=Account_NewCreate.fnd_savebtn(driver);
                y1.click();
                
                try {
                    //System.out.println("Thread Sleep: " + getName());
                    Thread.sleep(2000);
                } catch (InterruptedException ex) { }   
                Sprint2_RTB_TC18.captureScreenShot(driver);
                
                System.out.println("Contact validation Successful");
 
//---------------------------------------------------------------------------------------------------------//                
//Lead Creation and Edit//
                
            try {
                    //System.out.println("Thread Sleep: " + getName());
                    Thread.sleep(5000);
                } catch (InterruptedException ex) { } 
                HomePage.clk_Leads(driver).click();  
                
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                Sprint2_RTB_TC18.captureScreenShot(driver);
                            
                    
                    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
                    WebElement leadelement=AccountsPage.fnd_recentleads(driver);
                    System.out.println("The text "+ leadelement.getAttribute("innerHTML"));             
                     String leadelementtext=leadelement.getAttribute("innerHTML");         
                     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
                     if(leadelementtext.contains("Recent Leads"))
                     {
                    	AccountsPage.clk_nwbtn(driver).click();
                     }
               
                     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                     Sprint2_RTB_TC18.captureScreenShot(driver);
                     
                     Leads_NewCreate.sel_fnameddwn(driver).sendKeys("Mr");
                     Leads_NewCreate.typ_leadfname(driver).sendKeys("WT131_LD_T1");           
                     Leads_NewCreate.typ_leadlname(driver).sendKeys("WT131_LD_T1");
                     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                     Select m=new Select(Leads_NewCreate.sel_leadstatus(driver));
                     m.selectByVisibleText("Open");             
                     
                     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                     Select n=new Select( Leads_NewCreate.sel_leadsource(driver));
                     n.selectByVisibleText("Direct Mailing"); 
                     
                    
                     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                     Leads_NewCreate.typ_leadncmpny(driver).sendKeys("Sample_WT131_LD_nc");
                     
                     Select p=new Select(Leads_NewCreate.typ_leadtype(driver));
                     p.selectByVisibleText("Tender");
                     
                       
                     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
                     Sprint2_RTB_TC18.captureScreenShot(driver);
                                
                     try {
                         //System.out.println("Thread Sleep: " + getName());
                         Thread.sleep(5000);
                     } catch (InterruptedException ex) { } 
                     WebElement x2=Account_NewCreate.fnd_savebtn(driver);
                     x2.click();
                     
                     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
                     Sprint2_RTB_TC18.captureScreenShot(driver);
 //LEAD EDIT//
                     
                     try {
                         //System.out.println("Thread Sleep: " + getName());
                         Thread.sleep(3000);
                     } catch (InterruptedException ex) { } 
                     
                     WebElement leadedit=All_Edit_Clone.fnd_leaddetail(driver);
             	     System.out.println("The text "+ leadedit.getAttribute("innerHTML"));    	      
             	      String leadedittext=actedit.getAttribute("innerHTML");    	  
             	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);     	      
             	      if(leadedittext.contains("Lead Detail"))
             	      {
             	    	  All_Edit_Clone.fnd_editbtn(driver).click();
             	      }
             	      
             	     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             	     Leads_NewCreate.typ_leademail(driver).sendKeys("mmkautomation@gmail.com");
                     Leads_NewCreate.typ_leadphone(driver).sendKeys("4472726636");
                  
                     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
                     Sprint2_RTB_TC18.captureScreenShot(driver);
                     
                     try {
                         //System.out.println("Thread Sleep: " + getName());
                         Thread.sleep(3000);
                     } catch (InterruptedException ex) { } 
                      
                    WebElement y2=Account_NewCreate.fnd_savebtn(driver);
                    y2.click();  
                    
                    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
                    Sprint2_RTB_TC18.captureScreenShot(driver);
                    
                    System.out.println("Lead validation successful");
 //----------------------------------------------------------------------------------------------------------------------------//
//Oppor create and Edit//
                    
                    
                    try {
                        //System.out.println("Thread Sleep: " + getName());
                        Thread.sleep(5000);
                    } catch (InterruptedException ex) { }              
                    HomePage.clk_Opportunity(driver).click();
                    
                    
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
                    WebElement opporelement=AccountsPage.fnd_recentoppurtunities(driver);
                    System.out.println("The text "+ opporelement.getAttribute("innerHTML"));             
                     String opporelementtext=opporelement.getAttribute("innerHTML");         
                     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
                     if(opporelementtext.contains("Recent Opportunities"))
                     {
                    	AccountsPage.clk_nwbtn(driver).click();
                     }
                  
                     try {
                         //System.out.println("Thread Sleep: " + getName());
                         Thread.sleep(3000);
                     } catch (InterruptedException ex) { }              
                     
                     Sprint2_RTB_TC18.captureScreenShot(driver);
                     
                     try {
                         //System.out.println("Thread Sleep: " + getName());
                         Thread.sleep(2000);
                     } catch (InterruptedException ex) { } 
                     
                     Opportunity_NewCreate.typ_opporname(driver).sendKeys("WT131_OP_T1");
                     Opportunity_NewCreate.typ_opporacname(driver).sendKeys("WT131_AC_T1");
                     Opportunity_NewCreate.typ_opporcdate(driver).sendKeys("24/10/2016");
                     Opportunity_NewCreate.sel_opporcuurency(driver).click();
                    
                     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
                     Select a1=new Select(Opportunity_NewCreate.sel_opporcuurency(driver));
                     a1.selectByVisibleText("GBP - British Pound");
                     
                     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
                     Select b1=new Select(Opportunity_NewCreate.sel_opporstage(driver));
                     b1.selectByVisibleText("Develop");
                     
                     Opportunity_NewCreate.typ_opporonhdate(driver).sendKeys("24/10/2016");
                     Opportunity_NewCreate.typ_opporoffhdate(driver).sendKeys("24/10/2016");
                     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
                     Select c1=new Select(Opportunity_NewCreate.sel_opporprdfly(driver));
                     c1.selectByVisibleText("Air - Compressor");
                     
                     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
                     Leads_NewCreate.ldsel_prdflyrbt(driver).click();
                     
                     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
                     Select d=new Select(Opportunity_NewCreate.sel_opporldsrc(driver));
                     d.selectByVisibleText("Telemarketing");
                     
                     try {
                         //System.out.println("Thread Sleep: " + getName());
                         Thread.sleep(3000);
                     } catch (InterruptedException ex) { } 
                     
                     Account_NewCreate.fnd_savebtn(driver).click();
                     
                     try {
                         //System.out.println("Thread Sleep: " + getName());
                         Thread.sleep(3000);
                     } catch (InterruptedException ex) { }              
                     Sprint2_RTB_TC1.captureScreenShot(driver);    
                     
   //Edit-Opportunity//  
                     
                     try {
                         //System.out.println("Thread Sleep: " + getName());
                         Thread.sleep(3000);
                     } catch (InterruptedException ex) { } 
                     
                     WebElement opporedit=All_Edit_Clone.fnd_oppordetail(driver);
             	     System.out.println("The text "+ opporedit.getAttribute("innerHTML"));    	      
             	      String opporedittext=actedit.getAttribute("innerHTML");    	  
             	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);     	      
             	      if(opporedittext.contains("Opportunity Detail"))
             	      {
             	    	  All_Edit_Clone.fnd_editbtn(driver).click();
             	      }
                  
             	     Opportunity_NewCreate.typ_opporamnt(driver).sendKeys("100");
             	     
             	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
                    Sprint2_RTB_TC18.captureScreenShot(driver);
                  
             	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                    WebElement y3=Account_NewCreate.fnd_savebtn(driver);
                    y3.click();  
                    
                    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
                    Sprint2_RTB_TC18.captureScreenShot(driver);
                    
                    System.out.println("Opportunity Validation succesful");

  //View and Edit other zone-Using rep for South East//   
                    
 //Search functionality-S1-Tc5//
                    
                    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                    HomePage.clk_sfsearch(driver).click();
                    HomePage.clk_sfsearch(driver).sendKeys("test_southeast");
                    
                    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                    Sprint1_RTB_TC5.captureScreenShot(driver);
                     
                    WebElement k=HomePage.clk_sfsearchbtn(driver);
                    k.click();
                
    }
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint2_TC18/screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }         
       }
   	
    }
    	
    