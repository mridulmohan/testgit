package pageTest_S2;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import jxl.Workbook;
import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.Opportunity_NewCreate;
import pageTest_S3.Sprint3_RTB_TC27;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;
import pageObjects.Close_Opportunity;

 
     public class Sprint2_RTB_TC6 {
    	 
    	 
    	/* @AfterTest
    	 public void tearDown() throws Exception { 
    	     driver.close();
    		 driver.quit();
    	     } */
    	 
         private static WebDriver driver = null;
         
    @Test(enabled=true)
       public void ART_603() throws Exception {
    	
//REG-S2-Develop Opportunity: Highlight Competitor for Opportunity-Closed Lost//

    	
//---------------------------------------------------------------------------------------------------//
   	 
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data.xls");
     	 System.out.println("Excel located");        	 
     	 Workbook wb=Workbook.getWorkbook(src);        	 
     	 System.out.println("Excel loaded");
     	 String url=wb.getSheet(12).getCell(1,0).getContents();
    	 String username=wb.getSheet(12).getCell(1,1).getContents();
    	 String password=wb.getSheet(12).getCell(1,2).getContents();
    	 String oppname=wb.getSheet(12).getCell(1,3).getContents();
    	 String accname=wb.getSheet(12).getCell(1,4).getContents();
    	 String ocdate=wb.getSheet(12).getCell(1,5).getContents();
    	 String Currency=wb.getSheet(12).getCell(1,6).getContents();
    	 String opstage=wb.getSheet(12).getCell(1,7).getContents();
    	 String onhdate=wb.getSheet(12).getCell(1,8).getContents();
    	 String ofhdate=wb.getSheet(12).getCell(1,9).getContents();
    	 String prodcty=wb.getSheet(12).getCell(1,10).getContents();
    	 String oppsource=wb.getSheet(12).getCell(1,11).getContents(); 
    	 String reason=wb.getSheet(12).getCell(1,12).getContents();
    	 String compacc=wb.getSheet(12).getCell(1,13).getContents();
    	 String selcomp=wb.getSheet(12).getCell(1,14).getContents();
    	 String othcomp=wb.getSheet(12).getCell(1,15).getContents();
    	 String rsnlost=wb.getSheet(12).getCell(1,16).getContents();

//--------------------------------------------------------------------------------------------------//    	
    	 System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 	
        LoginPage.txtbx_Password(driver).sendKeys(password);        					
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
        Sprint2_RTB_TC6.captureScreenShot(driver);
        
        driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS); 
            HomePage.clk_Opportunity(driver).click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }              
            Sprint2_RTB_TC1.captureScreenShot(driver);
            
            
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement opporelement=AccountsPage.fnd_recentoppurtunities(driver);
            System.out.println("The text "+ opporelement.getAttribute("innerHTML"));             
             String opporelementtext=opporelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(opporelementtext.contains("Recent Opportunities"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC6.captureScreenShot(driver);
             
             
             Opportunity_NewCreate.typ_opporname(driver).sendKeys(oppname);			//Oppor Name
             
             Opportunity_NewCreate.typ_opporcdate(driver).sendKeys(ocdate);			//Oppor Date
             Opportunity_NewCreate.sel_opporcuurency(driver).click();
            
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select a=new Select(Opportunity_NewCreate.sel_opporcuurency(driver));
             a.selectByVisibleText(Currency);										//Currency
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select b=new Select(Opportunity_NewCreate.sel_opporstage(driver));
             b.selectByVisibleText(opstage);										//Oppor Stage
             
             Opportunity_NewCreate.typ_opporonhdate(driver).sendKeys(onhdate);		//Oppor on hire date
             Opportunity_NewCreate.typ_opporacname(driver).sendKeys(accname);		//Account Name
             Opportunity_NewCreate.typ_opporoffhdate(driver).sendKeys(ofhdate);		//Oppor off hire date
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select c=new Select(Opportunity_NewCreate.sel_opporprdfly(driver));
             c.selectByVisibleText(prodcty);										//Oppor Prod category
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Leads_NewCreate.ldsel_prdflyrbt(driver).click();
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select d=new Select(Opportunity_NewCreate.sel_opporldsrc(driver));
             d.selectByVisibleText(oppsource);										//Oppor source
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Account_NewCreate.fnd_savebtn(driver).click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC6.captureScreenShot(driver);             
                        
             System.out.println("Opportunity created successfully"+oppname);

//*********************Click on  Close Opportunity******************// 
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             WebElement cl=All_Edit_Clone.clk_closeoppor(driver);
             cl.click();
             
//*************Move focus to pop up window*************************//             
             
             try{
           	  Thread.sleep(7000);
           	  for(String winHandle:driver.getWindowHandles())
           			
           	  		  {
           		  driver.switchTo().window(winHandle);
           			  }
           	                   
           	  driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
              Sprint2_RTB_TC6.captureScreenShot(driver);
           	    
            	 Select e=new Select(Close_Opportunity.sel_clostatus(driver));
                 e.selectByVisibleText(reason);  
                 try {
                     //System.out.println("Thread Sleep: " + getName());
                     Thread.sleep(2000);
                 } catch (InterruptedException ex) { } 
                 Sprint2_RTB_TC6.captureScreenShot(driver);
                 
                 WebElement f=Close_Opportunity.clk_comyes(driver);
                 f.click();    
                 try {
                     //System.out.println("Thread Sleep: " + getName());
                     Thread.sleep(2000);
                 } catch (InterruptedException ex) { }
                 Sprint2_RTB_TC6.captureScreenShot(driver);
                 WebElement g=Close_Opportunity.clk_nxt(driver);
                 g.click();
//--//
                 Close_Opportunity.typ_compacc(driver).sendKeys(compacc); 
                 try {
                     //System.out.println("Thread Sleep: " + getName());
                     Thread.sleep(2000);
                 } catch (InterruptedException ex) { }
                 Sprint2_RTB_TC6.captureScreenShot(driver);
                 WebElement h=Close_Opportunity.clk_nxt(driver);
                 h.click();                 
//---//                 
                 Select j=new Select(Close_Opportunity.sel_compacc(driver));
                 j.selectByVisibleText(selcomp); 
                 try {
                     //System.out.println("Thread Sleep: " + getName());
                     Thread.sleep(2000);
                 } catch (InterruptedException ex) { }
                 Sprint2_RTB_TC6.captureScreenShot(driver);
                 WebElement k=Close_Opportunity.clk_nxt(driver);
                 k.click();
 //--//                
                 Close_Opportunity.typ_othacc(driver).sendKeys(othcomp); 
                 try {
                     //System.out.println("Thread Sleep: " + getName());
                     Thread.sleep(2000);
                 } catch (InterruptedException ex) { }
                 Sprint2_RTB_TC6.captureScreenShot(driver);
                 WebElement l=Close_Opportunity.clk_nxt(driver);
                 l.click();                 
//--//                 
                 Select m=new Select(Close_Opportunity.sel_reaslost(driver));
                 m.selectByVisibleText(rsnlost); 
                 try {
                     //System.out.println("Thread Sleep: " + getName());
                     Thread.sleep(2000);
                 } catch (InterruptedException ex) { }
                 Sprint2_RTB_TC6.captureScreenShot(driver);
                 WebElement n=Close_Opportunity.clk_nxt(driver);
                 n.click();
                 
                 try {
                     //System.out.println("Thread Sleep: " + getName());
                     Thread.sleep(5000);
                 } catch (InterruptedException ex) { }     
                 Sprint2_RTB_TC6.captureScreenShot(driver);
                 
                 String error=driver.findElement(By.xpath(".//*[@id='p:i:i:f:pb:d:FinishDisplay']")).getText();
                 System.out.println(error);
                                  	  
             }catch(Exception e)              
             {
           	  System.out.println(e);
             }
             
             
             System.out.println("Sprint2-test case_6 successfull..Please validate screenshots..");
                      
                          
    }
             public static void captureScreenShot(WebDriver ldriver){        	 
            	  // Take screenshot and store as a file format//
            	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
            	try {
            	  // To copy the  screenshot to desired location using copyFile method	 
            	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_2/Sprint2_TC6/screenshot_"+System.currentTimeMillis()+".png"));
            	       }	 
            	catch (IOException e)	 
            	{	 
            	System.out.println(e.getMessage());	 
            	    }         
              }
             
   
     
     }
     
            