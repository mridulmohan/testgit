package pageTest_S2;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.AfterTest;


  // Import package pageObject//     

import pageObjects.AccountsPage;
import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;
import pageObjects.Oppor_New_Competitor_Account;

 
     public class Sprint2_RTB_TC7{
    	 
         private static WebDriver driver = null;        
   
         /*@AfterTest
         public void tearDown() {
             driver.close();
             driver.quit();
         
         }*/
    @Test(enabled=true)
       public void ART_605() throws Exception {
    	
//REG-S2-Admin able to create Competitor accounts//
//---------------------------------------------------------------------------------------------------//
      	 
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data.xls");
     	 System.out.println("Excel located");        	 
     	 Workbook wb=Workbook.getWorkbook(src);        	 
     	 System.out.println("Excel loaded");
     	 String url=wb.getSheet(7).getCell(1,0).getContents();
    	 String username=wb.getSheet(7).getCell(1,1).getContents();
    	 String password=wb.getSheet(7).getCell(1,2).getContents();
    	 String Compname=wb.getSheet(7).getCell(1,3).getContents();
    	 String accname=wb.getSheet(7).getCell(1,4).getContents();

//--------------------------------------------------------------------------------------------------//    	

System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        	} catch (InterruptedException ex) { }    
        	HomePage.clk_Compacc(driver).click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(2000);
            } catch (InterruptedException ex) { }              
            Sprint2_RTB_TC7.captureScreenShot(driver);
            
            Sprint2_RTB_TC7.captureScreenShot(driver);
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(2000);
            } catch (InterruptedException ex) { }                
            WebElement opporelement=AccountsPage.fnd_compacct(driver);
            System.out.println("The text "+ opporelement.getAttribute("innerHTML"));             
             String opporelementtext=opporelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(opporelementtext.contains("Recent Competitor Accounts"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
             
             
             Oppor_New_Competitor_Account.typ_coactnm(driver).sendKeys(Compname);
             Oppor_New_Competitor_Account.typ_coaccnm(driver).sendKeys(accname);
             
             Sprint2_RTB_TC7.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { }  
             WebElement a=Oppor_New_Competitor_Account.clk_ocomsv(driver);
             a.click();
             
             Sprint2_RTB_TC7.captureScreenShot(driver);
             
             WebElement a1=All_Edit_Clone.fnd_editbtn(driver);
             a1.click();
            
             System.out.println("Competitor Account created successfully...");
             System.out.print("TC7 Successfull..Please verify screenshots");            
    }
    
    
    
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_2/Sprint2_TC7/screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }         
       }
      
    
     }    
     