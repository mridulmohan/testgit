package pageTest_S2;
 
     import java.io.File;
     import java.io.IOException;
     import java.util.concurrent.TimeUnit; 
     import org.openqa.selenium.WebDriver;
     import org.openqa.selenium.WebElement;
     import org.openqa.selenium.firefox.FirefoxDriver;
     import org.openqa.selenium.support.ui.Select;
     import org.testng.annotations.Test;

import jxl.Workbook;

import org.testng.annotations.AfterTest;
     import org.apache.commons.io.FileUtils;
     import org.openqa.selenium.OutputType;
     import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     

import pageObjects.AccountsPage;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.Projects_New;
import pageObjects.Project_Details;

 
     public class Sprint2_RTB_TC17{
    	 

			@AfterTest
    	 	public void tearDown() throws Exception { 
    		 driver.close();
    		 driver.quit();
    	     } 
    	 
         private static WebDriver driver = null;        
         
         
    @Test(enabled=true)
       public void ART_612() throws Exception {
    	
//AG-12	2.x.x Develop Opportunity: Link Opportunities to Project
//Scenario-Create a project and add  Opport/Lead-With master Slave//
//REG-S2-Project -Scenario-Create a project and add  Opport/Lead-With master Slave-Verify removing master
   //*****************************************************************************************************************//
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data.xls");
      	 System.out.println("Excel located");        	 
      	 Workbook wb=Workbook.getWorkbook(src);        	 
      	 System.out.println("Excel loaded");
      	 String url=wb.getSheet(1).getCell(1,0).getContents();
     	 String username=wb.getSheet(1).getCell(1,1).getContents();
     	 String password=wb.getSheet(1).getCell(1,2).getContents();
     	 String projname=wb.getSheet(1).getCell(1,3).getContents();
     	 String projtype=wb.getSheet(1).getCell(1,4).getContents();
     	 String location=wb.getSheet(1).getCell(1,5).getContents();
     	 String reltype=wb.getSheet(1).getCell(1,6).getContents();
     	 String searchterm=wb.getSheet(1).getCell(1,7).getContents();
    	
//*****************************************************************************************************************//
     	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
     	 driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }              
        Sprint2_RTB_TC17.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }     
        HomePage.clk_Projects(driver).click();    
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }              
        Sprint2_RTB_TC17.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement proelement=AccountsPage.fnd_recentprojects(driver);
            System.out.println("The text "+ proelement.getAttribute("innerHTML"));             
             String proelementtext=proelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(proelementtext.contains("Recent Projects"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
            
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC17.captureScreenShot(driver);
            
    
//************************************Enter all the details and create a project******************************//
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);   
             Projects_New.typ_prname(driver).sendKeys(projname);
             //Projects_New.sel_prstdt(driver).sendKeys("21/10/2016");
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
             Select a=new Select(Projects_New.sel_prtyp(driver));
             a.selectByVisibleText(projtype);
             
             //Projects_New.sel_prenddt(driver).sendKeys("21/10/2016");
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
             Select b=new Select(Projects_New.sel_prloc(driver));
             b.selectByVisibleText(location); 
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
             Select c=new Select(Projects_New.sel_prreltyp(driver));
             c.selectByVisibleText(reltype); 
            
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC17.captureScreenShot(driver);
            
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
             WebElement x=Projects_New.clk_prsv(driver);
             x.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC17.captureScreenShot(driver);
             
             System.out.println("Project -Competing typoe created succesfully..");
 //**************************************************************************************************************************//            
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 
             
             
            driver.switchTo().frame("066580000037RtF");
            System.out.println("Ifram invoked");
             Project_Details.typ_prdetnm(driver).sendKeys(searchterm);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(7000);
             } catch (InterruptedException ex) { } 
             
             Project_Details.clk_opp1ms(driver).click();
             Project_Details.clk_opp1add(driver).click();
             Project_Details.clk_opp2add(driver).click();
                          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC17.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             WebElement x1=Project_Details.clk_prdetsv(driver);
             x1.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC17.captureScreenShot(driver);
             
 //  ******************Remove Master***********************************//  
             
                          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 
             Project_Details.clk_opp1ms(driver).click();
        
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC17.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { } 
             WebElement x3=Project_Details.clk_prdetsv(driver);
             x3.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC17.captureScreenShot(driver);
             
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { } 
            
             
             driver.switchTo().defaultContent();
             
             System.out.println("Sprint2_TC17 successfull..Please verify SS..");
             
                
    }
    public static void captureScreenShot(WebDriver ldriver){        	 
  	  // Take screenshot and store as a file format//
  	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
  	try {
  	  // To copy the  screenshot to desired location using copyFile method	 
  	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_2/Sprint2_TC17/screenshot_"+System.currentTimeMillis()+".png"));
  	       }	 
  	catch (IOException e)	 
  	{	 
  	System.out.println(e.getMessage());	 
  	    }         
    }
     }
    