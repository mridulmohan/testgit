package pageTest_S2;
 
     import java.io.File;
     import java.io.IOException;
     import java.util.concurrent.TimeUnit; 
     import org.openqa.selenium.WebDriver;
     import org.openqa.selenium.WebElement;
     import org.openqa.selenium.firefox.FirefoxDriver;
     import org.testng.annotations.AfterTest;
     import org.testng.annotations.Test;
import jxl.Workbook;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import pageObjects.All_Edit_Clone;

// Import package pageObject//     

import pageObjects.HomePage;
import pageObjects.LoginPage;

 
     public class Sprint2_RTB_TC2{
    	 
    	/*@AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	 }*/
    	 
         private static WebDriver driver = null;        
         
         
    @Test(enabled=true)
       public void ART_599_2() throws Exception {
    	
//AG-3	2.x.x Create Leads-Search leads//
//Search for any Opportunity with keywords in Search field//
//Edit and Clone-Clone//     
    	
//--------------------------------------------------------------------------------------------------------------------//
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data.xls");
    	 System.out.println("Excel located");        	 
    	 Workbook wb=Workbook.getWorkbook(src);        	 
    	 System.out.println("Excel loaded");
    	 String url=wb.getSheet(6).getCell(1,0).getContents();
    	 String username=wb.getSheet(6).getCell(1,1).getContents();
    	 String password=wb.getSheet(6).getCell(1,2).getContents();
    	 String oppname=wb.getSheet(6).getCell(1,3).getContents();
    	 
//--------------------------------------------------------------------------------------------------------------------//
    	 System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe"); 													
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
        LoginPage.txtbx_UserName(driver).sendKeys(username); 							//Login Username
        LoginPage.txtbx_Password(driver).sendKeys(password);        					//Login Password
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint2_RTB_TC2.captureScreenShot(driver);
 
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }      
        HomePage.clk_sfsearch(driver).click();
        HomePage.clk_sfsearch(driver).sendKeys(oppname);							
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint2_RTB_TC2.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }         
        WebElement k=HomePage.clk_sfsearchbtn(driver);
        k.click();
 
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { } 
        Sprint2_RTB_TC2.captureScreenShot(driver);
      
        System.out.println("Searching opportunity..." +oppname);
                   												//   
        int Row_count2 = driver.findElements(By.xpath(".//*[@id='Opportunity_body']/table/tbody/tr")).size();
        System.out.println("Number Of Rows = "+Row_count2);
        
        		String  xpath_first=".//*[@id='Opportunity_body']/table/tbody/tr[";        
        		String xpath_last="]/th/a";

        		for (int p=2; p<=Row_count2; p++)
        		{

        		String OPPNAME=driver.findElement(By.xpath(xpath_first+p+xpath_last)).getText();
        				if(OPPNAME.equalsIgnoreCase(oppname)){
        					System.out.println("Opportunity Search term found");
        					WebElement m2=driver.findElement(By.xpath(xpath_first+p+xpath_last));
        					m2.click(); 
        					break;
        				}else{
        					System.out.println("Opportunity search term not found");
        				}
        		}                		
        
        	 try {
                    //System.out.println("Thread Sleep: " + getName());
       	            Thread.sleep(5000);
       	        } catch (InterruptedException ex) { }  
       		 All_Edit_Clone.fnd_opporclonebtn(driver).click();
       
       		 try {
           
            Thread.sleep(5000);
       		 } catch (InterruptedException ex) { }              
       		 Sprint2_RTB_TC1.captureScreenShot(driver);
       		 
       		All_Edit_Clone.fnd_editbtn(driver).click();
        
        System.out.println("Sprint2_testcase2 successful-verify SS");
        
        
    }
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_2/Sprint2_TC2/screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }  
     }
     }
     