package pageTest_S2;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import jxl.Workbook;
import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.Opportunity_NewCreate;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;

 
     public class Sprint2_RTB_TC1 {
    	 
    	 
    	 /*@AfterTest
    	 public void tearDown() throws Exception { 
    	     driver.close();
    		 driver.quit();
    	     } */
    	 
         private static WebDriver driver = null;
         
    @Test(enabled=true)
       public void ART_599_1() throws Exception {
    	
//AG-3	2.x.x Develop Opportunity: Clone opportunities
//This test case verifies-Creating a new opportunity and Cloning it//
    	
//---------------------------------------------------------------------------------------------------//
   	 
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data.xls");
     	 System.out.println("Excel located");        	 
     	 Workbook wb=Workbook.getWorkbook(src);        	 
     	 System.out.println("Excel loaded");
     	 String url=wb.getSheet(2).getCell(1,0).getContents();
    	 String username=wb.getSheet(2).getCell(1,1).getContents();
    	 String password=wb.getSheet(2).getCell(1,2).getContents();
    	 String oppname=wb.getSheet(2).getCell(1,3).getContents();
    	 String accname=wb.getSheet(2).getCell(1,4).getContents();
    	 String ocdate=wb.getSheet(2).getCell(1,5).getContents();
    	 String Currency=wb.getSheet(2).getCell(1,6).getContents();
    	 String opstage=wb.getSheet(2).getCell(1,7).getContents();
    	 String onhdate=wb.getSheet(2).getCell(1,8).getContents();
    	 String ofhdate=wb.getSheet(2).getCell(1,9).getContents();
    	 String prodcty=wb.getSheet(2).getCell(1,10).getContents();
    	 String oppsource=wb.getSheet(2).getCell(1,11).getContents();

//--------------------------------------------------------------------------------------------------//    	
    	 System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 	
        LoginPage.txtbx_Password(driver).sendKeys(password);        					
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
        Sprint2_RTB_TC1.captureScreenShot(driver);
        
        driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS); 
            HomePage.clk_Opportunity(driver).click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }              
            Sprint2_RTB_TC1.captureScreenShot(driver);
            
            
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement opporelement=AccountsPage.fnd_recentoppurtunities(driver);
            System.out.println("The text "+ opporelement.getAttribute("innerHTML"));             
             String opporelementtext=opporelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(opporelementtext.contains("Recent Opportunities"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC1.captureScreenShot(driver);
             
             
             Opportunity_NewCreate.typ_opporname(driver).sendKeys(oppname);			//Oppor Name
             
             Opportunity_NewCreate.typ_opporcdate(driver).sendKeys(ocdate);			//Oppor Date
             Opportunity_NewCreate.sel_opporcuurency(driver).click();
            
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select a=new Select(Opportunity_NewCreate.sel_opporcuurency(driver));
             a.selectByVisibleText(Currency);										//Currency
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select b=new Select(Opportunity_NewCreate.sel_opporstage(driver));
             b.selectByVisibleText(opstage);										//Oppor Stage
             
             Opportunity_NewCreate.typ_opporonhdate(driver).sendKeys(onhdate);		//Oppor on hire date
             Opportunity_NewCreate.typ_opporacname(driver).sendKeys(accname);		//Account Name
             Opportunity_NewCreate.typ_opporoffhdate(driver).sendKeys(ofhdate);		//Oppor off hire date
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select c=new Select(Opportunity_NewCreate.sel_opporprdfly(driver));
             c.selectByVisibleText(prodcty);										//Oppor Prod category
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Leads_NewCreate.ldsel_prdflyrbt(driver).click();
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select d=new Select(Opportunity_NewCreate.sel_opporldsrc(driver));
             d.selectByVisibleText(oppsource);										//Oppor source
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Account_NewCreate.fnd_savebtn(driver).click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC1.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { }     
             All_Edit_Clone.fnd_opporclonebtn(driver).click();
            
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC1.captureScreenShot(driver);
             
             All_Edit_Clone.fnd_editbtn(driver).click();
             
             System.out.println("Sprint2_TC1_Pass..Please Verify SS..");
             
                      
                          
    }
             public static void captureScreenShot(WebDriver ldriver){        	 
            	  // Take screenshot and store as a file format//
            	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
            	try {
            	  // To copy the  screenshot to desired location using copyFile method	 
            	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_2/Sprint2_TC1/screenshot_"+System.currentTimeMillis()+".png"));
            	       }	 
            	catch (IOException e)	 
            	{	 
            	System.out.println(e.getMessage());	 
            	    }         
              }
             
   
     
     }
     
            