package pageTest_S2;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.Opportunity_NewCreate;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.Oppor_New_Linked_Competitor;
import pageObjects.Oppor_New_Competitor_Account;
import pageObjects.All_Edit_Clone;

 
     public class Sprint2_RTB_TC8 {
    	 
    	/* @AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.quit();
    	     } 
    	 */
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void testcase8() {
    	
//AG-10	2.x.x Develop Opportunity: Highlight Competitor for Opportunity
//Sprint2_RTB_TC8-Create a Competitor and link to an Opportunity  	
 //Create New Competitor//
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get("https://aggreko--CI2.cs82.my.salesforce.com");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click();
        LoginPage.txtbx_UserName(driver).sendKeys("sf.systestmanager@aggreko.trial.ci2"); 
        LoginPage.txtbx_Password(driver).sendKeys("Mercury@123");        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
        Sprint2_RTB_TC6.captureScreenShot(driver);
    	
                try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { } 
            HomePage.clk_Compacc(driver).click();
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement opporelement=AccountsPage.fnd_compacct(driver);
            System.out.println("The text "+ opporelement.getAttribute("innerHTML"));             
             String opporelementtext=opporelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(opporelementtext.contains("Recent Competitor Accounts"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
    	
    	try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }  ;
        Oppor_New_Competitor_Account.typ_coactnm(driver).sendKeys("813_Competitor");
        //Oppor_New_Competitor_Account.typ_coaccnm(driver).sendKeys("gggg");
       
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { } 
        Sprint2_RTB_TC7.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  ;
        WebElement r=Oppor_New_Competitor_Account.clk_ocomsv(driver);
        r.click(); 
    	
    //Create Opportunity//
    	
        
        driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS); 
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { } 
            HomePage.clk_Opportunity(driver).click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }              
            Sprint2_RTB_TC6.captureScreenShot(driver);
            
            
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement opporelement1=AccountsPage.fnd_recentoppurtunities(driver);
            System.out.println("The text "+ opporelement1.getAttribute("innerHTML"));             
             String opporelementtext1=opporelement1.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(opporelementtext1.contains("Recent Opportunities"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC6.captureScreenShot(driver);
             
             Opportunity_NewCreate.typ_opporname(driver).sendKeys("Newtodayoppor114");
             Opportunity_NewCreate.typ_opporacname(driver).sendKeys("Sprinter1114");
             Opportunity_NewCreate.typ_opporcdate(driver).sendKeys("1/11/2016");
             Opportunity_NewCreate.sel_opporcuurency(driver).click();
            
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select a=new Select(Opportunity_NewCreate.sel_opporcuurency(driver));
             a.selectByVisibleText("GBP - British Pound");
       
     		try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }              
     		Sprint2_RTB_TC6.captureScreenShot(driver);
     		
    		
            
    		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);          
             Opportunity_NewCreate.typ_opporonhdate(driver).sendKeys("18/10/2016");
             Opportunity_NewCreate.sel_opporcuurency(driver).click();
             Opportunity_NewCreate.typ_opporoffhdate(driver).sendKeys("18/10/2016");
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select e=new Select(Opportunity_NewCreate.sel_opporprdfly(driver));
             e.selectByVisibleText("Air - Compressor");
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Leads_NewCreate.ldsel_prdflyrbt(driver).click();
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select f=new Select(Opportunity_NewCreate.sel_opporldsrc(driver));
             f.selectByVisibleText("Telemarketing");
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select g=new Select(Opportunity_NewCreate.sel_opporstage(driver));
             g.selectByVisibleText("Build");
             
             //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             //Select l=new Select(Opportunity_NewCreate.sel_opporrealst(driver));
             //l.selectByVisibleText("Alternative Solution/Non Aggreko");
  
            
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Account_NewCreate.fnd_savebtn(driver).click();
             
                                     
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC6.captureScreenShot(driver);
   
 //Link New Opportunity Created// 
             
           //New Competitor-Buttom click//  
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  ;
             WebElement q=All_Edit_Clone.fnd_newcomp(driver);
             q.click(); 
             
             
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC7.captureScreenShot(driver);
             
//  Enter values in the field-Competitor Page//
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  ;
             Oppor_New_Linked_Competitor.typ_nlaccact(driver).sendKeys("813_Competitor");
             //Oppor_New_Competitor_Account.typ_coaccnm(driver).sendKeys("gggg");
            
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC7.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  ;
             WebElement r1=Oppor_New_Linked_Competitor.clk_nlacsv(driver);
             r1.click(); 
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC7.captureScreenShot(driver);
             
             System.out.print("TC8 Successfull");            
                         
    }
    
   
    public static void captureScreenShot(WebDriver ldriver){        	 
  	  // Take screenshot and store as a file format//
  	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
  	try {
  	  // To copy the  screenshot to desired location using copyFile method	 
  	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_2/Sprint2_TC8/screenshot_"+System.currentTimeMillis()+".png"));
  	       }	 
  	catch (IOException e)	 
  	{	 
  	System.out.println(e.getMessage());	 
  	    }     
     }
     }
     