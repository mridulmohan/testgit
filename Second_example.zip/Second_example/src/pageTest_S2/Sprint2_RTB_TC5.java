package pageTest_S2;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.Opportunity_NewCreate;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;

 
     public class Sprint2_RTB_TC5 {
    	 
    	 /*@AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     } */
    	 
         private static WebDriver driver = null;
         
         @Test(enabled=true)
         public void ART_602() throws Exception {
    	
//AG-104	2.x.x Qualify Lead to Opportunity: Trigger automated status change
//This test case verifies the Closed-Lost//
//Verify mandatory fields//
//Verify the Stage-Percentage//
        	 
//---------------------------------------------------------------------------------------------------------------------------//
				//***DATA TO BE INPUT***//
         	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data.xls");
        	 System.out.println("Excel located");        	 
        	 Workbook wb=Workbook.getWorkbook(src);        	 
        	 System.out.println("Excel loaded");
        	 String url=wb.getSheet(5).getCell(1,0).getContents();
        	 String username=wb.getSheet(5).getCell(1,1).getContents();
        	 String password=wb.getSheet(5).getCell(1,2).getContents();
        	 String oppname=wb.getSheet(5).getCell(1,3).getContents();
        	 String accname=wb.getSheet(5).getCell(1,4).getContents();
        	 String ocdate=wb.getSheet(5).getCell(1,5).getContents();
        	 String Currency=wb.getSheet(5).getCell(1,6).getContents();
        	 String opstage=wb.getSheet(5).getCell(1,7).getContents();
       		 String onhdate=wb.getSheet(5).getCell(1,8).getContents();
       		 String ofhdate=wb.getSheet(5).getCell(1,9).getContents();
       		 String prodcty=wb.getSheet(5).getCell(1,10).getContents();
       		 String oppsource=wb.getSheet(5).getCell(1,11).getContents();
       		String rsnlost1=wb.getSheet(5).getCell(1,12).getContents();
       		String rsnlost2=wb.getSheet(5).getCell(1,13).getContents();
       		
//---------------------------------------------------------------------------------------------------------------------------//        	        	 
   	
 
    	
//Develop//  
       		System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
        Sprint2_RTB_TC5.captureScreenShot(driver);
        
        	try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        	} catch (InterruptedException ex) { }         
        	HomePage.clk_Opportunity(driver).click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }              
            Sprint2_RTB_TC5.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement opporelement=AccountsPage.fnd_recentoppurtunities(driver);
            System.out.println("The text "+ opporelement.getAttribute("innerHTML"));             
             String opporelementtext=opporelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(opporelementtext.contains("Recent Opportunities"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC5.captureScreenShot(driver);
             
             
             Opportunity_NewCreate.typ_opporname(driver).sendKeys(oppname);
             Opportunity_NewCreate.typ_opporacname(driver).sendKeys(accname);
             Opportunity_NewCreate.typ_opporcdate(driver).sendKeys(ocdate);		//Close Date
             Opportunity_NewCreate.sel_opporcuurency(driver).click();
            
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select a=new Select(Opportunity_NewCreate.sel_opporcuurency(driver));
             a.selectByVisibleText(Currency);									//Currency
       
     		try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }              
     	    Sprint2_RTB_TC5.captureScreenShot(driver);
     		
    		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select d=new Select(Opportunity_NewCreate.sel_opporstage(driver));
             d.selectByVisibleText(opstage);
           
           try {
               //System.out.println("Thread Sleep: " + getName());
               Thread.sleep(3000);
           } catch (InterruptedException ex) { }              
           Sprint2_RTB_TC5.captureScreenShot(driver);
            
            WebElement txtelement2 = Opportunity_NewCreate.get_opporprob(driver);
            String elementval2 = txtelement2.getAttribute("value");
    		System.out.println("Probablity % for Develop is  :: "+elementval2);
             
    		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);          
             Opportunity_NewCreate.typ_opporonhdate(driver).sendKeys(onhdate);		//On hire Date
             Opportunity_NewCreate.sel_opporcuurency(driver).click();
             Opportunity_NewCreate.typ_opporoffhdate(driver).sendKeys(ofhdate);		//Offhore date		
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select e=new Select(Opportunity_NewCreate.sel_opporprdfly(driver));	//Oppor prod Family
             e.selectByVisibleText(prodcty);
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Leads_NewCreate.ldsel_prdflyrbt(driver).click();
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select f=new Select(Opportunity_NewCreate.sel_opporldsrc(driver));			//Oppor Source
             f.selectByVisibleText(oppsource);
               
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }   
             Account_NewCreate.fnd_savebtn(driver).click();
                        
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC5.captureScreenShot(driver);
   
  //**********************************Editing to change the field to Closed-Lost***********************************// 
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }   
             All_Edit_Clone.fnd_editbtn(driver).click();
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select h=new Select(Opportunity_NewCreate.sel_opporstage(driver));
             h.selectByVisibleText("Closed Lost");
             
             WebElement txtelement3 = Opportunity_NewCreate.get_opporprob(driver);
             String elementval3 = txtelement3.getAttribute("value");
     		 System.out.println("Probablity % for Develop is  :: "+elementval3);
             
     		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);         
             Sprint2_RTB_TC5.captureScreenShot(driver);
            
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { }    
             Account_NewCreate.fnd_savebtn(driver).click();
             
   //***********************Entering mandatory fields mandatory fields**********************************************//
             System.out.println("Entering mandatory fields for Closed Lost...");
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC5.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select l=new Select(Opportunity_NewCreate.sel_opporrealst(driver));
             l.selectByVisibleText(rsnlost1);              
             

             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
             Account_NewCreate.fnd_savebtn(driver).click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC5.captureScreenShot(driver);
  
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select n=new Select(Opportunity_NewCreate.sel_opporrealst(driver));
             n.selectByVisibleText(rsnlost2);              
 
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
             Account_NewCreate.fnd_savebtn(driver).click();                      
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint2_RTB_TC5.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }   
             All_Edit_Clone.fnd_editbtn(driver).click(); 
             
             
             
             System.out.println("Sprint2_TC5_pass-verify SS...Please verify screenshots...");
             
    }
    public static void captureScreenShot(WebDriver ldriver){        	 
  	  // Take screenshot and store as a file format//
  	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
  	try {
  	  // To copy the  screenshot to desired location using copyFile method	 
  	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_2/Sprint2_TC5/screenshot_"+System.currentTimeMillis()+".png"));
  	       }	 
  	catch (IOException e)	 
  	{	 
  	System.out.println(e.getMessage());	 
  	    }     
     }
     }
     