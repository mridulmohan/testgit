package pageTest_S2;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.AfterTest;
import org.junit.After;
import org.junit.AfterClass;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.HomePage;
import pageObjects.Lead_Convert;
import pageObjects.LoginPage;
import pageTest.Sprint1_RTB_TC4;
import pageObjects.All_Edit_Clone;
import pageObjects.Oppor_New_Competitor_Account;

 
     public class Sprint2_RTB_TC9{
    	 
         private static WebDriver driver = null;        
   
        /* @AfterTest
         public void tearDown() {
             driver.close();
             driver.quit();
         
         }*/
         
    @Test(enabled=true)
       public void testcase9() {
    	
//AG-10	2.x.x Develop Opportunity: Highlight Competitor for Opportunity
//ART-202-SIT_AG_Opportunity_Highlight Competiter_Existing competitor_TC10//
//Lead-To Opportunity-Link Competitor//    	

    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get("https://aggreko--CI2.cs82.my.salesforce.com");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click(); 
        LoginPage.txtbx_UserName(driver).sendKeys("sf.systestmanager@aggreko.trial.ci2"); 
        LoginPage.txtbx_Password(driver).sendKeys("Mercury@123");        
        LoginPage.btn_LogIn(driver).click();
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { } 
        Sprint2_RTB_TC9.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }    
        HomePage.clk_Leads(driver).click(); 
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint2_RTB_TC9.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement leadelement=AccountsPage.fnd_recentleads(driver);
            System.out.println("The text "+ leadelement.getAttribute("innerHTML"));             
             String leadelementtext=leadelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(leadelementtext.contains("Recent Leads"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC9.captureScreenShot(driver);
             
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.sel_fnameddwn(driver).sendKeys("Mr");
             Leads_NewCreate.typ_leadfname(driver).sendKeys("Helloworld");           
             Leads_NewCreate.typ_leadlname(driver).sendKeys("Pvtltd");   
             //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             //.sendKeys("Open");
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Select a=new Select( Leads_NewCreate.sel_leadstatus(driver));
             a.selectByVisibleText("Qualified");
             
             Leads_NewCreate.typ_leadphone(driver).sendKeys("8626278290");           
             Select b=new Select(Leads_NewCreate.sel_leadaic(driver));
             b.selectByVisibleText("0202 Construction:Industrial");
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Select n=new Select( Leads_NewCreate.sel_leadsource(driver));
             n.selectByVisibleText("Direct Mailing");
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.typ_leadncmpny(driver).sendKeys("TC7_AG202_NC1"); 
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint2_RTB_TC9.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }   
             WebElement x=Account_NewCreate.fnd_savebtn(driver);
             x.click();
             
//Convert Lead to Opportunity//
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  
             All_Edit_Clone.fnd_ldconvrt(driver).click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC9.captureScreenShot(driver);
    
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Lead_Convert.typ_actytyp(driver).sendKeys("Call");
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  ;
             WebElement y=Lead_Convert.clk_ldcnrtbtn(driver);
             y.click();  
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC9.captureScreenShot(driver);
    
             
//New Competitor-Buttom click//  
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  ;
             WebElement q=All_Edit_Clone.fnd_opporcomac(driver);
             q.click(); 
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC9.captureScreenShot(driver);
//  Enter values in the field-Competitor Page//
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  ;
             Oppor_New_Competitor_Account.typ_coactnm(driver).sendKeys("TC7_Competitor");
             //Oppor_New_Competitor_Account.typ_coaccnm(driver).sendKeys("gggg");
            
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC9.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  ;
             WebElement r=Oppor_New_Competitor_Account.clk_ocomsv(driver);
             r.click(); 
  //Same entry getting added again//   
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  ;
             WebElement q1=All_Edit_Clone.fnd_opporcomac(driver);
             q1.click(); 
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC9.captureScreenShot(driver);

             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             Sprint2_RTB_TC9.captureScreenShot(driver);
             
             System.out.print("TC9 Successfull");            
    }
    
    
    
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint2_TC9/screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }         
       }
      
    
     }    
     