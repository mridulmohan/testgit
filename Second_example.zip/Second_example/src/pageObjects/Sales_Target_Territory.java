package pageObjects;
 
    import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class Sales_Target_Territory{ 
    private static WebElement element = null;
    
  //Page locators mainly in the Sales_Target_Territor page//
 //page which comes when 'New Sales target territory' is clicked on Sales plan page//
  //**MANDATORY FIELDS AND NON-MANDATORY FIRLDS INCLUDED ARE**//
    
 

  //SF portal_New Sales Target Territory Sales Target  type//    
    public static WebElement typ_sltgttytgt(WebDriver driver){ 
    	  element = driver.findElement(By.id("CF00N3E000000Wj9M"));
    	  return element;    	  
    }	
    
  //SF portal_New Sales Target TerritorySales //    
    public static WebElement typ_sltgttypln(WebDriver driver){ 
    	  element = driver.findElement(By.id("CF00N3E000000Wj9Q"));
    	  return element;    	  
    }	
    
  //SF portal_New Sales Target TerritoryTerritory//    
    public static WebElement typ_slttgtytty(WebDriver driver){ 
    	  element = driver.findElement(By.id("CF00N3E000000Wj9N"));
    	  return element;    	  
    }	
    
  //SF portal_New Sales Target Territory Currency//    
    public static WebElement sel_slttgttycrny(WebDriver driver){ 
    	  element = driver.findElement(By.id("CurrencyIsoCode"));
    	  return element;    	  
    }	
    
  //SF portal_New Sales Target TerritoryTerritory Amount//
    public static WebElement typ_slttgttyamnt(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N3E000000Wj9R"));
    	  return element;    	  
    }	
    
  //SF portal_New Sales Target TerritoryComment//
    public static WebElement typ_slttgttycmnt(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N3E000000Wj9S"));
    	  return element;    	  
    }	
    
  //SF portal_New Sales Target Territory Save//
    public static WebElement clk_slttgttysv(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='save']"));
    	  return element;    	  
    }	
    
  //SF portal_New Sales Target TerritoryCancel//
    public static WebElement clk_slttgttycncl(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='cancel']"));
    	  return element;    	  
    }	
}