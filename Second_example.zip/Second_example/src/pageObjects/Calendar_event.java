package pageObjects;
 
    import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class Calendar_event{ 
    private static WebElement element = null;
    
  //Page locators mainly in the NEW ACCOUNT CREATION page// 
  //**MANDATORY FIELDS AND NON-MANDATORY FIRLDS INCLUDED ARE**//
    /*
    Account name entry
    Account Group
  
    */

  //SF portal_Calendar event-Create follow up event//    
    public static WebElement clk_calevflevn(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='newEvent']"));
    			  return element;    	  
    }	
    
  //SF portal_Calendar event -Save//    
    public static WebElement clk_calevsv(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='save'"));
    	  return element;    	  
    }	
    
}