 package pageObjects;
 
import org.openqa.selenium.*; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement;
 
public class LoginPage {
 
        private static WebElement element = null;
 
 //SF Login page 'Username' field//
    public static WebElement txtbx_UserName(WebDriver driver){ 
         element = driver.findElement(By.id("username")); 
         return element; 
         }
 
//SF Login page 'Password' field//
     public static WebElement txtbx_Password(WebDriver driver){ 
         element = driver.findElement(By.id("password")); 
         return element; 
         }
 
//SF Login page 'Log In to Sandbox' buttom//
     public static WebElement btn_LogIn(WebDriver driver){ 
         element = driver.findElement(By.id("Login")); 
         return element; 
         }
     
 //SF Login page 'Forgot password link' link//
     public static WebElement lnk_frgthmpagepw(WebDriver driver){ 
         element = driver.findElement(By.id("forgot_password_link")); 
         return element; 
         }
     
//SF Login page 'Remember me' checkbox//
     public static WebElement chk_remembme(WebDriver driver){ 
         element = driver.findElement(By.id("rememberUn")); 
         return element; 
         }
 
}