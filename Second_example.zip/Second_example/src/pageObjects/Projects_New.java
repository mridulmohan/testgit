package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import java.util.List;

public class  Projects_New{ 
    private static WebElement element = null;
    
    
//All Mandatory and non-mandatory important parametrs Page objects for new Projects creation//  
//This section includes//
    /*
     1.Project Name
     2.Project Type
     3.Location
     4.Relationship Type
     5.Start Date
     6.End Date
     7.Information Source
     8.Description
     Mark for delete check-box
     Mark for delete reason
     9.Save
     10.Cancel
     */

//SF portal_Leads New page_Project name type//    
  public static WebElement typ_prname(WebDriver driver){ 
	  element = driver.findElement(By.id("Name"));
    return element; 
    }
  
//SF portal_Leads New page_Project Type type//    
  public static WebElement sel_prtyp(WebDriver driver){ 
	  element = driver.findElement(By.id("00N5800000BMXLY"));
    return element; 
    }
  
//SF portal_Leads New page_Project Location type//    
  public static WebElement sel_prloc(WebDriver driver){ 
	  element = driver.findElement(By.id("00N5800000BMXLZ"));
    return element; 
    }
  
//SF portal_Leads New page_Relationship Type//    
  public static WebElement sel_prreltyp(WebDriver driver){ 
	  element = driver.findElement(By.id("00N5800000BMXLX"));
    return element; 
    }
  
//SF portal_Leads New page_Start Date//    
  public static WebElement sel_prstdt(WebDriver driver){ 
	  element = driver.findElement(By.id("00N5800000BMWJn"));
    return element; 
    }
  
//SF portal_Leads New page_End date type//    
  public static WebElement sel_prenddt(WebDriver driver){ 
	  element = driver.findElement(By.id("00N5800000BMWJl"));
    return element; 
    }
  
//SF portal_Leads New page_Information source type//    
  public static WebElement typ_prinfos(WebDriver driver){ 
	  element = driver.findElement(By.id("00N5800000BMWJm"));
    return element; 
    }
  
//SF portal_Leads New page_Description type//    
  public static WebElement typ_prdesc(WebDriver driver){ 
	  element = driver.findElement(By.id("00N5800000BMWJjEAP_rta_body"));
    return element; 
    }
  
//SF portal_Project New Mark for Delete click//    
  public static WebElement clk_promkdel(WebDriver driver){ 
	  element = driver.findElement(By.id("00N3E000000XH5J"));
    return element; 
    }
  
//SF portal_Project mark for delete reason type//    
  public static WebElement typ_promkdelrsn(WebDriver driver){ 
	  element = driver.findElement(By.id("00N3E000000XH5K"));
    return element; 
    }
  
  
//SF portal_Leads New page_Save Button type//    
  public static WebElement clk_prsv(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//*[@name='save']"));
    return element; 
    }
  
//SF portal_Leads New page_Cancel type//    
  public static WebElement typ_leadfname(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//*[@name='cancel']"));
    return element; 
    }
}
  