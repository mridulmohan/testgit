package pageObjects;
 
    import java.util.concurrent.TimeUnit;

    import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class AccountsPage { 
    private static WebElement element = null;
    
//Page locators mainly in the Accounts page//    

//SF portal_Accountspage_New button click//    
public static WebElement fnd_recentaccount(WebDriver driver){ 
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h3[text()='Recent Accounts']"));
    	//System.out.println("After finding title");
    return element;       
    }

//SF portal_Contactpage_New button click// 
public static WebElement fnd_recentcontact(WebDriver driver){ 
	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h3[text()='Recent Contacts']"));
	//System.out.println("After finding title");
return element;       
}

//SF portal_Leadspage_New button click// 
public static WebElement fnd_recentleads(WebDriver driver){ 
	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h3[text()='Recent Leads']"));
	//System.out.println("After finding title");
return element;       
}

//SF portal_Oppourtunitiespage_New button click// 
public static WebElement fnd_recentoppurtunities(WebDriver driver){ 
	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h3[text()='Recent Opportunities']"));
	//System.out.println("After finding title");
return element;       
}

//Click Recent Competitor Accounts//
public static WebElement fnd_compacct(WebDriver driver){ 
	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h3[text()='Recent Competitor Accounts']"));
	//System.out.println("After finding title");
return element;       
}


//Click recent projects//
public static WebElement fnd_recentprojects(WebDriver driver){ 	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h3[text()='Recent Projects']"));
	//System.out.println("After finding title");
return element;       
}


//Click recent Sales plan//
public static WebElement fnd_recentslplans(WebDriver driver){ 	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h3[text()='Recent Sales Plans']"));
	//System.out.println("After finding title");
return element;       
}


//Click recent Sales targets//
public static WebElement fnd_recentsltgts(WebDriver driver){ 	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h3[text()='Recent Sales Targets']"));
	//System.out.println("After finding title");
return element;       
}

//Click recent Sales Territory//
public static WebElement fnd_recentsltrty(WebDriver driver){ 	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h3[text()='Recent Territories']"));
	//System.out.println("After finding title");
return element;       
}


//Click Account_New button//
public static WebElement clk_nwbtn(WebDriver driver){
	element = driver.findElement(By.xpath(".//input[@name='new']")); 
    return element; 
    
     
}
 
}