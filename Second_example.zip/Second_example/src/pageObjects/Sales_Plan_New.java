package pageObjects;
 
    import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class Sales_Plan_New { 
    private static WebElement element = null;
    
  //Page locators mainly in the NEW SALES PLAN CREATION page// 
  //**MANDATORY FIELDS AND NON-MANDATORY FIRLDS INCLUDED ARE**//
    /*
Sales Plan Name
Sales Target
Sales Plan Target
Direct Contribution
Currency
Total Expected Revenue
Current Financial Year
January Revenue
February Revenue
March Revenue
April Revenue
May Revenue
June Revenue
July Revenue
August Revenue
September Revenue
October Revenue
November Revenue
December Revenue
Save
Cancel
    */

  //SF portal_Sales  Plan Name//    
    public static WebElement typ_slplnnme(WebDriver driver){ 
    	  element = driver.findElement(By.id("Name"));
    	  return element;    	  
    }
    
  //SF portal_Sales Plan_Sales Target //    
    public static WebElement typ_slplntgt(WebDriver driver){ 
    	  element = driver.findElement(By.id("CF00N3E000000WW0l"));
    	  return element;     
    }
    
  //SF portal_Sales Plan-Direct Contribution//    
    public static WebElement typ_slplndircont(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N3E000000WoPo"));
    	  return element;     
    }  
    
    //SF portal_Sales Plan Currency//    
    public static WebElement typ_slplncrncy(WebDriver driver){ 
    	  element = driver.findElement(By.id("CurrencyIsoCode"));
    	  return element;     
    }  
        
  
  //SF portal_Sales Plan jan  reve//    
    public static WebElement typ_slplnjanrev(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N3E000000W7Ji"));
    	  return element;     
    }  
    
    //SF portal_Sales Plan feb  revenue//    
    public static WebElement typ_slplnfebrev(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7Jg"));
  	  return element;     
  } 
    
    //SF portal_Sales Plan march revenue//    
    public static WebElement typ_slplnmarrev(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7Jn"));
  	  return element;     
  }  
    
    //SF portal_Sales plan April revenue//    
    public static WebElement typ_slplnaprrev(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7JZ"));
  	  return element;     
  } 
    
    //SF portal_Sales Plan may  revenue//    
    public static WebElement typ_slplnmayrev(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7Jp"));
  	  return element;     
  }  
    
    //SF portal_Sales Plan June  revenue//    
    public static WebElement typ_slplnjunrev(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7Jl"));
  	  return element;     
  }  
    
    //SF portal_Sales Plan July revenue//    
    public static WebElement typ_slplnjulyrev(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7Jk"));
  	  return element;     
  }  
    
    //SF portal_Sales Plan Aug revenue//    
    public static WebElement typ_slplnaugrev(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7Jb"));
  	  return element;     
  }  
    
    //SF portal_Sales Plan Sep  revenue//    
    public static WebElement typ_slplnseprev(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7Jz"));
  	  return element;     
  } 
    
    //SF portal_Sales plan Oct  revenue//    
    public static WebElement typ_slplnoctrev(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7Jt"));
  	  return element;     
  } 
    
    //SF portal_Sales plan Nov  revenue//    
    public static WebElement typ_slplnnovrev(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7Jr"));
  	  return element;     
  }  
    
    //SF portal_Sales plan Dec  revenue//    
    public static WebElement typ_slplndecrev(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7Je"));
  	  return element;     
  } 
    
    //SF portal_Sales plan Comments//    
    public static WebElement typ_slplncmnts(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000WTPn"));
  	  return element;     
  } 
    
  //SF portal_Sales Plan Save button//    
    public static WebElement clk_slplnsv(WebDriver driver){ 
  	  element = driver.findElement(By.xpath(".//input[@name='save']"));
  	  return element;     
  } 
    
    //SF portal_Sales Plan Cancel btn//    
    public static WebElement clk_slplncnl(WebDriver driver){ 
  	  element = driver.findElement(By.xpath(".//input[@name='cancel']"));
  	  return element;     
  }   
    
    
}