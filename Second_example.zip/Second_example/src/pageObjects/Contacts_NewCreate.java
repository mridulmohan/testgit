package pageObjects;
 
    import java.util.concurrent.TimeUnit;
    import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class Contacts_NewCreate { 
    private static WebElement element = null;
    
  //Page locators mainly in the NEW CONTACT CREATION page// 
  //**MANDATORY FIELDS AND NON-MANDATORY FIRLDS INCLUDED ARE**//
    /*
    Drop Down_Fname
	First name
	Lastname
	Mobile
	E-Mail
	Account Name
	Mailing Street
	Mailing City
	Mailing State/Province
	Mailing/Postal Code
	Mailing Country
    */

  //SF portal_Contactsspage_NEW_Firstname  type//    
    public static WebElement typ_cntfname(WebDriver driver){ 
    	  element = driver.findElement(By.id("name_firstcon2"));
    	  return element;    	  
    }	
    
    //SF portal_Contactsspage_NEW_Lastname  type//    
    public static WebElement typ_cntlname(WebDriver driver){ 
    element = driver.findElement(By.id("name_lastcon2"));
    return element;
    }
    
  //SF portal_Contactsspage_NEW_Mobilenumber  type//  
    public static WebElement typ_cntmobno(WebDriver driver){ 
    element = driver.findElement(By.id("con12"));
    return element;
    }
    
  //SF portal_Contactsspage_NEW_Email  type//     
    public static WebElement typ_cntemail(WebDriver driver){ 
    element = driver.findElement(By.id("con15"));
    return element;
    }      

    //SF portal_Contactsspage_NEW_Mailing Street  type//       
    public static WebElement typ_cntmailstreet(WebDriver driver){ 
    element = driver.findElement(By.id("con19street"));
    return element;
    } 
        
  //SF portal_Contactsspage_NEW_Mailing City  type//          
    public static WebElement typ_cntmailcty(WebDriver driver){ 
    element = driver.findElement(By.id("con19city"));
    return element;
    }     
    
  //SF portal_Contactsspage_NEW_Mailing State  type//          
    public static WebElement typ_cntmailstate(WebDriver driver){ 
    element = driver.findElement(By.id("con19state"));
    return element;
    } 
    
    
  //SF portal_Contactsspage_NEW_Mailing Postal Code  type//          
    public static WebElement typ_cntmailpcode(WebDriver driver){ 
    element = driver.findElement(By.id("con19zip"));
    return element;
    }   
    
    
  //SF portal_Contactsspage_NEW_Mailing Country  type//          
    public static WebElement typ_cntmailctry(WebDriver driver){ 
    element = driver.findElement(By.id("con19country"));
    return element;
    } 
    
    
//SF portal_Contactsspage_NEW_Firstname_dropdown_Arrow click  type//          
    public static WebElement clk_cntfnamedrpdwn(WebDriver driver){ 
    element = driver.findElement(By.id("name_salutationcon2"));
    return element;
    } 
    
//SF portal_Contactsspage_NEW_Salutation click  type//          
    public static WebElement typ_cntSaltn(WebDriver driver){ 
    element = driver.findElement(By.id("00N5800000BM3dr"));
    return element;
    }  

 //SF portal_Contactsspage_NEW_Job Title click  type//          
    public static WebElement typ_cntjbtle(WebDriver driver){ 
    element = driver.findElement(By.id("con5"));
    return element;
    }    
    
  //SF portal_Contactsspage_NEW_Position click  type//          
    public static WebElement typ_cntpostn(WebDriver driver){ 
    element = driver.findElement(By.id("00N5800000BM3dp"));
    return element;
    }    
 
 //SF portal_Contactsspage_NEW_Phone no click  type//          
    public static WebElement typ_cntphno(WebDriver driver){ 
    element = driver.findElement(By.id("con10"));
    return element;
    }

//SF portal_Contactsspage_NEW_Account name click  type//          
    public static WebElement typ_cntaccno(WebDriver driver){ 
    element = driver.findElement(By.id("con4"));
    return element;
    }
 
//SF portal_Contactsspage_NEW_Language click  type//          
      public static WebElement sel_cntlang(WebDriver driver){ 
      element = driver.findElement(By.id("00N5800000BM3dk"));
      return element;
      }
      
//SF portal_Contactsspage_NEW_Segment click  type//          
      public static WebElement sel_cntseg(WebDriver driver){ 
      element = driver.findElement(By.id("00N5800000BM3dm"));
      return element;
      }
 
 //SF portal_Contactsspage_NEW_Product Family type//          
      public static WebElement sel_cntprdfly(WebDriver driver){ 
      element = driver.findElement(By.id("00N5800000BM3dl"));
      return element;
      }
 
 //SF portal_Contactsspage_NEW_Influence type//          
      public static WebElement sel_cntinfl(WebDriver driver){ 
      element = driver.findElement(By.id("00N5800000BM3dn"));
      return element;
      }
 
//SF portal_Contactsspage_NEW_Preferred Contact Method//          
      public static WebElement sel_cntpfcntmtd(WebDriver driver){ 
      element = driver.findElement(By.id("00N5800000BM3dq"));
      return element;
      }
 
//SF portal_Contactsspage_NEW_Lead Source Method//          
      public static WebElement sel_cntldsrc(WebDriver driver){ 
      element = driver.findElement(By.id("con9"));
      return element;
      }
      
}

    
    
    
    