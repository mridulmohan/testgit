package pageObjects;
 
    import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class  Reports_New{ 
    private static WebElement element = null;
    
//4 main sections involved-Contacts,Accounts,Leads,Opportunities//  
//Drop down for Sales_force logout and profile settings//

//SF portal_Homepage_Accounts section//    
  public static WebElement typ_repsrch(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//*[@id='listview_wrapper']//*[@id='listview_subNav']//*[@id='listview_search']//*[@id='ext-comp-1013']"));
    return element; 
    }
  
//SF portal_reports contacts section//    
  public static WebElement clk_rptfst(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//span[contains(text(),'Marked For Delete - Contacts')]"));
    return element; 
    } 
  
//SF portal_reports accounts section//    
  public static WebElement clk_actrept(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//span[contains(text(),'Marked For Delete - Accounts')]"));
    return element; 
    } 
  
//SF portal_reports opportunities section//    
  public static WebElement clk_opprept(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//span[contains(text(),'Marked For Delete - Opportunities')]"));
    return element; 
    }  
  
//SF portal_reports Projects section//    
  public static WebElement clk_prorept(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//span[contains(text(),'Marked For Delete - Projects')]"));
    return element; 
    }
  
//SF portal_reports Projects section//    
  public static WebElement clk_leadrept(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//span[contains(text(),'Marked For Delete - Leads')]"));
    return element; 
    }  
  
  
  
}
