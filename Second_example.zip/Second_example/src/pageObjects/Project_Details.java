package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
//import java.lang.object;

public class Project_Details { 
    private static WebElement element = null;
    //public  WebElement element = null;
    //private static WebDriver driver=null;
  //WebElement tabs=driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:criteria']//td[@class='pbTitle']/h2[text()='Search']"));  
  
//All Mandatory and non-mandatory important parameters Page objects for  Projects details page//  
//This section includes//
    /*
     1.Name Search
     2.Account Search
     3.Save selections
     */

//Find search button//
    
    public static WebElement fnd_tabsearch(WebDriver driver){ 
  	 element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:criteria']//td[@class='pbTitle']/h2[text()='Search']"));
      return element; 
    	
    	//if(tabs.isDisplayed()){
    		//tabs.clear();
    		//tabs.click();
    	
         }
     
//SF portal_Leads New page_name search type//    
  public static WebElement typ_prdetnm(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:criteria']//*[@id='nameSearchValue']"));
    return element; 
    }
  
//SF portal_Leads New page_Account type//    
  public static WebElement typ_prdetacnm(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//*[@id='companySearchValue']"));
	  	  	  return element;     
    }
  
  //JavascriptExecutor�jse�=�(JavascriptExecutor)�driver;�//  
  /*
   * public static List<WebElement> fulldocument(WebDriver driver){
	  //JavascriptExecutor�jse�=�(JavascriptExecutor)�driver;
	  //List<WebElement> full = (List<WebElement>)jse.executeAsyncScript("return document.getElementsByTagName('*')"); 
	  	  //List<WebElement> full=driver.findElements(By.tagName("INPUT"));
	 // System.out.println("The full content count is"+ full.size());
	 // return full;
  	*/  
	  
  
  
//SF portal_Leads New page_Save type//    
  public static WebElement clk_prdetsv(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:criteria']//*[@id='j_id0:j_id4:criteria:j_id12']"));
    return element; 
  }
  
//Opport-1st master//

   
    public static WebElement clk_opp1ms(WebDriver driver){ 
  	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:oppProspectResults:j_id51:0:j_id52']/input[@name='j_id0:j_id4:oppProspectResults:j_id51:0:j_id54']"));
      return element; 
    }
//Oppor-2nd master//
    public static WebElement clk_opp2ms(WebDriver driver){ 
    	element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:oppProspectResults:j_id51:1:j_id52']/input[@name='j_id0:j_id4:oppProspectResults:j_id51:1:j_id54']"));
        return element; 
      }  
    
//Oppor-1row-Add to project//
    public static WebElement clk_opp1add(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:oppProspectResults:j_id51:0:j_id55']/input[@name='j_id0:j_id4:oppProspectResults:j_id51:0:j_id57']"));
        return element; 
      } 
//Oppor-2nd-Add to projects//
    public static WebElement clk_opp2add(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:oppProspectResults:j_id51:1:j_id55']/input[@name='j_id0:j_id4:oppProspectResults:j_id51:1:j_id57']"));
        return element; 
      }
    
//Leads-1st add to proj//
    public static WebElement clk_ld1add(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:leadProspectResults:j_id73:0:j_id74']/input[@name='j_id0:j_id4:leadProspectResults:j_id73:0:j_id76']"));
        return element; 
      }
//Leads-2nd add to proj//    
    public static WebElement clk_ld2add(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:leadProspectResults:j_id73:1:j_id74']/input[@name='j_id0:j_id4:leadProspectResults:j_id73:1:j_id76']"));
        return element; 
      }
    
    
  
  }