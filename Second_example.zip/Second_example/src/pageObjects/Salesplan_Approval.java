package pageObjects;
 
    import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class Salesplan_Approval { 
    private static WebElement element = null;
    
  //Page locators mainly in the Adding -Account Sales Plan to an Sales Plan-Approval/Reject//
//Approve
    //Reject
    //reason

  //SF portal_Acc Sales Plan -Approve  clk//    
    public static WebElement clk_approve(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='goNext']"));
    	  return element;   
    	
    }	
    
    //SF portal_Acc Sales Plan -Reject  clk//    
    public static WebElement clk_reject(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='Reject']"));
    	  return element;   
    	
    }	

    
    //SF portal_Acc Sales Plan -Reason  clk//    
    public static WebElement typ_reason(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='Comments']"));
    	  return element;   
    	
    }	

}
