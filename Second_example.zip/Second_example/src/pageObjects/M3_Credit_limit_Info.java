 package pageObjects;
 
import org.openqa.selenium.*; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement;
 
public class M3_Credit_limit_Info {
 
        private static WebElement element = null;
 
 //SF M3 Payment method accounts receivable field//
    public static WebElement fnd_accreceiv(WebDriver driver){ 
         element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:CreditLimitBlock:j_id33:0:j_id68']/div[2]/table/tbody/tr/td[2]/label")); 
         return element; 
         }
    
    
  //SF M3 -Credit Limit Info-Currency//
    public static WebElement fnd_currency(WebDriver driver){ 
         element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:CreditLimitBlock:j_id33:0:j_id43']/div[2]/table/tbody/tr[1]/td[2]/label")); 
         return element; 
         }    
}