package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class  Leads_NewCreate{ 
    private static WebElement element = null;
    
    
//All Mandatory and non-mandatory important parametrs Page objects for new leads creation//  
//This section includes//
    /*
     Fname_Drop Down
	First Name
	Last Name
	Aggreko Location
	Mobile
	Email
	New Company
	Lead Status
	Lead Source
	Product-Family type
	Right Arrow
	Street
	City
	State Province
	Zip Code
	Country
	Save
     */

//SF portal_Leads New page_First Name type//    
  public static WebElement typ_leadfname(WebDriver driver){ 
	  element = driver.findElement(By.id("name_firstlea2"));
    return element; 
    }
  
//SF portal_Leads New page_Last Name type//    
  public static WebElement typ_leadlname(WebDriver driver){ 
	  element = driver.findElement(By.id("name_lastlea2"));
    return element; 
    }
  
//SF portal_Leads New page_Mobile type//    
  public static WebElement typ_leadmobno(WebDriver driver){ 
	  element = driver.findElement(By.id("lea9"));
    return element; 
    } 
  
//SF portal_Leads New page_Phone type//    
  public static WebElement typ_leadphone(WebDriver driver){ 
	  element = driver.findElement(By.id("lea8"));
    return element; 
    } 
  
//SF portal_Leads New page_Aggreko location type//    
  public static WebElement sel_ldaggloc(WebDriver driver){ 
	  element = driver.findElement(By.id("00N5800000BNJ2i"));
    return element; 
    } 
    
//SF portal_Leads New page_Email type//    
  public static WebElement typ_leademail(WebDriver driver){ 
	  element = driver.findElement(By.id("lea11"));
    return element; 
    } 
  
//SF portal_Leads New page_New Company type//    
  public static WebElement typ_leadncmpny(WebDriver driver){ 
	  element = driver.findElement(By.id("lea3"));
    return element; 
    } 
  
//SF portal_Leads New page_Mark for Delete//    
  public static WebElement clk_ldmkdel(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//input[@name='00N3E000000XGJ7']"));
    return element; 
    } 
  
  
//SF portal_Leads New page_Mark for Delete//    
  public static WebElement typ_ldmkdelrsn(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//*[@id='00N3E000000XGJ8']"));
    return element; 
    } 
  
    
//SF portal_Leads New page_New Street type//    
  public static WebElement typ_leadstreet(WebDriver driver){ 
	  element = driver.findElement(By.id("lea16street"));
    return element; 
    }  
  
//SF portal_Leads New page_New City type//    
  public static WebElement typ_leadcty(WebDriver driver){ 
	  element = driver.findElement(By.id("lea16city"));
    return element; 
    }  
  
//SF portal_Leads New page_New State type//    
  public static WebElement typ_leadstate(WebDriver driver){ 
	  element = driver.findElement(By.id("lea16state"));
    return element; 
    }  
  
//SF portal_Leads New page_New zipcode type//    
  public static WebElement typ_leadpcode(WebDriver driver){ 
	  element = driver.findElement(By.id("lea16zip"));
    return element; 
    }
   
  
//SF portal_Leads New page_New Country type//    
  public static WebElement typ_leadctry(WebDriver driver){ 
	  element = driver.findElement(By.id("lea16country"));
    return element; 
    }
   
//SF portal_Leads New page_Salutation dropdown type//  
  public static WebElement sel_fnameddwn(WebDriver driver){ 
	 element=driver.findElement(By.id("name_salutationlea2"));
	  //System.out.println("After identifying the drop down");
	  //Delement.selectByValue("Prof");
      return element; 
    }
  
//SF portal_Leads New page_Productfamily type type//  
  public static WebElement ldsel_prdfly(WebDriver driver){ 
	 element=driver.findElement(By.id("00N4E000000m1zB_unselected"));
	  //System.out.println("After identifying the drop down");
	  //Delement.selectByValue("Prof");
      return element; 
  }   
      
//SF portal_Leads New page_Productfamily Right button type//  
  public static WebElement ldsel_prdflyrbt(WebDriver driver){ 
	 element=driver.findElement(By.xpath(".//a[@title='Add']"));
	  //System.out.println("After identifying the drop down");
	  //Delement.selectByValue("Prof");
      return element; 
  }  
      
//SF portal_Leads New page_Lead Status Select type//  
  public static WebElement sel_leadstatus(WebDriver driver){ 
	 element=driver.findElement(By.id("lea13"));
	  //System.out.println("After identifying the drop down");
	  //Delement.selectByValue("Prof");
      return element;      
}
  
//SF portal_Leads New page_Lead Source Select type//  
  public static WebElement sel_leadsource(WebDriver driver){ 
	 element=driver.findElement(By.id("lea5"));
	  //System.out.println("After identifying the drop down");
	  //Delement.selectByValue("Prof");
      return element;
  } 
  
//SF portal_Leads New page_Lead AIC type//  
  public static WebElement sel_leadaic(WebDriver driver){ 
	 element=driver.findElement(By.id("00N5800000BM3dx"));
	  //System.out.println("After identifying the drop down");
	  //Delement.selectByValue("Prof");
      return element;
  }   
  
   
//SF portal_Leads New page_website type//  
  public static WebElement typ_leadwebsite(WebDriver driver){ 
	 element=driver.findElement(By.id("lea12"));
	  //System.out.println("After identifying the drop down");
	  //Delement.selectByValue("Prof");
      return element;
  } 
  
//SF portal_Leads New page_On hold reason type//  
  public static WebElement typ_leadonhldrsn(WebDriver driver){ 
	 element=driver.findElement(By.id("00N5800000BM3e4"));
	  //System.out.println("After identifying the drop down");
	  //Delement.selectByValue("Prof");
      return element;
  } 
 
//SF portal_Leads New page_On hold End Date type//  
  public static WebElement sel_leadonhlddat(WebDriver driver){ 
	 element=driver.findElement(By.id("00N5800000BM3e3"));
	  //System.out.println("After identifying the drop down");
	  //Delement.selectByValue("Prof");
      return element;
  }
  
  
//SF portal_Leads New page_Lead type--Sendkeys//  
  public static WebElement typ_leadtype(WebDriver driver){ 
	 element=driver.findElement(By.id("00N5800000BM3dz"));
	  //System.out.println("After identifying the drop down");
	  //Delement.selectByValue("Prof");
      return element;
  } 
  
}