package pageObjects;
 
    import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class  Opportunity_NewCreate{ 
    private static WebElement element = null;
    
//All mandatory and important non mandatory fields for Opportunities creation//
//This includes the below sections//
    /*
    Opportunity Name
	Account Name
	Close Date
	Stage
	Product family
	Product family options
	Right arrow
	Lead Source drop down
	On Hire date
	Off hire date
     */
    

//SF portal_Opporpage_New section//    
  public static WebElement typ_opporname(WebDriver driver){ 
	  element = driver.findElement(By.id("opp3"));
    return element; 
    }
 
//SF portal_Opporpage_Accountname section//    
  public static WebElement typ_opporacname(WebDriver driver){ 
	  element = driver.findElement(By.id("opp4"));
    return element; 
  } 
  
//SF portal_Opporpage_Opportunity Currency section//    
  public static WebElement sel_opporcuurency(WebDriver driver){ 
	  element = driver.findElement(By.id("opp16"));
    return element; 
  } 
  
//SF portal_Opporpage_Opportunity Amount section//    
  public static WebElement typ_opporamnt(WebDriver driver){ 
	  element = driver.findElement(By.id("opp7"));
    return element; 
  } 
    
 //SF portal_Opporpage_Closedate section//    
    public static WebElement typ_opporcdate(WebDriver driver){ 
  	  element = driver.findElement(By.id("opp9"));
      return element; 
    }
    
//SF portal_Opporpage_Stage section//    
    public static WebElement sel_opporstage(WebDriver driver){ 
  	  element = driver.findElement(By.id("opp11"));
      return element; 
    }
    
  //SF portal_Opporpage_Stage section//    
    public static WebElement get_opporprob(WebDriver driver){ 
  	  element = driver.findElement(By.id("opp12"));
      return element; 
    }
    
//SF portal_Opporpage_Proposal Number section//    
    public static WebElement typ_opporpronum(WebDriver driver){ 
  	  element = driver.findElement(By.xpath(".//input[@name='00N5800000BM3eG']"));
      return element; 
    }  
    
//SF portal_Opporpage_Agreement Number section//    
    public static WebElement typ_opporagrnum(WebDriver driver){ 
  	  element = driver.findElement(By.xpath(".//input[@name='00N5800000BM3e6']"));
      return element; 
    }       
            
 //SF portal_Opporpage_Onhire date section//    
      public static WebElement typ_opporonhdate(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='00N5800000BM3eB']"));
    	  return element; 
      }

    	  //SF portal_Opporpage_Offhire date section//    
   public static WebElement typ_opporoffhdate(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='00N5800000BM3eA']"));
    	  return element;          
    
   }
  
 //SF portal_Opporpage_Product Family section// 
   public static WebElement sel_opporprdfly(WebDriver driver){ 
		 element=driver.findElement(By.id("00N5800000BM3eE_unselected"));
			 		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  }   
 //SF portal_Opporpage_Lead Source drop down section// 
   public static WebElement sel_opporldsrc(WebDriver driver){ 
		 element=driver.findElement(By.id("opp6"));
		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  }
   //SF portal_Opporpage_Lead Source Next Step section// 
   public static WebElement typ_oppornxtstp(WebDriver driver){ 
		 element=driver.findElement(By.id("opp10"));
		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  }
   
   //SF portal_Opporpage_Proposal needed checkbox section// 
   public static WebElement clk_propneeded(WebDriver driver){ 
		 element=driver.findElement(By.id("00N5800000BMWKB"));
		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  }   
   
 //SF portal_Opporpage_Lead Source Lead Campaign section// 
   public static WebElement typ_opporldcmpgn(WebDriver driver){ 
		 element=driver.findElement(By.id("opp17"));
		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  }
   
//SF portal_Opporpage_Lead Source Reason Won section// 
   public static WebElement sel_opporreawon(WebDriver driver){ 
		 element=driver.findElement(By.id("00N5800000BMWKD"));
		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  }
   
//SF portal_Opporpage_Lead Source Reason lost section// 
   public static WebElement sel_opporrealst(WebDriver driver){ 
		 element=driver.findElement(By.id("00N5800000BMWKC"));
		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  } 
  
 //SF portal_Opporpage_Lead Is Competing Authority Checkbox // 
   public static WebElement clk_comaut(WebDriver driver){ 
		 element=driver.findElement(By.id("00N5800000BMWK3"));
		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  } 
   
//SF portal_Opporpage_Lead Comeptitor Account // 
   public static WebElement typ_comact(WebDriver driver){ 
		 element=driver.findElement(By.id("CF00N5800000BMWK4"));
		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  }     
   
 //SF portal_Opporpage_Lead Other Competitor section// 
   public static WebElement typ_opporotcom(WebDriver driver){ 
		 element=driver.findElement(By.id("00N5800000BMWK7"));
		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  }
   
 //SF portal_Seacr Oppor edit-Temp only-To be handled in tables// 
   public static WebElement clk_opporsrcedit(WebDriver driver){ 
		 element=driver.findElement(By.xpath(".//*[@id='searchBody']/div[2]/div[1]/*[@id='Opportunity']/div[2]/div[1]/div[2]//td[1]/a[@title='Edit - Record 1 - TC6_Op_Name_1019']"));
		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  }
   
   //SF portal_Seacr Oppor edit-Mark for delete// 
   public static WebElement clk_oppmkdel(WebDriver driver){ 
		 element=driver.findElement(By.xpath(".//*[@id='00N3E000000XH5L']"));
		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  }
   
   
   //SF portal_Seacr Oppor edit-Mark for delete-reason// 
   public static WebElement typ_oppmkdlreason(WebDriver driver){ 
		 element=driver.findElement(By.xpath(".//*[@id='00N3E000000XH5M']"));
		  //System.out.println("After identifying the drop down");
		  //Delement.selectByValue("Prof");
	      return element; 
	  }
   
   
   
   
   
   
 
}