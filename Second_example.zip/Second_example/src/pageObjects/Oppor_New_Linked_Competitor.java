package pageObjects;
 
    import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class  Oppor_New_Linked_Competitor
{ 
    private static WebElement element = null;
    
//All mandatory and important non mandatory fields for Create Competitor//
//This includes the below sections//
    /*
     Competitor Account Name
	Account
	Location
	Currency
	Save button 
	Cancel button

     */
 
    
//SF portal_OpporNew link comp-Opportunity//     
      public static WebElement typ_nlactnm(WebDriver driver){ 
    	  element = driver.findElement(By.id("CF00N5800000BMWJc"));
        return element;
      }
      
//SF portal_OpporNew link-Competitor Account//     
      public static WebElement typ_nlaccact(WebDriver driver){ 
    	  element = driver.findElement(By.id("CF00N5800000BMWJa"));
        return element;
      }
           
 //SF portal_Oppornew-Other Competitor//     
      public static WebElement typ_nlotcmp(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N5800000BMWJi"));
        return element;
      }
      
      
 //SF portal_Currency//     
      public static WebElement sel_nlaccrncy(WebDriver driver){ 
    	  element = driver.findElement(By.id("CurrencyIsoCode"));
        return element;
      }
      
 //SF portal_Save button//     
      public static WebElement clk_nlacsv(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='save']"));
        return element;
      }
      
 //SF portal_Cancel button//     
      public static WebElement clk_nlaccnl(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='cancel']"));
        return element;
      }
                
            
      
}
