package pageObjects;
 
    import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class Account_NewCreate { 
    private static WebElement element = null;
    
  //Page locators mainly in the NEW ACCOUNT CREATION page// 
  //**MANDATORY FIELDS AND NON-MANDATORY FIRLDS INCLUDED ARE**//
    /*
    Account name entry
    Account Group
    Aggreko Location
    Account Status
    Website
    VAT Number
    Primary Phone
    AIC
    Segment
    Accounttype
    Account Number
    Primary contact
    Physical Street 
    Physical City
    Physical State
    Physical Postal code
    Physical Country
    M3 customer number
    Save
    Save&New
    Cancel
    New Opportunity
    mark for delete check box
    mark for delete reason

    */

  //SF portal_Accountspage_NEW_accountname_entry  type//    
    public static WebElement typ_actname(WebDriver driver){ 
    	  element = driver.findElement(By.id("acc2"));
    	  return element;    	  
    }	
    
 //SF portal_Accountspage_NEW_Account Group_entry  type//    
    public static WebElement sel_actgrp(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N5800000BM3d7"));
    	  return element;    
    }	
    
//SF portal_Accountspage_NEW_Aggrekko Location_entry  type//    
    public static WebElement sel_aggloc(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N3E000000X84q"));
    	  return element;    
    }
      
  //SF portal_Accountspage_NEW_Account Status_entry  type//    
    public static WebElement sel_actst(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N5800000BM3dB"));
    	  return element;    
    }  
    
//SF portal_Accountspage_NEW_Website_entry  type//    
    public static WebElement typ_actwsite(WebDriver driver){ 
    	  element = driver.findElement(By.id("acc12"));
    	  return element;    
    }
    
//SF portal_Accountspage_NEW_VAT Number_entry  type//    
    public static WebElement typ_actvatnm(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N5800000BM3dN"));
    	  return element;    
    }  
    
 //SF portal_Accountspage_NEW_Primary Phone_entry  type//    
    public static WebElement typ_actprimphno(WebDriver driver){ 
    	  element = driver.findElement(By.id("acc10"));
    	  return element;    
    }  
    
 //SF portal_Accountspage_NEW_AIC_entry  type//    
    public static WebElement sel_actaic(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N5800000BM3dE"));
    	  return element;    
    } 

 //SF portal_Accountspage_NEW_Account Number  type//    
    public static WebElement typ_acnum(WebDriver driver){ 
    	  element = driver.findElement(By.id("acc5"));
    	  return element;    
    }   
    
//SF portal_Accountspage_NEW_Parent Account  type//    
    public static WebElement typ_parenac(WebDriver driver){ 
    	  element = driver.findElement(By.id("acc3"));
    	  return element;    
    }   
       
  //SF portal_Accountspage_NEW_Primary Contact  type//    
    public static WebElement typ_acpricon(WebDriver driver){ 
    	  element = driver.findElement(By.id("CF00N5800000BM3dJ"));
    	  return element;    
    }     
        
//SF portal_Accountspage_NEW_Segment  type//    
    public static WebElement typ_acsegmnt(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N5800000BM3dA"));
    	  return element;    
    }  
    
 //SF portal_Accountspage_NEW_Language drppdwn click and select type//    
    public static WebElement clk_aclngdrpdn(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N5800000BM3d8"));
    	  return element;    
    }  
    
//SF portal_Accountspage_NEW_M3 customer number//    
    public static WebElement typ_m3cust(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N3E000000WHpK"));
    	  return element;    
    }    
 
    
 //SF portal_Accountspage_NEW_Physical Street  type//    
    public static WebElement typ_acPhyst(WebDriver driver){ 
    element = driver.findElement(By.id("acc17street"));
    return element;
    }
    
  //SF portal_Accountspage_NEW_Physical City  type//    
    public static WebElement typ_acPhycty(WebDriver driver){ 
    element = driver.findElement(By.id("acc17city"));
    return element;
    }
    
  //SF portal_Accountspage_NEW_Physical State/Province  type//    
    public static WebElement typ_acPhystate(WebDriver driver){ 
    element = driver.findElement(By.id("acc17state"));
    return element;
    }  
    
  //SF portal_Accountspage_NEW_Physical Zip/Postal Code  type//    
    public static WebElement typ_acPhyzipcode(WebDriver driver){ 
    element = driver.findElement(By.id("acc17zip"));
    return element;
    } 
    
    
  //SF portal_Accountspage_NEW_Physical Country  type//    
    public static WebElement typ_acPhyctry(WebDriver driver){ 
    element = driver.findElement(By.id("acc17country"));
    return element;
    } 
    
    //SF portal_Accountspage_NEW_mark for delete checkbox//    
    public static WebElement clk_accmkdel(WebDriver driver){ 
    element = driver.findElement(By.id("00N3E000000XGJ5"));
    return element;
    }    
    
    //SF portal_Accountspage_NEW_mark for delete reason-type//    
    public static WebElement typ_accmkdlreason(WebDriver driver){ 
    element = driver.findElement(By.id("00N3E000000XGJ6"));
    return element;
    }  
    
//SF portal_Accountspage_NEW_SAVE button  type//    
    
    public static WebElement fnd_savebtn(WebDriver driver){     	
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	System.out.println("Before finding title");
    	element = driver.findElement(By.xpath(".//input[@name='save']"));
    	System.out.println("After finding title");
    return element; 
    }

  //SF portal_Accountspage_Send update to Customer checkbox  type//
  public static WebElement clk_snudcb(WebDriver driver){     	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	System.out.println("Before finding title");
	element = driver.findElement(By.id("00N5800000BM3dL"));
	System.out.println("After finding title");
return element; 
}
  
    //public static WebElement clk_savebtn(WebDriver driver){ 
    //element = driver.findElement(By.className("save"));
    //return element;
    //} 
    
//SF portal_Accountspage_NEW_SAVE&NEW button  type//    
    public static WebElement clk_savenew(WebDriver driver){ 
    element = driver.findElement(By.className("save_new"));
    return element;
    } 
    
 //SF portal_Accountspage_NEW_CANCEL button  type//    
    public static WebElement clk_cancel(WebDriver driver){ 
    element = driver.findElement(By.className("cancel"));
    return element;
    } 
    
    
    //SF portal_Accountspage_New Save(Ignore Alert) button  type//    
    public static WebElement clk_svignalrt(WebDriver driver){ 
    element = driver.findElement(By.xpath(".//input[@name='save']"));
    return element;
    } 
    
    
    //SF portal_Accountspage_New Save(Ignore Alert) button  type//    
    public static WebElement clk_svnwignalrt(WebDriver driver){ 
    element = driver.findElement(By.xpath(".//input[@name='save_new']"));
    return element;
    } 
    
    
    //SF portal_Accountspage_New opportunity button  type//    
    public static WebElement clk_acnwoppor(WebDriver driver){ 
    element = driver.findElement(By.xpath(".//input[@name='newOpp']"));
    return element;
    } 
    
    //SF portal_Accountspage_New Account type button  type//    
    public static WebElement sel_acttyp(WebDriver driver){ 
    element = driver.findElement(By.id("00N3E000000W7JJ"));
    return element;
    } 
    
}


     
    