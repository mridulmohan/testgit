package pageObjects;
 
    import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class  Opportunity_AddTeam{ 
    private static WebElement element = null;
    
//All mandatory and important non mandatory fields for Add team to Opportunity page//
//This includes the below sections//
    /*
    Team Role
    User
    Opportunity Access	
    Save
    Cancel
     */
 
    
//SF portal_Opporpage_New page_Save section//     
      public static WebElement clk_oatadd(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='add']"));
        return element;
      }

//SF portal_Opporpage_New page_Team Role section//    
  public static WebElement sel_oattmrl(WebDriver driver){ 
	  element = driver.findElement(By.id("TeamMemberRole_1"));
    return element; 
  }
  
//SF portal_Opporpage_New page_ User section//     
    public static WebElement sel_oatusr(WebDriver driver){ 
  	  element = driver.findElement(By.id("User_1"));
      return element; 
    }
    
//SF portal_Opporpage_New page_Opportunity Access section//      
      public static WebElement sel_oatopac(WebDriver driver){ 
    	  element = driver.findElement(By.id("OpportunityAccessLevel_1"));
        return element; 
      }
      
//SF portal_Opporpage_New page_Save section//     
        public static WebElement clt_oatsv(WebDriver driver){ 
      	  element = driver.findElement(By.xpath(".//input[@name='save']"));
          return element; 
        }      
 //SF portal_Opporpage_New page_Cancel section//  
          public static WebElement clt_oatcnl(WebDriver driver){ 
        	  element = driver.findElement(By.xpath(".//input[@name='cancel']"));
            return element; 
  
          
            
            
  }
  }