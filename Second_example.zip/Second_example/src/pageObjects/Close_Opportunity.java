package pageObjects;
 
    import java.util.concurrent.TimeUnit;

    import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class Close_Opportunity { 
    private static WebElement element = null;
    
   

//SF portal_Oppor Reason select click//    
public static WebElement sel_clostatus(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@id='p:i:i:f:pb:d:What_is_the_Close_status.input']"));
    	    return element;       
    }

//SF portal_Oppor Yes click//    
public static WebElement clk_comyes(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@id='p:i:i:f:pb:d:Is_this_a_Competing_Opportunity.ChoiceYes.radio']"));
  	    return element;       
  }

//SF portal_Oppor No click//    
public static WebElement clk_comno(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@id='p:i:i:f:pb:d:Is_this_a_Competing_Opportunity.ChoiceNo.radio']"));
  	    return element;       
  }

//SF portal_Oppor Next button//    
public static WebElement clk_nxt(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@id='p:i:i:f:pb:pbb:bottom:next']"));
  	    return element;       
  }

//SF portal_Oppor Competitor Account click//    
public static WebElement typ_compacc(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@id='p:i:i:f:pb:d:CAP_AG_Competitor_Account.input']"));
  	    return element;       
  }

//SF portal_Oppor Select Competitor Account//    
public static WebElement sel_compacc(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@id='p:i:i:f:pb:d:CAP_AG_Select_Competitor_Account.input']"));
  	    return element;       
  }

//SF portal_Oppor Other Competitor//    
public static WebElement typ_othacc(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@id='p:i:i:f:pb:d:Other_Competitor.input']"));
  	    return element;       
  }

//SF portal_Oppor Reason lost//    
public static WebElement sel_reaslost(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@id='p:i:i:f:pb:d:Reason_LostDevelopBuild.input']"));
  	    return element;       
  }

//SF portal_Oppor Previous button//    
public static WebElement clk_previous(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@id='p:i:i:f:pb:pbb:bottom:back']"));
	    return element;       
}



}