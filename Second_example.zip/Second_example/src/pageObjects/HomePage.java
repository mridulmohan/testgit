package pageObjects;
 
    import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class  HomePage{ 
    private static WebElement element = null;
    
//4 main sections involved-Contacts,Accounts,Leads,Opportunities//  
//Drop down for Sales_force logout and profile settings//

//SF portal_Homepage_Accounts section//    
  public static WebElement clk_Account(WebDriver driver){ 
	  element = driver.findElement(By.id("Account_Tab"));
    return element; 
    }

//SF portal_Homepage_Contacts section//   
public static WebElement clk_Contacts(WebDriver driver){ 
    element = driver.findElement(By.id("Contact_Tab"));
    return element; 
    }

//SF portal_Homepage_Leads section//
public static WebElement clk_Leads(WebDriver driver){ 
    element = driver.findElement(By.id("Lead_Tab"));
    return element; 
    }

//SF portal_Homepage_Opportunities section//
public static WebElement clk_Opportunity(WebDriver driver){ 
  element = driver.findElement(By.id("Opportunity_Tab"));
  return element; 
  }

//SF portal_Homepage_Competiitor Accounts section//
public static WebElement clk_Compacc(WebDriver driver){ 
element = driver.findElement(By.id("01r58000000cryg_Tab"));
return element; 
}

//SF portal_Homepage_Projects section//   
public static WebElement clk_Projects(WebDriver driver){ 
  element = driver.findElement(By.xpath(".//a[@title='Projects Tab']"));
  return element; 
  }

//SF portal_Homepage_Sales Plan section//   
public static WebElement clk_slplan(WebDriver driver){ 
element = driver.findElement(By.xpath(".//a[@title='Sales Plans Tab']"));
return element; 
}

//SF portal_Homepage_Sales Target section//   
public static WebElement clk_sltrgt(WebDriver driver){ 
element = driver.findElement(By.xpath(".//a[@title='Sales Targets Tab']"));
return element; 
}

//SF portal_Homepage_Sales Territory section//   
public static WebElement clk_slterity(WebDriver driver){ 
element = driver.findElement(By.xpath(".//a[@title='Territories Tab']"));
return element; 
}

//SF portal_Homepage_Salesforce profile dropdown section//
public static WebElement clk_salesdrpdn(WebDriver driver){ 
element = driver.findElement(By.id("userNavButton"));
return element; 
}


//SF portal_Homepage_Salesforce Reports section//
public static WebElement clk_reports(WebDriver driver){ 
element = driver.findElement(By.id("report_Tab"));
return element; 
}


//SF portal_Homepage_Salesforce Search section section//
public static WebElement clk_sfsearch(WebDriver driver){ 
element = driver.findElement(By.id("phSearchInput"));
return element; 
}

//SF portal_Homepage_Salesforce Search button click section section//
public static WebElement clk_sfsearchbtn(WebDriver driver){ 
element = driver.findElement(By.id("phSearchButton"));
return element; 
}


//SF

//SF portal_Homepage_Salesforce profile dropdown_Logout section//href
public static WebElement clk_salesdrpdn_lgt(WebDriver driver){ 
element = driver.findElement(By.xpath(".//a[@title='Logout']"));
return element; 
}

//SF portal_Homepage_Salesforce profile dropdown_ My Settings//href
public static WebElement clk_salesdrpdn_myst(WebDriver driver){ 
element = driver.findElement(By.xpath(".//a[@title='My Settings']"));
return element; 
}

//SF portal_Homepage_Salesforce profile dropdown_ My Settings//href
public static WebElement clk_firstitem(WebDriver driver){ 
element = driver.findElement(By.xpath(".//*[@id='Opportunity_body']/table/tbody/tr[2]/th/a[@href='/0063E000002H0zF?srPos=0&srKp=006']"));
return element; 
}

//SF portal_Salesplan Search first element//href
public static WebElement clk_plansrch(WebDriver driver){ 
element = driver.findElement(By.xpath(".//*[@id='CAP_AG_Sales_Plan__c_body']/table/tbody/tr[2]/th/a[@href='/a0G3E000000WfVg?srPos=0&srKp=a0G']"));
return element; 
}



}