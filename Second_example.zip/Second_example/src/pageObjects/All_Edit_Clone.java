package pageObjects;
 
    import java.util.concurrent.TimeUnit;

    import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class All_Edit_Clone { 
    private static WebElement element = null;
    
//Page locators mainly in the Accounts page//    

//SF portal_Accountspage_New button click//    
public static WebElement fnd_accountdetail(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h2[text()='Account Detail']"));
    	    return element;       
    }

public static WebElement fnd_contactdetail(WebDriver driver){ 	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h2[text()='Contact Detail']"));
	
return element;       
}

public static WebElement fnd_leaddetail(WebDriver driver){ 	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h2[text()='Lead Detail']"));
	
return element;       
}

public static WebElement fnd_oppordetail(WebDriver driver){	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//td[@class='pbTitle']/h2[text()='Opportunity Detail']"));
	
return element;       
}

public static WebElement fnd_editbtn(WebDriver driver){     	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	element = driver.findElement(By.xpath(".//input[@name='edit']"));
	
return element; 
}

public static WebElement fnd_coldclonebtn(WebDriver driver){     	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	element = driver.findElement(By.xpath("l.//input[@name='clone']"));
	
return element; 
}

public static WebElement fnd_opporclonebtn(WebDriver driver){     	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	element = driver.findElement(By.xpath(".//input[@name='eclone__cloneopportunity']"));
	
return element; 
}

public static WebElement fnd_ldconvrt(WebDriver driver){     	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	element = driver.findElement(By.xpath(".//input[@name='convert']"));
	
return element; 
}

public static WebElement fnd_ldcncl(WebDriver driver){     	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	element = driver.findElement(By.xpath(".//input[@name='cancel']"));
	
return element; 
}

//One which Lead to oppor-Competiitor accounts section-New Competitor account//
public static WebElement fnd_opporcomac(WebDriver driver){	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//input[@name='new00N5800000BMWJe']"));
	System.out.println("After finding title");
return element;       
}

//this is linked to New Linked Competitors//
public static WebElement fnd_newcomp(WebDriver driver){	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//input[@name='new00N5800000BMWJc']"));
	System.out.println("After finding title");
return element;       
}


//Post Account creation-Credit Limit Info//
public static WebElement clk_crdtlt(WebDriver driver){	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//input[@name='credit_limit_info']"));
	return element;       
}

//Post Account creation-Show invoice//
public static WebElement clk_invoice(WebDriver driver){	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//input[@name='show_invoices']"));
	return element;       
}

//Post Account creation-Show Orders//
public static WebElement clk_orders(WebDriver driver){	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//input[@name='show_orders']"));
	return element;       
}


//Opportunity Post Account creation-Close Opportunity//
public static WebElement clk_closeoppor(WebDriver driver){	
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	element = driver.findElement(By.xpath(".//input[@name='cap_ag_close_opportunity']"));
	return element;       
}



}
