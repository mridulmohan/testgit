package pageObjects;
 
    import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class Sales_Target_New { 
    private static WebElement element = null;
    
  //Page locators mainly in the NEW SALES TARGET CREATION page// 
  //**MANDATORY FIELDS AND NON-MANDATORY FIRLDS INCLUDED ARE**//
    /*
    Sales Target Name
	Target Amount
	Sales Plan Target Roll Up
	Current Financial Year
	Currency
	Owner
	January Expected Revenue
	February Expected Revenue
	March Expected Revenue
	April Expected Revenue
	May Expected Revenue
	June Expected Revenue
	July Expected Revenue
	August Expected Revenue
	September Expected Revenue
	October Expected Revenue
	November Expected Revenue
	December Expected Revenue
    Save
    Cancel
    
    */

  //SF portal_Sales target_Sales Target Name//    
    public static WebElement typ_sltrgtname(WebDriver driver){ 
    	  element = driver.findElement(By.id("Name"));
    	  return element;    	  
    }
    
  //SF portal_Sales target_Sales Target Amount//    
    public static WebElement typ_sltrgamnt(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N3E000000W7KD"));
    	  return element;     
    }
    
  //SF portal_Sales target_Sales Target Current Financial year//    
    public static WebElement sel_sltcfy(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N3E000000WtFe"));
    	  return element;     
    }  
    
    //SF portal_Sales target_Sales Target Currency//    
    public static WebElement typ_sltgcncy(WebDriver driver){ 
    	  element = driver.findElement(By.id("CurrencyIsoCode"));
    	  return element;     
    }  
        
  
  //SF portal_Sales target_Sales jan Exp reve//    
    public static WebElement typ_sltjaner(WebDriver driver){ 
    	  element = driver.findElement(By.id("00N3E000000W7K5"));
    	  return element;     
    }  
    
    //SF portal_Sales target_Sales feb exp revenue//    
    public static WebElement typ_sltfeber(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7K4"));
  	  return element;     
  } 
    
    //SF portal_Sales target_Sales march exp revenue//    
    public static WebElement typ_sltmarer(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7K8"));
  	  return element;     
  }  
    
    //SF portal_Sales target_Sales April exp revenue//    
    public static WebElement typ_sltaprer(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7K1"));
  	  return element;     
  } 
    
    //SF portal_Sales target_Sales Target may exp revenue//    
    public static WebElement typ_sltmayer(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7K9"));
  	  return element;     
  }  
    
    //SF portal_Sales target_Sales Target June exp revenue//    
    public static WebElement typ_sltjuner(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7K7"));
  	  return element;     
  }  
    
    //SF portal_Sales target_Sales Target July exp revenue//    
    public static WebElement typ_sltjlyer(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7K6"));
  	  return element;     
  }  
    
    //SF portal_Sales target_Sales Target Aug exp revenue//    
    public static WebElement typ_sltauger(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7K2"));
  	  return element;     
  }  
    
    //SF portal_Sales target_Sales Target Sep exp revenue//    
    public static WebElement typ_sltseper(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7KC"));
  	  return element;     
  } 
    
    //SF portal_Sales target_Sales Target Oct exp revenue//    
    public static WebElement typ_sltocter(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7KB"));
  	  return element;     
  } 
    
    //SF portal_Sales target_Sales Target Nov exp revenue//    
    public static WebElement typ_sltnover(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7KA"));
  	  return element;     
  }  
    
    //SF portal_Sales target_Sales Target Dec exp revenue//    
    public static WebElement typ_sltdecer(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N3E000000W7K3"));
  	  return element;     
  } 
    
  //SF portal_Sales target_Sales Target Save button//    
    public static WebElement clk_sltsv(WebDriver driver){ 
  	  element = driver.findElement(By.xpath(".//input[@name='save']"));
  	  return element;     
  } 
    
    //SF portal_Sales target_Sales Target Cancel btn//    
    public static WebElement clk_sltcncl(WebDriver driver){ 
  	  element = driver.findElement(By.xpath(".//input[@name='cancel']"));
  	  return element;     
  }   
    
    
}