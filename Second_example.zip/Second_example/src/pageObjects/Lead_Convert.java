package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class  Lead_Convert{ 
    private static WebElement element = null;
    
    
//All Mandatory and non-mandatory important parametrs for Lead conversion//  
//This section includes//
    /*
    Record Owner
    Account Name
    Opportunity Name
    Converted Status
    Activity Type
    Type
    Due Date
    Call Result
    Priority
    Status
     */

//SF portal_Leads Convert_Record Owner type//    
  public static WebElement typ_ldrcownr(WebDriver driver){ 
	  element = driver.findElement(By.id("owner_id"));
    return element; 
  }

//SF portal_Leads Convert_Account Name type//    
  public static WebElement typ_ldacname(WebDriver driver){ 
	  element = driver.findElement(By.id("accid"));
    return element; 
  }
  
//SF portal_Leads Convert_Opportunity Name type//    
  public static WebElement typ_ldopname(WebDriver driver){ 
	  element = driver.findElement(By.id("noopptt"));
    return element; 
  }
  
//SF portal_Leads Convert_Converted Status type//    
  public static WebElement sel_ldconvst(WebDriver driver){ 
	  element = driver.findElement(By.id("cstatus"));
    return element; 
  }
  
//SF portal_Leads Convert_Activity Type type//    
  public static WebElement typ_actytyp(WebDriver driver){ 
	  element = driver.findElement(By.id("tsk5_fu"));
    return element; 
  } 

//SF portal_Leads Convert_Type type//    
  public static WebElement sel_ldtype(WebDriver driver){ 
	  element = driver.findElement(By.id("tsk10_fu"));
    return element; 
  }
  
//SF portal_Leads Convert_Due Date type//    
  public static WebElement typ_ldduedt(WebDriver driver){ 
	  element = driver.findElement(By.id("tsk4_fu"));
    return element; 
  } 

//SF portal_Leads Convert_Call Result type//    
  public static WebElement typ_ldclrslt(WebDriver driver){ 
	  element = driver.findElement(By.id("CallDisposition_fu"));
    return element; 
  } 
   
//SF portal_Leads Convert_Priority type//    
  public static WebElement sel_ldprity(WebDriver driver){ 
	  element = driver.findElement(By.id("tsk13_fu"));
    return element; 
  } 
  
//SF portal_Leads Convert_Status type//    
  public static WebElement sel_ldstts(WebDriver driver){ 
	  element = driver.findElement(By.id("tsk12_fu"));
    return element; 
  }  

//SF portal_Leads Convert_Reminder Date type//    
  public static WebElement sel_ldrmdt(WebDriver driver){ 
	  element = driver.findElement(By.id("reminder_dt_fu"));
    return element; 
  } 
 
//SF portal_Leads Convert_Reminder time type//    
  public static WebElement sel_ldrmtm(WebDriver driver){ 
	  element = driver.findElement(By.id("reminder_dt_fu_time"));
    return element; 
  } 
  
//SF portal_Leads Convert_Convert button type//    
  public static WebElement clk_ldcnrtbtn(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//input[@name='save']"));
    return element; 
  }  
  
  
//SF portal_Leads Convert_Cancel button type//    
  public static WebElement clk_ldcnrtcnl(WebDriver driver){ 
	  element = driver.findElement(By.xpath(".//input[@name='save']"));
    return element; 
  }
  
  
  
  }