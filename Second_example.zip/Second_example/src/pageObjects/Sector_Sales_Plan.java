package pageObjects;
 
    import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class Sector_Sales_Plan  { 
    private static WebElement element = null;
    
  //Page locators mainly in the Adding -Account Sales Plan to an Sales Plan-New tab page// 
  //**MANDATORY FIELDS AND NON-MANDATORY FIRLDS INCLUDED ARE**//
 /*   
  Expected Revenue
	Activity Frequency
	Save 
	Cancel
	Search for sectors

*/

  //SF portal_Acc Sec Sales Plan -Exp revenue//    
    public static WebElement typ_secspexprvn(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:selected:j_id12:tb']//td[3]/*[@id='j_id0:j_id4:selected:j_id12:0:j_id18']"));
    	  return element;    	  
    }	

    //SF portal_Acc Sec Sales Plan -Activity freq//    
    public static WebElement sel_secspactfrncy(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:selected:j_id12:tb']//td[3]/*[@id='j_id0:j_id4:selected:j_id12:0:j_id20']"));
    	  return element;    	  
    }	
    
    //SF portal_Acc Sec Sales Plan  -Save  clk//    
    public static WebElement clk_secspsave(WebDriver driver){ 
    	  element = driver.findElement(By.id(".//input[@name='j_id0:j_id4:selected:j_id26:j_id27']"));
    	  return element;    	  
    }	
    
    //SF portal_Acc Sec Sales Plan -Cancel clk//    
    public static WebElement clk_secspcncl(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//input[@name='j_id0:j_id4:selected:j_id26:j_id28']"));
    	  return element;    	  
    }	
    
    //SF portal_Acc Sec Sales Plan -search for sectors  clk//    
    public static WebElement typ_secspsrch(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:j_id29']/div[1]/input"));
    	  return element;    	  
    }	
    
}