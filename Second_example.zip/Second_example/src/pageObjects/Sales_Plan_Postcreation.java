package pageObjects;
 
    import java.util.concurrent.TimeUnit;

    import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class Sales_Plan_Postcreation
 { 
    private static WebElement element = null;
    
//Page locators mainly in the Accounts page//    

//SF portal_Accountspage_New Submit for Approval click//    
public static WebElement clk_spsndappr
(WebDriver driver){ 
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@name='piSubmit']"));
    	//System.out.println("After finding title");
    return element;       
    }

//SF portal_Accountspage_New Ad new sales plan click//  
public static WebElement clk_spnaccslpln(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@name='cap_ag_select_account_sales_plan']"));
    	//System.out.println("After finding title");
    return element;       
    }


//SF portal_Accountspage_New Edit Button//  
public static WebElement clk_spnedit(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@name='edit']"));
  	//System.out.println("After finding title");
  return element;  
  
}

//SF portal_Sales Plan-Add territory Button//  
public static WebElement clk_spnsltrgttrty(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//input[@name='new00N3E000000Wj9Q']"));
	//System.out.println("After finding title");
return element;

}

//SF portal_Sales Plan-Select Sector Sales plan Button//  
public static WebElement clk_spnsectspn(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//input[@name='cap_ag_select_sales_plan_sector']"));
	//System.out.println("After finding title");
return element;
}

//SF portal_Accountspage_Approve/Reject Button//  
public static WebElement clk_spnapprj(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//a[contains(text(),'Approve / Reject')]"));
  	//System.out.println("After finding title");
  return element;
}
  
//SF portal_Accountspage_Search in Add accounts Button//  
public static WebElement typ_acctsrchsp(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4:j_id31']/div[1]/input"));
  	//System.out.println("After finding title");
  return element;  
  
  }

}