package pageObjects;
 
    import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class Oppor_New_Competitor_Account { 
    private static WebElement element = null;
    
  //Page locators mainly in the NEW ACCOUNT CREATION page// 
  //**MANDATORY FIELDS AND NON-MANDATORY FIRLDS INCLUDED ARE**//
    /*
    
    */

  //SF portal_OpporNew link Competitor Account Name//     
    public static WebElement typ_coactnm(WebDriver driver){ 
  	  element = driver.findElement(By.id("Name"));
      return element;
    }
    
//SF portal_OpporNew link- Account//     
    public static WebElement typ_coaccnm(WebDriver driver){ 
  	  element = driver.findElement(By.id("CF00N5800000BMWJe"));
      return element;
    }
         
//SF portal_Oppornew-Location//     
    public static WebElement sel_ocomloc(WebDriver driver){ 
  	  element = driver.findElement(By.id("00N5800000BMWJf"));
      return element;
    }
    
    
//SF portal_Currency//     
    public static WebElement sel_nlaccrncy(WebDriver driver){ 
  	  element = driver.findElement(By.id("CurrencyIsoCode"));
      return element;
    }
    
//SF portal_Save button//     
    public static WebElement clk_ocomsv(WebDriver driver){ 
  	  element = driver.findElement(By.xpath(".//input[@name='save']"));
      return element;
    }
    
//SF portal_Cancel button//     
    public static WebElement clk_ocomcnl(WebDriver driver){ 
  	  element = driver.findElement(By.xpath(".//input[@name='cancel']"));
      return element;
    }
              
    }	
    
    

