package pageObjects;
 
    import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class SalesPlan_Account { 
    private static WebElement element = null;
    
  //Page locators mainly in the Adding -Account Sales Plan to an Sales Plan-New tab page// 
  //**MANDATORY FIELDS AND NON-MANDATORY FIRLDS INCLUDED ARE**//
 /*   
  Save
    Search
    First
    Second
    Third
    Fourth
*/

  //SF portal_Acc Sales Plan -Save  clk//    
    public static WebElement clk_spacsave(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[3]//tr[1]/*[@id='j_id0:j_id4:selected:j_id28:bottom']/input[@name='j_id0:j_id4:selected:j_id28:bottom:j_id29']"));
    	  return element;    	  
    }	

    //SF portal_Acc Sales Plan -Search  type//    
    public static WebElement typ_spsearch(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]//div[1]/*[@id='j_id0:j_id4:j_id31']//input[@name='j_id0:j_id4:j_id31:j_id36']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Plan -First acc click//    
    public static WebElement clk_spacfirst(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]//div[1]//*[@id='j_id0:j_id4:j_id31:j_id40']/*[@id='j_id0:j_id4:j_id31:j_id40:tb']/tr[1]/td[8]/input[@name='j_id0:j_id4:j_id31:j_id40:0:j_id64']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Second Acc click//    
    public static WebElement clk_spacsecond(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]//div[1]//*[@id='j_id0:j_id4:j_id31:j_id40']/*[@id='j_id0:j_id4:j_id31:j_id40:tb']/tr[2]/td[8]/input[@name='j_id0:j_id4:j_id31:j_id40:1:j_id64']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Plan -Third//    
    public static WebElement clk_spacthird(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]//div[1]//*[@id='j_id0:j_id4:j_id31:j_id40']/*[@id='j_id0:j_id4:j_id31:j_id40:tb']/tr[3]/td[8]/input[@name='j_id0:j_id4:j_id31:j_id40:2:j_id64']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Plan -Fourth click//    
    public static WebElement clk_spacfrth(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]//div[1]//*[@id='j_id0:j_id4:j_id31:j_id40']/*[@id='j_id0:j_id4:j_id31:j_id40:tb']/tr[4]/td[8]/input[@name='j_id0:j_id4:j_id31:j_id40:3:j_id64']"));
    	  return element;    	  
    }

//Expected Revenue//    
    //SF portal_Acc Sales Plan -Expected revenue1//    
    public static WebElement typ_spexprevenue1(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[1]/td[4]/input[@name='j_id0:j_id4:selected:j_id12:0:j_id20']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Plan -Expected revenue2//    
    public static WebElement typ_spexprevenue2(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[2]/td[4]/input[@name='j_id0:j_id4:selected:j_id12:1:j_id20']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Plan -Expected revenue3//    
    public static WebElement typ_spexprevenue3(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[3]/td[4]/input[@name='j_id0:j_id4:selected:j_id12:2:j_id20']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Plan -Expected revenue4//    
    public static WebElement typ_spexprevenue4(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[4]/td[4]/input[@name='j_id0:j_id4:selected:j_id12:3:j_id20']"));
    	  return element;    	  
    }
    
//Activity frequency//    
   
  //SF portal_Acc Sales Plan -Activity Frequecy 1//    
    public static WebElement sel_spactyfreq1(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[1]/td[5]/*[@id='j_id0:j_id4:selected:j_id12:0:j_id22']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Plan -Activity Frequecy 2//    
    public static WebElement sel_spactyfreq2(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[2]/td[5]/*[@id='j_id0:j_id4:selected:j_id12:1:j_id22']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Plan -Activity Frequecy 3//    
    public static WebElement sel_spactyfreq3(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[3]/td[5]/*[@id='j_id0:j_id4:selected:j_id12:2:j_id22']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Plan -Activity Frequecy 4//    
    public static WebElement sel_spactyfreq4(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[4]/td[5]/*[@id='j_id0:j_id4:selected:j_id12:3:j_id22']"));
    	  return element;    	  
    }
  //Number of Activities to be scheduled//
    
  //SF portal_Acc Sales Plan -Number of Activities to be scheduled 1//    
    public static WebElement typ_spactyschl1(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[1]/td[6]/input[@name='j_id0:j_id4:selected:j_id12:0:j_id27']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Plan -Number of Activities to be scheduled 2//    
    public static WebElement typ_spactyschl2(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[2]/td[6]/input[@name='j_id0:j_id4:selected:j_id12:1:j_id27']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Plan -Number of Activities to be scheduled 3//    
    public static WebElement typ_spactyschl3(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[3]/td[6]/input[@name='j_id0:j_id4:selected:j_id12:2:j_id27']"));
    	  return element;    	  
    }
    
    //SF portal_Acc Sales Plan -Number of Activities to be scheduled 4//    
    public static WebElement typ_spactyschl4(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[4]/td[6]/input[@name='j_id0:j_id4:selected:j_id12:3:j_id27']"));
    	  return element;    	  
    }
    
  //SF portal_Acc Sales Plan -Click First Account-Link//    
    public static WebElement clk_spaclnk(WebDriver driver){ 
    	  element = driver.findElement(By.xpath(".//*[@id='j_id0:j_id4']//div[2]/*[@id='j_id0:j_id4:selected:j_id12']//tr[1]/*[@id='j_id0:j_id4:selected:j_id12:0:j_id16']/*[@id='j_id0:j_id4:selected:j_id12:0:j_id68']/a[@id='lookup0013E0000093hqW00N3E000000W7JL']"));
    	  return element;    	  
    }
    
    
    
}

