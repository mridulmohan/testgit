package pageObjects;
 
    import java.util.concurrent.TimeUnit;
    import org.openqa.selenium.By; 
    import org.openqa.selenium.WebDriver; 
    import org.openqa.selenium.WebElement;
 
public class Sales_Territory_New { 
    private static WebElement element = null;
    
//Page locators mainly in the Sales Territory page//    
    /*
Territory Name
Territory Type
Area
Postcode Owner
Currency
Save
Cancel
     */
    

//SF portal_Sales territory_Name//    
public static WebElement typ_strynam(WebDriver driver){
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.id("Name"));
    	//System.out.println("After finding title");
    return element;       
    }

//SF portal_Sales territory_Type//    
public static WebElement sel_strytyp(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.id("00N5800000BNHe5"));
  	//System.out.println("After finding title");
  return element;       
  }

//SF portal_Sales Territory-Area//    
public static WebElement typ_stryarea(WebDriver driver){ 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.id("CF00N3E000000WMZH"));
  	//System.out.println("After finding title");
  return element;       
  }

//SF portal_Sales territory-Postcode Owner //    
public static WebElement typ_stryprown(WebDriver driver){ 		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.id("CF00N3E000000W7KK"));
  	//System.out.println("After finding title");
  return element;       
  }

//SF portal_Sales territory-Currency//    
public static WebElement sel_strycrncy(WebDriver driver){
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.id("CurrencyIsoCode"));
  	//System.out.println("After finding title");
  return element;       
  }

//SF portal_Sales territory Save click//    
public static WebElement clk_strysv(WebDriver driver){ 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//input[@name='save']"));
  	//System.out.println("After finding title");
  return element;       
  }

//SF portal_Sales Territory Cancel click//    
public static WebElement clk_strycncl(WebDriver driver){ 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//input[@name='cancel']"));
  	//System.out.println("After finding title");
  return element;       
  }

//SF portal_Sales Territory Change owner click//    
public static WebElement clk_strycngown(WebDriver driver){ 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.xpath(".//*[@id='Owner_ileinner']/a"));
	//System.out.println("After finding title");
return element;       
}


//SF portal_Sales Territory Ownership Edit-Change owner new page//    
public static WebElement typ_stryownchng(WebDriver driver){ 
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		element = driver.findElement(By.id("newOwn"));
	//System.out.println("After finding title");
return element;       
}


}
