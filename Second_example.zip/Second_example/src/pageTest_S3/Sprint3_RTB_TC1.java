package pageTest_S3;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     

import pageObjects.AccountsPage;
import pageObjects.All_Edit_Clone;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.Sales_Plan_New;
import pageObjects.Sales_Target_New;

 
     public class Sprint3_RTB_TC1 {
    	 
    	 
    	 /*@AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     } */
    	 
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void ART_619() throws Exception {
    	
//Sprint 3	AG-52	2.x.x Manage Sales Plan: Create a sales plan//
//"REG-S3-Create a sales plan    	This test case verifies creation of a Sales Target and Sales Plan//
   	
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_3.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(6).getCell(1,0).getContents();
   	 String username=wb.getSheet(6).getCell(1,1).getContents();
   	 String password=wb.getSheet(6).getCell(1,2).getContents();    	 
   	 String targname=wb.getSheet(6).getCell(1,3).getContents();
   	 String Currency=wb.getSheet(6).getCell(1,4).getContents();    	 
   	 String jan=wb.getSheet(6).getCell(1,5).getContents();   	 
   	 String feb=wb.getSheet(6).getCell(1,6).getContents();   	 
   	 String march=wb.getSheet(6).getCell(1,7).getContents();   	 
   	 String april=wb.getSheet(6).getCell(1,8).getContents();   	 
   	 String may=wb.getSheet(6).getCell(1,9).getContents();   	 
   	 String june=wb.getSheet(6).getCell(1,10).getContents();
   	 String july=wb.getSheet(6).getCell(1,11).getContents();
   	 String aug=wb.getSheet(6).getCell(1,12).getContents();
   	 String sep=wb.getSheet(6).getCell(1,13).getContents();
   	 String oct=wb.getSheet(6).getCell(1,14).getContents(); 
   	 String nov=wb.getSheet(6).getCell(1,15).getContents(); 
   	 String dec=wb.getSheet(6).getCell(1,15).getContents();
   	 
 //-------------------------------------------------------------------------------------------------------------------------//
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
        Sprint3_RTB_TC1.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { } 
        HomePage.clk_sltrgt(driver).click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(2000);
            } catch (InterruptedException ex) { }              
            Sprint3_RTB_TC1.captureScreenShot(driver);
  //*****************************************Sales target Creation*****************************//          
            
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement stgtelement=AccountsPage.fnd_recentsltgts(driver);
            System.out.println("The text "+ stgtelement.getAttribute("innerHTML"));             
             String stgtelementtext=stgtelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(stgtelementtext.contains("Recent Sales Targets"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }              
             Sprint3_RTB_TC1.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sales_Target_New.typ_sltrgtname(driver).sendKeys(targname);
             
             Select a=new Select(Sales_Target_New.typ_sltgcncy(driver));
             a.selectByVisibleText(Currency);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sales_Target_New.typ_sltjaner(driver).sendKeys(jan);
             Sales_Target_New.typ_sltfeber(driver).sendKeys(feb);
             Sales_Target_New.typ_sltmarer(driver).sendKeys(march);
             Sales_Target_New.typ_sltaprer(driver).sendKeys(april);
             Sales_Target_New.typ_sltmayer(driver).sendKeys(may);
             Sales_Target_New.typ_sltjuner(driver).sendKeys(june);
             Sales_Target_New.typ_sltjlyer(driver).sendKeys(july);
             Sales_Target_New.typ_sltauger(driver).sendKeys(aug);
             Sales_Target_New.typ_sltseper(driver).sendKeys(sep);
             Sales_Target_New.typ_sltocter(driver).sendKeys(oct);
             Sales_Target_New.typ_sltnover(driver).sendKeys(nov);
             Sales_Target_New.typ_sltdecer(driver).sendKeys(dec);
             
             Sprint3_RTB_TC1.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             WebElement c=Sales_Target_New.clk_sltsv(driver);
             c.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { }              
             Sprint3_RTB_TC1.captureScreenShot(driver);
             
             WebElement c1=All_Edit_Clone.fnd_editbtn(driver);
             c1.click();

             
             System.out.println("Target created successfully::"+targname);
             System.out.println("Sprint3_TC1 Pass..Please verify SS..");
             

             
    }
             public static void captureScreenShot(WebDriver ldriver){        	 
            	  // Take screenshot and store as a file format//
            	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
            	try {
            	  // To copy the  screenshot to desired location using copyFile method	 
            	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_3/Sprint3_TC1/screenshot_"+System.currentTimeMillis()+".png"));
            	       }	 
            	catch (IOException e)	 
            	{	 
            	System.out.println(e.getMessage());	 
            	    }         
              }
             
   
     
     }
     
            