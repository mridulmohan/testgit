package pageTest_S3;
 
     import java.io.File;
     import java.io.IOException;
     import java.util.concurrent.TimeUnit; 
     import org.openqa.selenium.WebDriver;
     import org.openqa.selenium.WebElement;
     import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
     import org.testng.annotations.Test;

import jxl.Workbook;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
     import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.Sales_Territory_New;
import pageTest.Sprint1_RTB_TC5;
import pageObjects.All_Edit_Clone;

 
     public class Sprint3_RTB_TC12{
    	 
    	/*@AfterTest
    	 public void tearDown() throws Exception { 
    		 driver.close();
    	   driver.quit();
    	     }  */
    	 
         private static WebDriver driver = null;        
         
                  
    @Test(enabled=true)
       public void ART_629() throws Exception {
    	
    	
//Sprint 3	AG-53	2.x.x Manage Sales Plan: Create a sales territory
//Sprint3_RTB-TC12-Verifies creating an account and check if the assignment is as per the Agg location
  
//-------------------------------------------------------------------------------------------------------------------------//
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_3.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(14).getCell(1,0).getContents();
   	 String username=wb.getSheet(14).getCell(1,1).getContents();
   	 String password=wb.getSheet(14).getCell(1,2).getContents();    	 
     String actname=wb.getSheet(14).getCell(1,3).getContents();     	 
   	 String actstat=wb.getSheet(14).getCell(1,4).getContents();
   	 String actaic=wb.getSheet(14).getCell(1,5).getContents();
   	 String actseg=wb.getSheet(14).getCell(1,6).getContents();
   	 String actloc=wb.getSheet(14).getCell(1,7).getContents();
   	String searchterm=wb.getSheet(14).getCell(1,8).getContents();
   	 
 //-------------------------------------------------------------------------------------------------------------------------//    	
    	
    	
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint3_RTB_TC12.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
        HomePage.clk_Account(driver).click();    
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint3_RTB_TC12.captureScreenShot(driver);
            
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }               
            WebElement accelement=AccountsPage.fnd_recentaccount(driver);
            System.out.println("The text "+ accelement.getAttribute("innerHTML"));             
             String accelementtext=accelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(accelementtext.contains("Recent Accounts"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint3_RTB_TC12.captureScreenShot(driver);
              
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            Account_NewCreate.typ_actname(driver).sendKeys(actname);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);         
            Select a=new Select(Account_NewCreate.sel_actst(driver));
            a.selectByVisibleText(actstat);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);         
            Select b=new Select(Account_NewCreate. sel_actaic(driver));
            b.selectByVisibleText(actaic);
           
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);         
            Select c=new Select(Account_NewCreate. typ_acsegmnt(driver));
            c.selectByVisibleText(actseg);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);         
            Select d=new Select(Account_NewCreate. sel_aggloc(driver));
            d.selectByVisibleText(actloc);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint3_RTB_TC12.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            WebElement x=Account_NewCreate.fnd_savebtn(driver);
            x.click(); 
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);           
            Sprint3_RTB_TC12.captureScreenShot(driver);
            
            ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);           
            Sprint3_RTB_TC12.captureScreenShot(driver);
            
            ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
                      
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);           
            Sprint3_RTB_TC12.captureScreenShot(driver);
   
//***************************Verify the Aggreko location-Territory details****************************//
//*************Seacrh for location**********************//
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { } 
            HomePage.clk_sfsearch(driver).click();
            HomePage.clk_sfsearch(driver).sendKeys(searchterm);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint3_RTB_TC12.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
            
            WebElement k=HomePage.clk_sfsearchbtn(driver);
            k.click();
            
((JavascriptExecutor)driver).executeScript("scroll(0,400)");
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }              
            Sprint3_RTB_TC12.captureScreenShot(driver);
 
((JavascriptExecutor)driver).executeScript("scroll(0,400)");
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(2000);
            } catch (InterruptedException ex) { }              
            Sprint3_RTB_TC12.captureScreenShot(driver);
            
//***********Select the location from the table*************//
//To search and click-Location//   
//TERRITORY LOCATOR.//*[@id='CAP_AG_Territory__c_body']/table/tbody/tr[2]/th/a            
           
            String territoryname="Aberdeen UK";        
            int Row_count = driver.findElements(By.xpath("//*[@id='CAP_AG_Territory__c_body']/table/tbody/tr")).size();
            System.out.println("Number Of Rows = "+Row_count);
            
            		String  xpath_first=".//*[@id='CAP_AG_Territory__c_body']/table/tbody/tr[";        
            		String xpath_last="]/th/a";

            		for (int i=2; i<=Row_count; i++)
            		{

            		String TERRITORYNAME=driver.findElement(By.xpath(xpath_first+i+xpath_last)).getText();
            				if(TERRITORYNAME.equalsIgnoreCase(territoryname)){
            					System.out.println("Lead Seacrh term found");
            					WebElement m=driver.findElement(By.xpath(xpath_first+i+xpath_last));
            					m.click();  
            					break;
            				}else{
            					System.out.println("Search term not found");
            				}
            		}
    	   
            		try {
                        //System.out.println("Thread Sleep: " + getName());
                        Thread.sleep(3000);
                    } catch (InterruptedException ex) { }              
                    Sprint3_RTB_TC12.captureScreenShot(driver); 
                    
//*******************Click on Area/***********************************************/
                    
                    try {
                        //System.out.println("Thread Sleep: " + getName());
                        Thread.sleep(2000);
                    } catch (InterruptedException ex) { }       
                    WebElement Area=driver.findElement(By.xpath(".//*[@id='ep']/div[2]/div[2]/table/tbody/tr[3]//*[@id='CF00N3E000000WMZH_ilecell']//a"));
                    Area.click();
                    
                    try {
                        //System.out.println("Thread Sleep: " + getName());
                        Thread.sleep(5000);
                    } catch (InterruptedException ex) { }              
                    Sprint3_RTB_TC12.captureScreenShot(driver); 
                    
                    System.out.println("Sprint3_test case 12 successfull..Please verify SS..");
            		
    }
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_3/Sprint3_TC12/screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }         
       }
   	
    }
    	
    