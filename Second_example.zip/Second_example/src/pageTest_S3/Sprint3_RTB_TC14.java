package pageTest_S3;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import java.util.ArrayList;


  // Import package pageObject//     

import pageObjects.AccountsPage;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.Sales_Plan_New;
import pageObjects.Sales_Target_New;
import pageObjects.Salesplan_Approval;
import pageTest.Sprint1_RTB_TC5;
import pageObjects.Sales_Plan_Postcreation;

 
     public class Sprint3_RTB_TC14 {
    	 
    	 @AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     }     	 
    	 
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void ART_630_2() throws Exception {
    	
//Sprint 3	AG-71	2.x.x Manage Sales Plan: Update Sales Plan
//Sprint3_RTB_TC13-Sales rep submits Sales plan and manager approves it	

//-------------------------------------------------------------------------------------------------------------------------//
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_3.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(20).getCell(1,0).getContents();
   	 String username=wb.getSheet(20).getCell(1,1).getContents();
   	 String password=wb.getSheet(20).getCell(1,2).getContents();    	 
   	 String planname=wb.getSheet(20).getCell(1,3).getContents();
   	 String reason=wb.getSheet(20).getCell(1,4).getContents();
   	 
 //-------------------------------------------------------------------------------------------------------------------------// 
    	
 //Sales Rep creates a test plan and submits for approval//
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click();
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
 
   //*************Search the sales plan**************/
                  
                  
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                  HomePage.clk_Leads(driver).click();   
                  
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                  HomePage.clk_sfsearch(driver).click();
                  HomePage.clk_sfsearch(driver).sendKeys(planname);
                  
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                  Sprint3_RTB_TC14.captureScreenShot(driver);
                  
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
                  
                  WebElement k=HomePage.clk_sfsearchbtn(driver);
                  k.click();
                  HomePage.clk_sfsearchbtn(driver).click();
           
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { } 
                  Sprint3_RTB_TC14.captureScreenShot(driver);
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { } 

  //**********To search and click-Sales-Use Display name****************//       
                        
                  int Row_count = driver.findElements(By.xpath("//*[@id='CAP_AG_Sales_Plan__c_body']/table/tbody/tr")).size();
                  System.out.println("Number Of Rows = "+Row_count);
                  
                  		String  xpath_first="//*[@id='CAP_AG_Sales_Plan__c_body']/table/tbody/tr[";        
                  		String xpath_last="]/th/a";

                  		for (int i=2; i<=Row_count; i++)
                  		{

                  		String SPNAME=driver.findElement(By.xpath(xpath_first+i+xpath_last)).getText();
                  				if(SPNAME.equalsIgnoreCase(planname)){
                  					System.out.println("Sales Plan found..");
                  					WebElement m=driver.findElement(By.xpath(xpath_first+i+xpath_last));
                  					m.click();        					
                  				}else{
                  					System.out.println("Sales Plan not found..");
                  				}
                  		}
   //**************Verify Approve-Reject Button and click********************//
                  		
                  	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                      Sprint3_RTB_TC14.captureScreenShot(driver);
                  		
                  		try {
                            //System.out.println("Thread Sleep: " + getName());
                            Thread.sleep(5000);
                        } catch (InterruptedException ex) { } 

                  		Sales_Plan_Postcreation.clk_spnapprj(driver).click();
                  		
                  		try {
                            //System.out.println("Thread Sleep: " + getName());
                            Thread.sleep(7000);
                        } catch (InterruptedException ex) { } 

                  		Salesplan_Approval.typ_reason(driver).sendKeys(reason);
                  		
                  		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                         Sprint3_RTB_TC14.captureScreenShot(driver);
                  		
                  		WebElement h=Salesplan_Approval.clk_approve(driver);
                  		h.click();
                  		
                  		 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                         Sprint3_RTB_TC14.captureScreenShot(driver);
                         
                         System.out.println("Sprint3-test case 14 successful..Please validate screenshots..");
                  		
                  
    }
             public static void captureScreenShot(WebDriver ldriver){        	 
            	  // Take screenshot and store as a file format//
            	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
            	try {
            	  // To copy the  screenshot to desired location using copyFile method	 
            	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_3/Sprint3_TC14/screenshot_"+System.currentTimeMillis()+".png"));
            	       }	 
            	catch (IOException e)	 
            	{	 
            	System.out.println(e.getMessage());	 
            	    }         
              }
             
   
     
     }
     
            