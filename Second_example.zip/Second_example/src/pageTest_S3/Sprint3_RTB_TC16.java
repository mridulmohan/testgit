package pageTest_S3;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import java.util.ArrayList;


  // Import package pageObject//     

import pageObjects.AccountsPage;
import pageObjects.Calendar_event;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.SalesPlan_Account;
import pageObjects.Sales_Plan_New;
import pageObjects.Sales_Target_New;
import pageObjects.Sales_Plan_Postcreation;

 
     public class Sprint3_RTB_TC16 {
    	 
    	 /*@AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.quit();
    	     }     	 
    	 */
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void testcase16() {
    	
//Sprint 3	AG-47	2.x.x Manage Sales Plan: Sales Account plan automation
//1.Change the freq in Sales plan and check for all 3   	and add event//
//Sprint3_RTB_TC16-medium freq
    	
   	
 //Sales Rep creates a test plan and submits for approval//
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get("https://aggreko--CI2.cs82.my.salesforce.com");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click();
        LoginPage.txtbx_UserName(driver).sendKeys("sf.systestrep@aggreko.trial.ci2"); 
        LoginPage.txtbx_Password(driver).sendKeys("Welcome1");        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
        Sprint3_RTB_TC8.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(2000);
        } catch (InterruptedException ex) { }   
            HomePage.clk_sltrgt(driver).click();
            
                        
            Sprint3_RTB_TC8.captureScreenShot(driver);
  //Sales target Creation//          
         /*   
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }               
            WebElement stgtelement=AccountsPage.fnd_recentsltgts(driver);
            System.out.println("The text "+ stgtelement.getAttribute("innerHTML"));             
             String stgtelementtext=stgtelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(stgtelementtext.contains("Recent Sales Targets"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }              
             Sprint3_RTB_TC8.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sales_Target_New.typ_sltrgtname(driver).sendKeys("Sprint3_TC16_Targ1");
             
             Select a=new Select(Sales_Target_New.typ_sltgcncy(driver));
             a.selectByVisibleText("GBP - British Pound");
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             WebElement c=Sales_Target_New.clk_sltsv(driver);
             c.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { }              
             Sprint3_RTB_TC8.captureScreenShot(driver);
     */        
//Sales Plan Creation//             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }   
                 HomePage.clk_slplan(driver).click();
                 
                 try {
                     //System.out.println("Thread Sleep: " + getName());
                     Thread.sleep(2000);
                 } catch (InterruptedException ex) { }              
                 Sprint3_RTB_TC8.captureScreenShot(driver);
                 
                 
                 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
                 WebElement splnelement=AccountsPage.fnd_recentslplans(driver);
                 System.out.println("The text "+ splnelement.getAttribute("innerHTML"));             
                  String splnelementtext=splnelement.getAttribute("innerHTML");         
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
                  if(splnelementtext.contains("Recent Sales Plans"))
                  {
                 	AccountsPage.clk_nwbtn(driver).click();
                  }
               
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC8.captureScreenShot(driver);
                  
                  
                  Sales_Plan_New.typ_slplnnme(driver).sendKeys("Sprint3_TC16_Plan_1");
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                  Sales_Plan_New.typ_slplntgt(driver).sendKeys("Sprint3_TC16_Targ1");
                  
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);            
                  Sprint3_RTB_TC8.captureScreenShot(driver);
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }  

                  WebElement d=Sales_Plan_New.clk_slplnsv(driver);
                  d.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC8.captureScreenShot(driver);
                  

                  
//Add Account to the Sales Plan created//
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }  
                  Sales_Plan_Postcreation.clk_spnaccslpln(driver).click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC3.captureScreenShot(driver);
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { }  
                  ArrayList<String> s = new ArrayList<String>(driver.getWindowHandles());
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { } 
                  driver.switchTo().window(s.get(1));
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(7000);
                  } catch (InterruptedException ex) { } 
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC3.captureScreenShot(driver);
//Add the Sales plan with Account-1//               
                  
                  WebElement m1=SalesPlan_Account.clk_spacfirst(driver);
                  m1.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { } 
                 
                  SalesPlan_Account.typ_spexprevenue1(driver).click();
                  SalesPlan_Account.typ_spexprevenue1(driver).sendKeys("100");                  
                  Select s1=new Select(SalesPlan_Account.sel_spactyfreq1(driver));
                  s1.selectByVisibleText("High");
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC3.captureScreenShot(driver);   
                  
                //Save the records                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { } 
                  WebElement m=SalesPlan_Account.clk_spacsave(driver);
                  m.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { } 
 //SS-
                 

//Create event for one place holder/
                  
                 /*String spname="29/12/2016 All Day";        
                 int Row_count = driver.findElements(By.xpath("//*[@id='a0G3E000000Wufk_00N3E000000W7JK']//div[2]//tbody/tr")).size();
                  System.out.println("Number Of Rows = "+Row_count);
                  
                  		String  xpath_first="//*[@id='a0G3E000000Wufk_00N3E000000W7JK']//div[2]//tbody/tr[";        
                  		String xpath_last="]/td[1]/a[2]";
                  		//String xpath_first1=".//*[@id='a0G3E000000Wufk_00N3E000000W7JK']//div[2]//tbody/tr[";
                  		String xpath_last1="]/td[5]";
                  		

                  		for (int i=2; i<=Row_count; i++)
                  		{
                  		     
                  		String SPNAME=driver.findElement(By.xpath(xpath_first+i+xpath_last1)).getText();
                  				if(SPNAME.equalsIgnoreCase(spname)){
                  					WebElement m6=driver.findElement(By.xpath(xpath_first+i+xpath_last));
                  					m6.click();     
                  					break;
                  				}*/
                  		
                  WebElement k1=driver.findElement(By.xpath(".//*[@id='a0G3E000000Wufk_00N3E000000W7JK_body']/table/tbody/tr[2]/th/a"));
                  k1.click();
                  
                  	  try {
                          //System.out.println("Thread Sleep: " + getName());
                          Thread.sleep(2000);
                      } catch (InterruptedException ex) { } 
                      Sprint3_RTB_TC3.captureScreenShot(driver);
                      
    try {
        //System.out.println("Thread Sleep: " + getName());
        Thread.sleep(5000);
    } catch (InterruptedException ex) { } 
  
    Sprint3_RTB_TC16.captureScreenShot(driver);
                  
   
//Click on convert//
    Calendar_event.clk_calevflevn(driver).click();
//Click on Save//  
    try {
        //System.out.println("Thread Sleep: " + getName());
        Thread.sleep(2000);
    } catch (InterruptedException ex) { } 
  
    Sprint3_RTB_TC16.captureScreenShot(driver);
    Calendar_event.clk_calevsv(driver).click();
                  
    try {
        //System.out.println("Thread Sleep: " + getName());
        Thread.sleep(2000);
    } catch (InterruptedException ex) { } 
  
    Sprint3_RTB_TC16.captureScreenShot(driver);           


 
   /*To search and click-Sales-Use Display name//       
                  String spname="Sprint3_TC13_Plan_1";        
                  int Row_count1 = driver.findElements(By.xpath("//*[@id='CAP_AG_Sales_Plan__c_body']/table/tbody/tr")).size();
                  System.out.println("Number Of Rows = "+Row_count1);
                  
                  		String  xpath_first1="//*[@id='CAP_AG_Sales_Plan__c_body']/table/tbody/tr[";        
                  		String xpath_last1="]/th/a";

                  		for (int i=2; i<=Row_count1; i++)
                  		{

                  		String SPNAME=driver.findElement(By.xpath(xpath_first1+i+xpath_last1)).getText();
                  				if(SPNAME.equalsIgnoreCase(spname)){
                  					System.out.println("Sales Plan found");
                  					WebElement m5=driver.findElement(By.xpath(xpath_first+i+xpath_last));
                  					m5.click();        					
                  				}else{
                  					System.out.println("Search term not found");
                  				}
                  		}
               		
     */    
                  		}         		
                  		
                  

             public static void captureScreenShot(WebDriver ldriver){        	 
            	  // Take screenshot and store as a file format//
            	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
            	try {
            	  // To copy the  screenshot to desired location using copyFile method	 
            	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_3/Sprint3_TC15/screenshot_"+System.currentTimeMillis()+".png"));
            	       }	 
            	catch (IOException e)	 
            	{	 
            	System.out.println(e.getMessage());	 
            	    }         
              }
             
   
     
     }
     
            