package pageTest_S3;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.By;
import java.util.ArrayList;
import org.openqa.selenium.Keys;
import org.openqa.selenium.JavascriptExecutor;
  // Import package pageObject//     

import pageObjects.AccountsPage;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.Sales_Plan_New;
import pageObjects.Sales_Target_New;
import pageObjects.Sales_Plan_Postcreation;
import pageObjects.SalesPlan_Account;

 
     public class Sprint3_RTB_TC10 {
    	 
    	 
    	/* @AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.quit();
    	     } 
    	 */
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void testcase10() {
    	
//Sprint 3	AG--49//
//Add multiple Sales plan accoun to the Sales plan//
//verify the Revenue values//
//Verify Opportunity attached to records//    	

    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get("https://aggreko--CI2.cs82.my.salesforce.com");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click();
        LoginPage.txtbx_UserName(driver).sendKeys("sf.systestmanager@aggreko.trial.ci2"); 
        LoginPage.txtbx_Password(driver).sendKeys("Mercury@123");        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
        Sprint3_RTB_TC10.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }   
            HomePage.clk_sltrgt(driver).click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(2000);
            } catch (InterruptedException ex) { }              
            Sprint3_RTB_TC10.captureScreenShot(driver);
  //Sales target Creation//          
     /*       
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement stgtelement=AccountsPage.fnd_recentsltgts(driver);
            System.out.println("The text "+ stgtelement.getAttribute("innerHTML"));             
             String stgtelementtext=stgtelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(stgtelementtext.contains("Recent Sales Targets"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }              
             Sprint3_RTB_TC10.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sales_Target_New.typ_sltrgtname(driver).sendKeys("Sprint3_TC10_Targ1027_1");
                          
             Select a=new Select(Sales_Target_New.typ_sltgcncy(driver));
             a.selectByVisibleText("GBP - British Pound");
             
             Sales_Target_New.typ_sltjaner(driver).sendKeys("20");
             Sales_Target_New.typ_sltfeber(driver).sendKeys("10");
             Sales_Target_New.typ_sltmarer(driver).sendKeys("10");
             Sales_Target_New.typ_sltaprer(driver).sendKeys("20");
             Sales_Target_New.typ_sltmayer(driver).sendKeys("20");
             Sales_Target_New.typ_sltjuner(driver).sendKeys("20");
             Sales_Target_New.typ_sltjlyer(driver).sendKeys("20");
             Sales_Target_New.typ_sltauger(driver).sendKeys("20");
             Sales_Target_New.typ_sltseper(driver).sendKeys("20");
             Sales_Target_New.typ_sltocter(driver).sendKeys("20");
             Sales_Target_New.typ_sltnover(driver).sendKeys("20");
             Sales_Target_New.typ_sltdecer(driver).sendKeys("20");
          
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             WebElement c=Sales_Target_New.clk_sltsv(driver);
             c.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { }              
             Sprint3_RTB_TC10.captureScreenShot(driver);
    */         
//Sales Plan Creation//             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }   
                 HomePage.clk_slplan(driver).click();
                 
                 try {
                     //System.out.println("Thread Sleep: " + getName());
                     Thread.sleep(2000);
                 } catch (InterruptedException ex) { }              
                 Sprint3_RTB_TC10.captureScreenShot(driver);
                 
                 
                 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
                 WebElement splnelement=AccountsPage.fnd_recentslplans(driver);
                 System.out.println("The text "+ splnelement.getAttribute("innerHTML"));             
                  String splnelementtext=splnelement.getAttribute("innerHTML");         
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
                  if(splnelementtext.contains("Recent Sales Plans"))
                  {
                 	AccountsPage.clk_nwbtn(driver).click();
                  }
               
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC10.captureScreenShot(driver);
                  
                  Sales_Plan_New.typ_slplnnme(driver).sendKeys("Sprint3_TC10_Plan1027_1");
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                  Sales_Plan_New.typ_slplntgt(driver).sendKeys("Sprint3_TC10_Targ1027_1");
                  
                  Sales_Plan_New.typ_slplnjanrev(driver).sendKeys("20");
                  Sales_Plan_New.typ_slplnfebrev(driver).sendKeys("20");
                  Sales_Plan_New.typ_slplnmarrev(driver).sendKeys("20");
                  Sales_Plan_New.typ_slplnaprrev(driver).sendKeys("20");
                  Sales_Plan_New.typ_slplnmayrev(driver).sendKeys("20");
                  Sales_Plan_New.typ_slplnjunrev(driver).sendKeys("20");
                  Sales_Plan_New.typ_slplnjulyrev(driver).sendKeys("20");
                  Sales_Plan_New.typ_slplnaugrev(driver).sendKeys("20");
                  Sales_Plan_New.typ_slplnseprev(driver).sendKeys("20");
                  Sales_Plan_New.typ_slplnoctrev(driver).sendKeys("20");
                  Sales_Plan_New.typ_slplnnovrev(driver).sendKeys("20");
                  Sales_Plan_New.typ_slplndecrev(driver).sendKeys("20");
                 
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);            
                  Sprint3_RTB_TC10.captureScreenShot(driver);
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }  

                  WebElement d=Sales_Plan_New.clk_slplnsv(driver);
                  d.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC10.captureScreenShot(driver);
                  
                  //System.out.println("Sprint3_TC1_Successful_Verify SS");
  //Add Account to the Sales Plan created//
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }  
                  Sales_Plan_Postcreation.clk_spnaccslpln(driver).click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC10.captureScreenShot(driver);
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { }  
                  ArrayList<String> s = new ArrayList<String>(driver.getWindowHandles());
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { } 
                  driver.switchTo().window(s.get(1));
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(7000);
                  } catch (InterruptedException ex) { } 
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC10.captureScreenShot(driver);
                  
                  
   //Add the Sales plan to Account-1//               
                  
                  WebElement m1=SalesPlan_Account.clk_spacfirst(driver);
                  m1.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { } 
                 
                  SalesPlan_Account.typ_spexprevenue1(driver).click();
                  SalesPlan_Account.typ_spexprevenue1(driver).sendKeys("10000");
                  
                  Select s1=new Select(SalesPlan_Account.sel_spactyfreq1(driver));
                  s1.selectByVisibleText("High");
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC10.captureScreenShot(driver);
                  
  //Add the Sales plan to Account-2// 
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { } 
                  
                  
                  WebElement m2=SalesPlan_Account.clk_spacsecond(driver);
                  m2.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { } 
                 
                  SalesPlan_Account.typ_spexprevenue2(driver).sendKeys("12000");
                  
                  Select s2=new Select(SalesPlan_Account.sel_spactyfreq2(driver));
                  s2.selectByVisibleText("High");
                  
                  //SalesPlan_Account.typ_spactyschl2(driver).clear();
                  //SalesPlan_Account.typ_spactyschl2(driver).sendKeys("5");
  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC10.captureScreenShot(driver);
                  
//Add the Sales plan to Account-3// 
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { } 
                  
                  
                  WebElement m3=SalesPlan_Account.clk_spacthird(driver);
                  m3.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { } 
                 
                  SalesPlan_Account.typ_spexprevenue3(driver).sendKeys("12000");
                  
                  Select s3=new Select(SalesPlan_Account.sel_spactyfreq3(driver));
                  s3.selectByVisibleText("Medium");
                  
                   
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC10.captureScreenShot(driver);                 
                  
//Save the records                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { } 
                  WebElement m=SalesPlan_Account.clk_spacsave(driver);
                  m.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { } 
 //SS-
                              
                  Sprint3_RTB_TC1.captureScreenShot(driver);
                  
                  ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC10.captureScreenShot(driver);

                 
//Check Attached accounts//
                  
                  driver.close();
                  driver.switchTo().window(s.get(0));
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }  
                  Sales_Plan_Postcreation.clk_spnaccslpln(driver).click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { }  
                  ArrayList<String> ss = new ArrayList<String>(driver.getWindowHandles());
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { } 
                  driver.switchTo().window(ss.get(1));
                  
//Click on Accounts//
                  
                  WebElement s5=SalesPlan_Account.clk_spaclnk(driver);
                  s5.click();
                  
//view the Oppor and Records//                  
                  

                  
                  ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC10.captureScreenShot(driver);
                  

                  
                  ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC10.captureScreenShot(driver);
                  
                  
                  ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC10.captureScreenShot(driver);
                  
                  //driver.close();
                  //driver.switchTo().window(s.get(0));
                  
    }
             public static void captureScreenShot(WebDriver ldriver){        	 
            	  // Take screenshot and store as a file format//
            	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
            	try {
            	  // To copy the  screenshot to desired location using copyFile method	 
            	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_3/Sprint3_TC10/screenshot_"+System.currentTimeMillis()+".png"));
            	       }	 
            	catch (IOException e)	 
            	{	 
            	System.out.println(e.getMessage());	 
            	    }         
              }
             
   
             public void switchToTab() {
            	  //Switching between tabs using CTRL + tab keys.
            	  driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"\t");
            	  //Switch to current selected tab's content.
            	  driver.switchTo().defaultContent();  
            	 }
             
     
     }
     
            