package pageTest_S3;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.Alert;
import java.util.ArrayList;


  // Import package pageObject//     

import pageObjects.AccountsPage;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.Sales_Plan_New;
import pageObjects.Sales_Target_New;
import pageTest.Sprint1_RTB_TC5;
import pageObjects.Sales_Plan_Postcreation;

 
     public class Sprint3_RTB_TC2 {
    	 
    	 
    	 
    	 
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void testcase2() {
    	
//Sprint 3	AG-69	2.x.x Manage Sales Plan: Set sales plan review schedule periods//
//This test case verifies Review set my manager as quarterly//    	

 
    	
    	//Sales Rep creates a test plan ans submits for approval//
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get("https://aggreko--CI2.cs82.my.salesforce.com");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click();
        LoginPage.txtbx_UserName(driver).sendKeys("sf.systestmanager@aggreko.trial.ci2"); 
        LoginPage.txtbx_Password(driver).sendKeys("Mercury@123");        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
        Sprint3_RTB_TC1.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }   
            HomePage.clk_sltrgt(driver).click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(2000);
            } catch (InterruptedException ex) { }              
            Sprint3_RTB_TC1.captureScreenShot(driver);
  //Sales target Creation//          
            
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement stgtelement=AccountsPage.fnd_recentsltgts(driver);
            System.out.println("The text "+ stgtelement.getAttribute("innerHTML"));             
             String stgtelementtext=stgtelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(stgtelementtext.contains("Recent Sales Targets"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }              
             Sprint3_RTB_TC1.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sales_Target_New.typ_sltrgtname(driver).sendKeys("Sprint3_TC2_Targ22");
             
             Select a=new Select(Sales_Target_New.typ_sltgcncy(driver));
             a.selectByVisibleText("GBP - British Pound");
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             WebElement c=Sales_Target_New.clk_sltsv(driver);
             c.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { }              
             Sprint3_RTB_TC1.captureScreenShot(driver);
             
//Sales Plan Creation//             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }   
                 HomePage.clk_slplan(driver).click();
                 
                 try {
                     //System.out.println("Thread Sleep: " + getName());
                     Thread.sleep(2000);
                 } catch (InterruptedException ex) { }              
                 Sprint3_RTB_TC1.captureScreenShot(driver);
                 
                 
                 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
                 WebElement splnelement=AccountsPage.fnd_recentslplans(driver);
                 System.out.println("The text "+ splnelement.getAttribute("innerHTML"));             
                  String splnelementtext=splnelement.getAttribute("innerHTML");         
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
                  if(splnelementtext.contains("Recent Sales Plans"))
                  {
                 	AccountsPage.clk_nwbtn(driver).click();
                  }
               
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC1.captureScreenShot(driver);
                  
                  
                  Sales_Plan_New.typ_slplnnme(driver).sendKeys("Sprint3_TC2_Plan_23");
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                  Sales_Plan_New.typ_slplntgt(driver).sendKeys("Sprint3_TC2_Targ22");
                  
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);            
                  Sprint3_RTB_TC1.captureScreenShot(driver);
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }  

                  WebElement d=Sales_Plan_New.clk_slplnsv(driver);
                  d.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC1.captureScreenShot(driver);
                  
//Submit for approval//
                  
                  WebElement e=Sales_Plan_Postcreation.clk_spsndappr(driver);
                  e.click();
                  
//Handling Child popup-Aooroval Sent//                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { } 
                  
                  Alert alert = driver.switchTo().alert();
                  alert.accept(); 
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { } 
                  
                  //driver.close();
                  //driver.quit();
                  
 //Login as Sales manager//
                  
                  driver = new FirefoxDriver(); 
                  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
                  driver.get("https://aggreko--CI2.cs82.my.salesforce.com");
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                     //HomePage.lnk_MyAccount(driver).click();
                  LoginPage.txtbx_UserName(driver).sendKeys("sf.systestmanager@aggreko.trial.ci2"); 
                  LoginPage.txtbx_Password(driver).sendKeys("Mercury@123");        
                  LoginPage.btn_LogIn(driver).click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { } 
                
               try {
                   //System.out.println("Thread Sleep: " + getName());
                   Thread.sleep(3000);
               } catch (InterruptedException ex) { } 
               
               driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
               HomePage.clk_sfsearch(driver).click();
               HomePage.clk_sfsearch(driver).sendKeys("Sprint3_TC2_Plan_23");
               
               driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
               Sprint1_RTB_TC5.captureScreenShot(driver);
               
               try {
                   //System.out.println("Thread Sleep: " + getName());
                   Thread.sleep(3000);
               } catch (InterruptedException ex) { } 
               
               WebElement k=HomePage.clk_sfsearchbtn(driver);
               k.click();
             //  
               try {
                   //System.out.println("Thread Sleep: " + getName());
                   Thread.sleep(3000);
               } catch (InterruptedException ex) { } 
               
               WebElement k1=HomePage.clk_firstitem(driver);
               k1.click();

                  
    }
             public static void captureScreenShot(WebDriver ldriver){        	 
            	  // Take screenshot and store as a file format//
            	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
            	try {
            	  // To copy the  screenshot to desired location using copyFile method	 
            	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_3/Sprint3_TC2/screenshot_"+System.currentTimeMillis()+".png"));
            	       }	 
            	catch (IOException e)	 
            	{	 
            	System.out.println(e.getMessage());	 
            	    }         
              }
             
   
     
     }
     
            