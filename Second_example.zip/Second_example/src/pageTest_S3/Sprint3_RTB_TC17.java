package pageTest_S3;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

import java.util.ArrayList;

import pageObjects.Account_NewCreate;

// Import package pageObject//     

import pageObjects.AccountsPage;
import pageObjects.Calendar_event;
import pageObjects.HomePage;
import pageObjects.Leads_NewCreate;
import pageObjects.LoginPage;
import pageObjects.Opportunity_NewCreate;
import pageObjects.SalesPlan_Account;
import pageObjects.Sales_Plan_New;
import pageObjects.Sales_Target_New;
import pageTest.Sprint1_RTB_TC1;
import pageTest_S2.Sprint2_RTB_TC1;
import pageObjects.Sales_Plan_Postcreation;

 
     public class Sprint3_RTB_TC17 {
    	 
    	 /*@AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.quit();
    	     }     	 
    	 */
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void testcase17() {
    	
//Sprint 3	AG-45	2.x.x Manage Sales Plan: Ability to tag an opportunity as source 'Sales Plan'
//Sprint3_RTB_TC17-Create Sp and add acount with opportunities attached.
  	
 //Login As Sales Rep//
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get("https://aggreko--CI2.cs82.my.salesforce.com");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys("sf.systestmanager@aggreko.trial.ci2"); 
        LoginPage.txtbx_Password(driver).sendKeys("Mercury@123");        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
        Sprint3_RTB_TC16.captureScreenShot(driver);
        
//Create an Account//
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
        HomePage.clk_Account(driver).click();    
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint3_RTB_TC17.captureScreenShot(driver);
            
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { } 
        
            WebElement accelement=AccountsPage.fnd_recentaccount(driver);
            //System.out.println("The text "+ accelement.getAttribute("innerHTML"));             
             String accelementtext=accelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(accelementtext.contains("Recent Accounts"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint3_RTB_TC17.captureScreenShot(driver);
              
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            Account_NewCreate.typ_actname(driver).sendKeys("MMKS17");
            Select a=new Select(Account_NewCreate.typ_acsegmnt(driver));
            a.selectByVisibleText("Transactional Customer");
 
            driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS); 
            Account_NewCreate.typ_acPhyst(driver).sendKeys("71 street 6");
            Account_NewCreate.typ_acPhycty(driver).sendKeys("Glasgow");	
            Account_NewCreate.typ_acPhystate(driver).sendKeys("Glasgow");			
            Account_NewCreate.typ_acPhyzipcode(driver).sendKeys("G3 9NS");			
            Account_NewCreate.typ_acPhyctry(driver).sendKeys("United Kingdom");				
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint3_RTB_TC17.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            WebElement b=Account_NewCreate.fnd_savebtn(driver);
            b.click(); 
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint3_RTB_TC17.captureScreenShot(driver);
 //Click on Add New opportunity//
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { } 
            
            WebElement c=Account_NewCreate.clk_acnwoppor(driver);
            c.click();
    
//Update Opportunity fields//
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { } 
            
            Opportunity_NewCreate.typ_opporname(driver).sendKeys("Oppor_Sprint3_TC17_2");
            //Opportunity_NewCreate.typ_opporacname(driver).sendKeys("");
            Opportunity_NewCreate.typ_opporcdate(driver).sendKeys("01/11/2016");
            Opportunity_NewCreate.sel_opporcuurency(driver).click();
           
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
            Select d=new Select(Opportunity_NewCreate.sel_opporcuurency(driver));
            d.selectByVisibleText("GBP - British Pound");
            
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
            Select e=new Select(Opportunity_NewCreate.sel_opporstage(driver));
            e.selectByVisibleText("Develop");
            
            Opportunity_NewCreate.typ_opporonhdate(driver).sendKeys("01/11/2016");
            Opportunity_NewCreate.typ_opporname(driver).click();
            Opportunity_NewCreate.typ_opporoffhdate(driver).sendKeys("01/11/2016");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
            Select f=new Select(Opportunity_NewCreate.sel_opporprdfly(driver));
            f.selectByVisibleText("Air - Compressor");
            
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
            Leads_NewCreate.ldsel_prdflyrbt(driver).click();
            
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
            Select g=new Select(Opportunity_NewCreate.sel_opporldsrc(driver));
            g.selectByVisibleText("Telemarketing");
            
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
            Account_NewCreate.fnd_savebtn(driver).click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }              
            Sprint3_RTB_TC17.captureScreenShot(driver);
        
//Create Sales Target//
            
                        try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(2000);
            } catch (InterruptedException ex) { }  
                        HomePage.clk_sltrgt(driver).click();
              
                        try {
                            //System.out.println("Thread Sleep: " + getName());
                            Thread.sleep(2000);
                        } catch (InterruptedException ex) { }  
            WebElement stgtelement=AccountsPage.fnd_recentsltgts(driver);
            
            System.out.println("The text "+ stgtelement.getAttribute("innerHTML"));             
             String stgtelementtext=stgtelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(stgtelementtext.contains("Recent Sales Targets"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }              
             Sprint3_RTB_TC17.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sales_Target_New.typ_sltrgtname(driver).sendKeys("Sprint3_TC17_Targ2");
             
             Select h=new Select(Sales_Target_New.typ_sltgcncy(driver));
             h.selectByVisibleText("GBP - British Pound");
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             WebElement k=Sales_Target_New.clk_sltsv(driver);
             k.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { }              
             Sprint3_RTB_TC17.captureScreenShot(driver);
             
//Create Sales Plan//
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }   
                 HomePage.clk_slplan(driver).click();                 
                              
                 Sprint3_RTB_TC17.captureScreenShot(driver);                 
                 
                 try {
                     //System.out.println("Thread Sleep: " + getName());
                     Thread.sleep(2000);
                 } catch (InterruptedException ex) { }                 
                 WebElement splnelement=AccountsPage.fnd_recentslplans(driver);
                // System.out.println("The text "+ splnelement.getAttribute("innerHTML"));             
                  String splnelementtext=splnelement.getAttribute("innerHTML");         
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
                  if(splnelementtext.contains("Recent Sales Plans"))
                  {
                 	AccountsPage.clk_nwbtn(driver).click();
                  }
               
                            
                  Sprint3_RTB_TC17.captureScreenShot(driver);
                  
                  
                  Sales_Plan_New.typ_slplnnme(driver).sendKeys("Sprint3_TC17_Plan_2");
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                  Sales_Plan_New.typ_slplntgt(driver).sendKeys("Sprint3_TC17_Targ2");
                  
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);            
                  Sprint3_RTB_TC17.captureScreenShot(driver);
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }  

                  WebElement l=Sales_Plan_New.clk_slplnsv(driver);
                  l.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC17.captureScreenShot(driver);
                  
        
//Add Account to Sales Plan//        
                  
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(2000);
                  } catch (InterruptedException ex) { }  
                  Sales_Plan_Postcreation.clk_spnaccslpln(driver).click();
                  
                 Sprint3_RTB_TC17.captureScreenShot(driver);
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }  
                  ArrayList<String> s = new ArrayList<String>(driver.getWindowHandles());
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { } 
                  driver.switchTo().window(s.get(1));
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(7000);
                  } catch (InterruptedException ex) { } 
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC17.captureScreenShot(driver);
                 
   //Add the Sales plan to Account-1//      
                  
                  //Search-AG 396//
                  
                  Sales_Plan_Postcreation.typ_acctsrchsp(driver).click();
                  Sales_Plan_Postcreation.typ_acctsrchsp(driver).sendKeys("MMKS17");
                  
                  WebElement m1=SalesPlan_Account.clk_spacfirst(driver);
                  m1.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { } 
                 
                  SalesPlan_Account.typ_spexprevenue1(driver).click();
                  SalesPlan_Account.typ_spexprevenue1(driver).sendKeys("10000");
                  
                  Select s1=new Select(SalesPlan_Account.sel_spactyfreq1(driver));
                  s1.selectByVisibleText("High");
                  
                          
                  Sprint3_RTB_TC17.captureScreenShot(driver);
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { } 
                  WebElement m=SalesPlan_Account.clk_spacsave(driver);
                  m.click();
        
    }
  //Screenshot  
    public static void captureScreenShot(WebDriver ldriver){        	 
  	  // Take screenshot and store as a file format//
  	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
  	try {
  	  // To copy the  screenshot to desired location using copyFile method	 
  	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_3/Sprint3_TC17/screenshot_"+System.currentTimeMillis()+".png"));
  	       }	 
  	catch (IOException e)	 
  	{	 
  	System.out.println(e.getMessage());	 
  	    }         
    }
   


}

  