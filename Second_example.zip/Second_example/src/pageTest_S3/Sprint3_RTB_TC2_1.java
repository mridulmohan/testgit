package pageTest_S3;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.Alert;
import java.util.ArrayList;


  // Import package pageObject//     

import pageObjects.AccountsPage;
import pageObjects.All_Edit_Clone;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.Sales_Plan_New;
import pageObjects.Sales_Target_New;
import pageTest.Sprint1_RTB_TC5;
import pageObjects.Sales_Plan_Postcreation;

 
     public class Sprint3_RTB_TC2_1 {
    	 
    	 
    	/* @AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     } */
    	 
        private static WebDriver driver = null;
    @Test(enabled=true)
    
       public void testcase2() throws Exception {
    	
//"REG-S3-Create a sales plan-This test case verifies creation of a Sales Plan//
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_3.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(7).getCell(1,0).getContents();
   	 String username=wb.getSheet(7).getCell(1,1).getContents();
   	 String password=wb.getSheet(7).getCell(1,2).getContents();    	 
   	 String spname=wb.getSheet(7).getCell(1,3).getContents();
   	 String targname=wb.getSheet(7).getCell(1,4).getContents();    	 
   	 String jan=wb.getSheet(7).getCell(1,5).getContents();   	 
   	 String feb=wb.getSheet(7).getCell(1,6).getContents();   	 
   	 String march=wb.getSheet(7).getCell(1,7).getContents();   	 
   	 String april=wb.getSheet(7).getCell(1,8).getContents();   	 
   	 String may=wb.getSheet(7).getCell(1,9).getContents();   	 
   	 String june=wb.getSheet(7).getCell(1,10).getContents();
   	 String july=wb.getSheet(7).getCell(1,11).getContents();
   	 String aug=wb.getSheet(7).getCell(1,12).getContents();
   	 String sep=wb.getSheet(7).getCell(1,13).getContents();
   	 String oct=wb.getSheet(7).getCell(1,14).getContents(); 
   	 String nov=wb.getSheet(7).getCell(1,15).getContents(); 
   	 String dec=wb.getSheet(7).getCell(1,15).getContents();
   	 
 //-------------------------------------------------------------------------------------------------------------------------//
//**************************Sales Rep creates a Sales plan*********************************//
   	 
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click();
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
        Sprint3_RTB_TC1.captureScreenShot(driver);
 
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }   
                 HomePage.clk_slplan(driver).click();
                 
                 try {
                     //System.out.println("Thread Sleep: " + getName());
                     Thread.sleep(2000);
                 } catch (InterruptedException ex) { }              
                 Sprint3_RTB_TC1.captureScreenShot(driver);
                 
                 
                 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
                 WebElement splnelement=AccountsPage.fnd_recentslplans(driver);
                 System.out.println("The text "+ splnelement.getAttribute("innerHTML"));             
                  String splnelementtext=splnelement.getAttribute("innerHTML");         
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
                  if(splnelementtext.contains("Recent Sales Plans"))
                  {
                 	AccountsPage.clk_nwbtn(driver).click();
                  }
               
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC1.captureScreenShot(driver);
                  
                  
                  Sales_Plan_New.typ_slplnnme(driver).sendKeys(spname);
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                  Sales_Plan_New.typ_slplntgt(driver).sendKeys(targname);
                  
                  Sales_Plan_New.typ_slplnjanrev(driver).sendKeys(jan);
                  Sales_Plan_New.typ_slplnfebrev(driver).sendKeys(feb);
                  Sales_Plan_New.typ_slplnmarrev(driver).sendKeys(march);
                  Sales_Plan_New.typ_slplnaprrev(driver).sendKeys(april);
                  Sales_Plan_New.typ_slplnmayrev(driver).sendKeys(may);
                  Sales_Plan_New.typ_slplnjunrev(driver).sendKeys(june);
                  Sales_Plan_New.typ_slplnjulyrev(driver).sendKeys(july);
                  Sales_Plan_New.typ_slplnaugrev(driver).sendKeys(aug);
                  Sales_Plan_New.typ_slplnseprev(driver).sendKeys(sep);
                  Sales_Plan_New.typ_slplnoctrev(driver).sendKeys(oct);
                  Sales_Plan_New.typ_slplnnovrev(driver).sendKeys(nov);
                  Sales_Plan_New.typ_slplndecrev(driver).sendKeys(dec);
                  
              
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);            
                  Sprint3_RTB_TC1.captureScreenShot(driver);
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { } 

                  WebElement d=Sales_Plan_New.clk_slplnsv(driver);
                  d.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(3000);
                  } catch (InterruptedException ex) { }              
                  Sprint3_RTB_TC1.captureScreenShot(driver);
                  
                  WebElement c1=All_Edit_Clone.fnd_editbtn(driver);
                  c1.click();

                  
                  System.out.println("Sales Plan created successfully::"+spname);
                  System.out.println("Sprint3_TC2 Pass..Please verify SS..");
                  

                  
    }
             public static void captureScreenShot(WebDriver ldriver){        	 
            	  // Take screenshot and store as a file format//
            	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
            	try {
            	  // To copy the  screenshot to desired location using copyFile method	 
            	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_3/Sprint3_TC2/screenshot_"+System.currentTimeMillis()+".png"));
            	       }	 
            	catch (IOException e)	 
            	{	 
            	System.out.println(e.getMessage());	 
            	    }         
              }
             
   
     
     }
     
            