package pageTest_S3;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     

import pageObjects.AccountsPage;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.Sales_Plan_New;
import pageObjects.Sales_Target_New;
import pageObjects.Sales_Territory_New;
import pageObjects.All_Edit_Clone;

 
     public class Sprint3_RTB_TC11 {
    	 
    	 
    	 @AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     } 
    	 
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void ART_628() throws Exception {
    	
//Sprint 3	AG-53	2.x.x Manage Sales Plan: Create a sales territory
//Sprint3_RTB_TC11-This is for ART-337-Creation of a Territory as Admin/Manager and Negative for sys rep
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_3.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(13).getCell(1,0).getContents();
   	 String username=wb.getSheet(13).getCell(1,1).getContents();
   	 String password=wb.getSheet(13).getCell(1,2).getContents();    	 
     String ttyname=wb.getSheet(13).getCell(1,3).getContents();     	 
   	 String ttytyp=wb.getSheet(13).getCell(1,4).getContents();   
   	 
 //-------------------------------------------------------------------------------------------------------------------------//

 //Admin-Able to create a Territory Successfully//
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
        Sprint3_RTB_TC11.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }   
            HomePage.clk_slterity(driver).click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(2000);
            } catch (InterruptedException ex) { }              
            Sprint3_RTB_TC11.captureScreenShot(driver);
            
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement stgtelement=AccountsPage.fnd_recentsltgts(driver);
            System.out.println("The text "+ stgtelement.getAttribute("innerHTML"));             
             String stgtelementtext=stgtelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(stgtelementtext.contains("Recent Territories"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }              
             Sprint3_RTB_TC11.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sales_Territory_New.typ_strynam(driver).sendKeys(ttyname);
             
           Sales_Territory_New.sel_strytyp(driver).click();
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  
             
             Select a=new Select(Sales_Territory_New.sel_strytyp(driver));
             a.selectByVisibleText(ttytyp);
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             WebElement b=Sales_Territory_New.clk_strysv(driver);
             b.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { }              
             Sprint3_RTB_TC11.captureScreenShot(driver);
  
             WebElement b1=All_Edit_Clone.fnd_editbtn(driver);
             b1.click();

                  
             
    }
             public static void captureScreenShot(WebDriver ldriver){        	 
            	  // Take screenshot and store as a file format//
            	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
            	try {
            	  // To copy the  screenshot to desired location using copyFile method	 
            	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_3/Sprint3_TC11/screenshot_"+System.currentTimeMillis()+".png"));
            	       }	 
            	catch (IOException e)	 
            	{	 
            	System.out.println(e.getMessage());	 
            	    }         
              }
             
   
     
     }
     
            