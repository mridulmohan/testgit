package pageTest_S3;
 
     import java.io.File;
     import java.io.IOException;
     import java.util.concurrent.TimeUnit; 
     import org.openqa.selenium.WebDriver;
     import org.openqa.selenium.WebElement;
     import org.openqa.selenium.firefox.FirefoxDriver;
     import org.openqa.selenium.support.ui.Select;
     import org.testng.annotations.AfterTest;
     import org.testng.annotations.Test;
     //import org.openqa.selenium.By;
     //import org.openqa.selenium.*;
     import jxl.Workbook;
     import org.apache.commons.io.FileUtils;
     import org.openqa.selenium.OutputType;
     import org.openqa.selenium.TakesScreenshot;
     import java.io.FileOutputStream;
     import java.io.FileInputStream;
     //import org.apache.poi.xssf.usermodel.XSSFCell;     
 	//import org.apache.poi.xssf.usermodel.XSSFRow;
 	import org.apache.poi.xssf.usermodel.XSSFSheet;
 	import org.apache.poi.xssf.usermodel.XSSFWorkbook;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;

 
     public class Sprint3_RTB_TC26{
    	 
    	 /*@AfterTest
    	 public void tearDown() throws Exception { 
    		 driver.close();
    	   driver.quit();
    	     }  */
    	         
    	 private static WebDriver driver = null;        
         
                  
    @Test(enabled=true)
       public void testcase26() throws Exception {
    	
//REG-S3-Validate Customer Credit Information in Salesforce 
//REG-S3-Validate Get Orders in Salesforce for new M3 Customer on new account which has more than 5 agreement number


    	
//-------------------------------------------------------------------------------------------------------------------------//
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_3.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(4).getCell(1,0).getContents();
   	 String username=wb.getSheet(4).getCell(1,1).getContents();
   	 String password=wb.getSheet(4).getCell(1,2).getContents();   	 
   	 String accname=wb.getSheet(4).getCell(1,3).getContents();
   	 String aggloc=wb.getSheet(4).getCell(1,4).getContents();   	
   	 String actaic=wb.getSheet(4).getCell(1,5).getContents();   	 
   	 String actst=wb.getSheet(4).getCell(1,6).getContents();   	 
   	 String segmnt=wb.getSheet(4).getCell(1,7).getContents();   	 
   	 String Physt=wb.getSheet(4).getCell(1,8).getContents();   	 
   	 String Phycty=wb.getSheet(4).getCell(1,9).getContents();   	 
   	 String Phystate=wb.getSheet(4).getCell(1,10).getContents();
   	 String zipcode=wb.getSheet(4).getCell(1,11).getContents();
   	 String Phyctry=wb.getSheet(4).getCell(1,12).getContents();
   	 String m3num=wb.getSheet(4).getCell(1,13).getContents();
   	//String pymtyp=wb.getSheet(4).getCell(1,14).getContents();
   	
   
   	 
  //-------------------------------------------------------------------------------------------------------------------------//  	

   	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");    	
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 							//Login User name//
        LoginPage.txtbx_Password(driver).sendKeys(password);        					//Login password	
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint3_RTB_TC26.captureScreenShot(driver);
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
        HomePage.clk_Account(driver).click();    
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint3_RTB_TC26.captureScreenShot(driver);
            
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { } 
        
            WebElement accelement=AccountsPage.fnd_recentaccount(driver);
            System.out.println("The text "+ accelement.getAttribute("innerHTML"));             
             String accelementtext=accelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(accelementtext.contains("Recent Accounts"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint3_RTB_TC26.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
              
              
            Account_NewCreate.typ_actname(driver).sendKeys(accname);			//Account name//
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Select a=new Select(Account_NewCreate.sel_aggloc(driver));
            a.selectByVisibleText(aggloc);										//Location//
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Select b=new Select(Account_NewCreate.sel_actaic(driver));
            b.selectByVisibleText(actaic);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Select b1=new Select(Account_NewCreate.sel_actst(driver));
            b1.selectByVisibleText(actst);
                     
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Select c=new Select(Account_NewCreate.typ_acsegmnt(driver));			//Segment//
            c.selectByVisibleText(segmnt);
        
            driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS); 
            Account_NewCreate.typ_acPhyst(driver).sendKeys(Physt);					//Address-Street//
            Account_NewCreate.typ_acPhycty(driver).sendKeys(Phycty);				//City//
            Account_NewCreate.typ_acPhystate(driver).sendKeys(Phystate);			//State//
            Account_NewCreate.typ_acPhyzipcode(driver).sendKeys(zipcode);			//Zip-code//
            Account_NewCreate.typ_acPhyctry(driver).sendKeys(Phyctry);				//Country//				
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint3_RTB_TC26.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            WebElement x=Account_NewCreate.fnd_savebtn(driver);
            x.click(); 
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }  
            Sprint3_RTB_TC26.captureScreenShot(driver);
            
            System.out.println("Account created successfully..");
  
//------------------Account Created-Edit Account to enter M3 number---------------//            
//------------------Edit-Created Account-----------------------------------------//
    		
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }  
    		 WebElement actedit=All_Edit_Clone.fnd_accountdetail(driver);
    	     System.out.println("The text "+ actedit.getAttribute("innerHTML"));    	      
    	      String actedittext=actedit.getAttribute("innerHTML");    	  
    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);     	      
    	      if(actedittext.contains("Account Detail"))
    	      {
    	    	  All_Edit_Clone.fnd_editbtn(driver).click();
    	      }
    	      
    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	        Sprint3_RTB_TC26.captureScreenShot(driver);

    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);    	      
    	      Account_NewCreate.typ_m3cust(driver).sendKeys(m3num);				//M3 number//
    	      
    	     
    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	      Sprint3_RTB_TC26.captureScreenShot(driver);
    	          
    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
              WebElement y=Account_NewCreate.fnd_savebtn(driver);
              y.click();
  //------------------------------------------------------------------------------------------------------------//
  //********Click On Credit Limit Info************//
              
              try {
                  //System.out.println("Thread Sleep: " + getName());
                  Thread.sleep(5000);
              } catch (InterruptedException ex) { }  
              Sprint3_RTB_TC26.captureScreenShot(driver);
              WebElement p=All_Edit_Clone.clk_orders(driver);
              p.click();
              
//Handling New Window// 
           
              try{
            	  Thread.sleep(7000);
            	  for(String winHandle:driver.getWindowHandles())
            			
            	  		  {
            		  driver.switchTo().window(winHandle);
            			  }
            	  
            	  driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
            	  //String pm=M3_Credit_limit_Info.fnd_currency(driver).getText();--Replace with Invoice page code
            	  //System.out.println("Currency is " +pm);            	  
                  Sprint3_RTB_TC26.captureScreenShot(driver);
                  
                  driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
            	    Sprint3_RTB_TC26.captureScreenShot(driver);
                          	  
              }catch(Exception e)              
              {
            	  System.out.println(e);
              }
              
              
             
              }        
  
          
    
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_3/Sprint3_TC26/screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }         
       }
   	
    }
    	
    