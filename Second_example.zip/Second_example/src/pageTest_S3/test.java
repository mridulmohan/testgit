package pageTest_S3;
 
     import java.io.File;
     import java.io.IOException;
     import java.util.concurrent.TimeUnit; 
     import org.openqa.selenium.WebDriver;
     import org.openqa.selenium.WebElement;
     import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     

import pageObjects.HomePage;
import pageObjects.LoginPage;


 
     public class test{
    	 
    	     	 
         private static WebDriver driver = null;        
         
         
    @Test(enabled=true)
       public void testcase5() {
    	
//AG-38	2.x.x Create Leads-Search leads//
//Search for any terms with keywords in Search field//

    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get("https://aggreko--CI2.cs82.my.salesforce.com");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click(); 
        LoginPage.txtbx_UserName(driver).sendKeys("sf.systestrep@aggreko.trial.ci2"); 
        LoginPage.txtbx_Password(driver).sendKeys("Welcome1");        
        LoginPage.btn_LogIn(driver).click();
        
        //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        //Sprint1_RTB_TC5.captureScreenShot(driver);
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
        HomePage.clk_Leads(driver).click();   
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
        HomePage.clk_sfsearch(driver).click();
        HomePage.clk_sfsearch(driver).sendKeys("Sprint3_TC2_Plan_23");
        
        //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
       // Sprint1_RTB_TC5.captureScreenShot(driver);
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
        
        WebElement k=HomePage.clk_sfsearchbtn(driver);
        k.click();
        HomePage.clk_sfsearchbtn(driver).click();
 
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
        
        WebElement k1=HomePage.clk_plansrch(driver);
        k1.click();
        
        
    }
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint1_TC5/TC5screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }  
     }
     }
     