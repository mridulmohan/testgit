package pageTest_S3;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import java.util.ArrayList;

// Import package pageObject//     

import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Calendar_event;
import pageObjects.HomePage;
import pageObjects.Leads_NewCreate;
import pageObjects.LoginPage;
import pageObjects.Opportunity_NewCreate;
import pageObjects.SalesPlan_Account;
import pageObjects.Sales_Plan_New;
import pageObjects.Sales_Target_New;
import pageObjects.All_Edit_Clone;
import pageTest_S2.Sprint2_RTB_TC1;
import pageObjects.Sales_Plan_Postcreation;
import pageObjects.Sales_Territory_New;

 
     public class Sprint3_RTB_TC20 {
    	 
    	 /*@AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     }   */  	 
    	 
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void ART_636() throws Exception {
    	
//Sprint 3	AG-57	2.x.x Manage Sales Plan: Maintain a sales territory hierarchy
//Admin create a territory with City
//Search and Modify,change owner
    	
//---------------------------------------------------------------------------------------------------//
   	 
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_3.xls");
    		 System.out.println("Excel located");        	 
    		 Workbook wb=Workbook.getWorkbook(src);        	 
    		 System.out.println("Excel loaded");
    	 String url=wb.getSheet(17).getCell(1,0).getContents();
    	 String username=wb.getSheet(17).getCell(1,1).getContents();
    	 String password=wb.getSheet(17).getCell(1,2).getContents();
    	 String ttyname=wb.getSheet(17).getCell(1,3).getContents();
    	 String ttytyp=wb.getSheet(17).getCell(1,4).getContents();
    	 String ttyarea=wb.getSheet(17).getCell(1,5).getContents();
    	 String ttyowner=wb.getSheet(17).getCell(1,6).getContents();
    	 String ttynwarea=wb.getSheet(17).getCell(1,7).getContents();
    	 

//--------------------------------------------------------------------------------------------------//      
  	
 //Login As Admin//
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
        Sprint3_RTB_TC20.captureScreenShot(driver);
        
//Create a Sales Territory//
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
        HomePage.clk_slterity(driver).click();    
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint3_RTB_TC20.captureScreenShot(driver);
            
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { } 
        
            WebElement ttyelement=AccountsPage.fnd_recentsltrty(driver);
            //System.out.println("The text "+ accelement.getAttribute("innerHTML"));             
             String ttyelementtext=ttyelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(ttyelementtext.contains("Recent Territories"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint3_RTB_TC20.captureScreenShot(driver);
        
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { } 
             
             Sales_Territory_New.typ_strynam(driver).sendKeys(ttyname);
             
             Select r=new Select(Sales_Territory_New.sel_strytyp(driver));
             r.selectByVisibleText(ttytyp);
             
            Sales_Territory_New.typ_stryarea(driver).sendKeys(ttyarea);
             //f.selectByVisibleText("");
          
             Sales_Territory_New.typ_stryprown(driver).sendKeys(ttyowner);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 
             WebElement b=Sales_Territory_New.clk_strysv(driver);
             b.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 
             
             Sprint3_RTB_TC20.captureScreenShot(driver);
//*********Search for Sales territory created******//
        
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
             HomePage.clk_sfsearch(driver).click();
             HomePage.clk_sfsearch(driver).sendKeys(ttyname);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint3_RTB_TC20.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { }
             Sprint3_RTB_TC20.captureScreenShot(driver);
             
             WebElement k=HomePage.clk_sfsearchbtn(driver);
             k.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { }
             Sprint3_RTB_TC20.captureScreenShot(driver);
             
//*******To search and click-Territory-Use Display name*************//       
                     
             int Row_count = driver.findElements(By.xpath("//*[@id='CAP_AG_Territory__c_body']/table/tbody/tr")).size();
             System.out.println("Number Of Rows = "+Row_count);
             
             		String  xpath_first="//*[@id='CAP_AG_Territory__c_body']/table/tbody/tr[";        
             		String xpath_last="]/th/a";

             		for (int i=2; i<=Row_count; i++)
             		{

             		String TTYNAME=driver.findElement(By.xpath(xpath_first+i+xpath_last)).getText();
             				if(TTYNAME.equalsIgnoreCase(ttyname)){
             					System.out.println("Territory found");
             					WebElement m=driver.findElement(By.xpath(xpath_first+i+xpath_last));
             					m.click();  
             					break;
             				}else{
             					System.out.println("Territory not found");
             				}
             		}           
             
//********************Edit and Change Area of the territory***********//
             		  try {
                          //System.out.println("Thread Sleep: " + getName());
                          Thread.sleep(2000);
                      } catch (InterruptedException ex) { }
             		WebElement l=All_Edit_Clone.fnd_editbtn(driver);
             		l.click();
             		
             		try {
                        //System.out.println("Thread Sleep: " + getName());
                        Thread.sleep(2000);
                    } catch (InterruptedException ex) { }
                    Sprint3_RTB_TC20.captureScreenShot(driver);
             		
             		  try {
                          //System.out.println("Thread Sleep: " + getName());
                          Thread.sleep(5000);
                      } catch (InterruptedException ex) { }
             		Sales_Territory_New.typ_stryarea(driver).clear();
             		Sales_Territory_New.typ_stryarea(driver).sendKeys(ttynwarea);
             		
             		try {
                        //System.out.println("Thread Sleep: " + getName());
                        Thread.sleep(2000);
                    } catch (InterruptedException ex) { }
                    Sprint3_RTB_TC20.captureScreenShot(driver);
             		
             		 WebElement m=Sales_Territory_New.clk_strysv(driver);
                     m.click();
                     
                     try {
                         //System.out.println("Thread Sleep: " + getName());
                         Thread.sleep(2000);
                     } catch (InterruptedException ex) { }
                     Sprint3_RTB_TC20.captureScreenShot(driver);
             		
 System.out.println("Sprint_3 test case 20 successful..Please verify SS..");
                     
    }
  //Screenshot  
    public static void captureScreenShot(WebDriver ldriver){        	 
  	  // Take screenshot and store as a file format//
  	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
  	try {
  	  // To copy the  screenshot to desired location using copyFile method	 
  	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_3/Sprint3_TC20/screenshot_"+System.currentTimeMillis()+".png"));
  	       }	 
  	catch (IOException e)	 
  	{	 
  	System.out.println(e.getMessage());	 
  	    }         
    }
   


}

  