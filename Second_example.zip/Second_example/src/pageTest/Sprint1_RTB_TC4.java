package pageTest;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.HomePage;
import pageObjects.Lead_Convert;
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;

 
     public class Sprint1_RTB_TC4{
    	
    	 @AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     } 
    	 
         private static WebDriver driver = null;        
        
    @Test(enabled=true)
       public void  ART_515() throws Exception{
    	
//AG-93	2.x.x Qualify Lead to Opportunity: Convert lead to opportunity
    	//1.Create Lead with mandatory parameters and convert it when it is Open
    	//2.Edit Lead to Qualify and covert-Verify msg for Phone No
    	//3.Edit lead with Ph no and convert-Verify msg for AIC
    	//4.Successfully convert after entering all mandatory parameters
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_1.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(3).getCell(1,0).getContents();
   	 String username=wb.getSheet(3).getCell(1,1).getContents();
   	 String password=wb.getSheet(3).getCell(1,2).getContents();
   	 String ldtitle=wb.getSheet(3).getCell(1,3).getContents();
     String ldfname=wb.getSheet(3).getCell(1,4).getContents();     	 
   	 String ldlname=wb.getSheet(3).getCell(1,5).getContents();
   	 String ldstatus=wb.getSheet(3).getCell(1,6).getContents();
   	 String ldsrc=wb.getSheet(3).getCell(1,7).getContents();
   	 String ldcmpny=wb.getSheet(3).getCell(1,8).getContents();
   	 String onholdrsn=wb.getSheet(3).getCell(1,9).getContents();
   	 String onholddate=wb.getSheet(3).getCell(1,10).getContents();
   	 String ldphno=wb.getSheet(3).getCell(1,11).getContents();
   	 String ldaic=wb.getSheet(3).getCell(1,12).getContents();
   	
 
 //-------------------------------------------------------------------------------------------------------------------------//    	


    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click(); 
        LoginPage.txtbx_UserName(driver).sendKeys(username); 		//Login User Name
        LoginPage.txtbx_Password(driver).sendKeys(password);        						//Login Password
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint1_RTB_TC4.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }    
        HomePage.clk_Leads(driver).click(); 
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint1_RTB_TC4.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement leadelement=AccountsPage.fnd_recentleads(driver);
            System.out.println("The text "+ leadelement.getAttribute("innerHTML"));             
             String leadelementtext=leadelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(leadelementtext.contains("Recent Leads"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC4.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.sel_fnameddwn(driver).sendKeys(ldtitle);						//First name-Salutation
             Leads_NewCreate.typ_leadfname(driver).sendKeys(ldfname);  						//Lead First name         
             Leads_NewCreate.typ_leadlname(driver).sendKeys(ldlname);   					//Lead last name
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Select a=new Select( Leads_NewCreate.sel_leadstatus(driver));
             a.selectByVisibleText(ldstatus);												//Lead Status
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Select n=new Select( Leads_NewCreate.sel_leadsource(driver));
             n.selectByVisibleText(ldsrc);													//Lead Source
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.typ_leadncmpny(driver).sendKeys(ldcmpny); 						//LEAD COMPANY
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC4.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }   
             WebElement x=Account_NewCreate.fnd_savebtn(driver);
             x.click();
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC4.captureScreenShot(driver);
             
 //Lead creation successful//
 //TRY-Covert Lead to Opportunity-Verify Message--CHECK FOR CONVERT BUTTON//
//CHECK PRESENCE OF CONVERT BUTTON            
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  
             
             
             try
             {
             if(All_Edit_Clone.fnd_ldconvrt(driver).isDisplayed())
             {
            	 System.out.println("**Error***Convert Button found for Open");    
             }
             }
             catch(Exception e1)
             {
            	 System.out.println("Convert Button Not found-Open stage Pass..");
             }
             
//----------------------------------------------------------------------------------------------------------------//
//CONVERT LEAD TO ON HOLD AND TRY-CONVERTING TO OPPORTUNITY//   
             
             
             System.out.println("Changing Open lead to On-Hold..Please wait..Convert Button should not be displayed..");
                      
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  
             WebElement r=All_Edit_Clone.fnd_editbtn(driver);
             r.click();
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC4.captureScreenShot(driver);
             
             Select a1=new Select( Leads_NewCreate.sel_leadstatus(driver));
             a1.selectByVisibleText("On Hold");	             
                  
             Leads_NewCreate.typ_leadonhldrsn(driver).sendKeys(onholdrsn);
             Leads_NewCreate.sel_leadonhlddat(driver).sendKeys(onholddate);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  
             WebElement b=Account_NewCreate.fnd_savebtn(driver);
             b.click();
           
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  
             Sprint1_RTB_TC4.captureScreenShot(driver);
             
             try
             {
             if(All_Edit_Clone.fnd_ldconvrt(driver).isDisplayed())
             {
            	 System.out.println("**Error***Convert Button found for On Hold");    
             }
             }
             catch(Exception e1)
             {
            	 System.out.println("Convert Button Not found");
             }

             
 //----------------------------------------------------------------------------------------------------------------//
 //CONVERT LEAD TO QUALIFIED AND TRY-CONVERTING TO OPPORTUNITY//             
             
             System.out.println("Changing Open lead to Qualified..Please wait..Convert Button should be displayed..");
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  
             WebElement e=All_Edit_Clone.fnd_editbtn(driver);
             e.click();
             
             Select a2=new Select( Leads_NewCreate.sel_leadstatus(driver));
             a2.selectByVisibleText("Qualified");	            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);     
             Leads_NewCreate.typ_leadphone(driver).sendKeys(ldphno);
             Select a3=new Select( Leads_NewCreate.sel_leadaic(driver));
             a3.selectByVisibleText(ldaic);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC4.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  ;
             WebElement f=Account_NewCreate.fnd_savebtn(driver);
             f.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 
             Sprint1_RTB_TC4.captureScreenShot(driver);
             
             try
             {
             if(All_Edit_Clone.fnd_ldconvrt(driver).isDisplayed())
             {
            	 System.out.println("Convert Button found for Qualified....");    
             }
             }
             catch(Exception e1)
             {
            	 System.out.println("***Error***Convert Button Not found for Qualified..");
             }
             
//-------------------------------------------------------------------------------------------------------------------//
//CONVERT OPPORTUNITY//             

             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
             All_Edit_Clone.fnd_ldconvrt(driver).click();  
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC4.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Lead_Convert.typ_actytyp(driver).sendKeys("Call");
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  
             WebElement g=Lead_Convert.clk_ldcnrtbtn(driver);
             g.click();
                      
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC4.captureScreenShot(driver);
           
             System.out.println("S1_Testcase4_pass..Please verify SS...");
            
    }
    
    
    public static void captureScreenShot(WebDriver ldriver){        	 
   	  // Take screenshot and store as a file format//
   	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
   	try {
   	  // To copy the  screenshot to desired location using copyFile method	 
   	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_1/Sprint1_TC4/screenshot_"+System.currentTimeMillis()+".png"));
   	       }	 
   	catch (IOException e)	 
   	{	 
   	System.out.println(e.getMessage());	 
   	    }         
     }
    
     }