package pageTest;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;


 
     public class Sprint1_RTB_TC8_1{
    	 
    	 @AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     } 
    	   
         private static WebDriver driver = null;
         
//AG-74	Qualify Lead to Opportunity: Assign Lead Status
//Sprint1_RTB_TC8_1-Verify mandatory parameters when changing Open to Qualified//   
         
         
       
    @Test(enabled=true)
       public void ART_519() throws Exception{    
    	
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_1.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(7).getCell(1,0).getContents();
   	 String username=wb.getSheet(7).getCell(1,1).getContents();
   	 String password=wb.getSheet(7).getCell(1,2).getContents();
   	 String ldtitle=wb.getSheet(7).getCell(1,3).getContents();
     String ldfname=wb.getSheet(7).getCell(1,4).getContents();  
     String ldlname=wb.getSheet(7).getCell(1,5).getContents();     
     String ldsource=wb.getSheet(7).getCell(1,6).getContents();     
     String ldcomp=wb.getSheet(7).getCell(1,7).getContents();
     String ldmobno=wb.getSheet(7).getCell(1,8).getContents();     
     String ldaic=wb.getSheet(7).getCell(1,9).getContents();
     
 
//-------------------------------------------------------------------------------------------------------------------------//     	

    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click(); 
        LoginPage.txtbx_UserName(driver).sendKeys(username); 								//Login Username
        LoginPage.txtbx_Password(driver).sendKeys(password);        						//Login Password
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint1_RTB_TC8_1.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }  
        HomePage.clk_Leads(driver).click();       
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement leadelement=AccountsPage.fnd_recentleads(driver);
            System.out.println("The text "+ leadelement.getAttribute("innerHTML"));             
             String leadelementtext=leadelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(leadelementtext.contains("Recent Leads"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
             
             try {
               Thread.sleep(3000);
             } catch (InterruptedException ex) { }  
             Sprint1_RTB_TC8_1.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.sel_fnameddwn(driver).sendKeys(ldtitle);					//Title
             Leads_NewCreate.typ_leadfname(driver).sendKeys(ldfname);       		    //First name 	
             Leads_NewCreate.typ_leadlname(driver).sendKeys(ldlname);   				//Last name
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.sel_leadstatus(driver).sendKeys("Open");
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select g=new Select(Leads_NewCreate.sel_leadsource(driver));
             g.selectByVisibleText(ldsource);											//Lead Source
           
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.typ_leadncmpny(driver).sendKeys(ldcomp); 					//Lead Company
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC8_1.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             WebElement x=Account_NewCreate.fnd_savebtn(driver);
             x.click();
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);   
             Sprint1_RTB_TC8_1.captureScreenShot(driver);
             
//-----------------------------------------------------------------------------------------------------------------------------//
//Edit and Change Lead to Qualified//
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  
             All_Edit_Clone.fnd_editbtn(driver).click();
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC8_1.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select h=new Select(Leads_NewCreate.sel_leadstatus(driver));
             h.selectByVisibleText("Qualified");
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }   
             WebElement y=Account_NewCreate.fnd_savebtn(driver);
             y.click();
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);   
             Sprint1_RTB_TC8_1.captureScreenShot(driver);
 //--------------------------------------------------------------------------------------------------------------------------//            
//Verify error message//
//Review all error messages below to correct your data.
//You need to add a Phone or a Mobile field before you can qualify the lead
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }   
             Leads_NewCreate.typ_leadmobno(driver).click();
             Leads_NewCreate.typ_leadmobno(driver).sendKeys(ldmobno);
                     
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC8_1.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  
             WebElement z=Account_NewCreate.fnd_savebtn(driver);
             z.click();
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);   
             Sprint1_RTB_TC8_1.captureScreenShot(driver);
//----------------------------------------------------------------------------------------------------------------------------//             
//Verify error message//
//Review all error messages below to correct your data.
//Error: Please select an AIC to save the record.
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select j=new Select(Leads_NewCreate.sel_leadaic(driver));
             j.selectByVisibleText(ldaic);
            
             Leads_NewCreate.typ_leadwebsite(driver).click();
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC8_1.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  
             WebElement a=Account_NewCreate.fnd_savebtn(driver);
             a.click(); 
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  
             Sprint1_RTB_TC8_1.captureScreenShot(driver);
             
           //  System.out.println("S1_Testcase8_1_pass..Please verify SS..");
                        
    }
    
    public static void captureScreenShot(WebDriver ldriver){        	 
   	  // Take screenshot and store as a file format//
   	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
   	try {
   	  // To copy the  screenshot to desired location using copyFile method	 
   	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_1/Sprint1_TC8_1/screenshot_"+System.currentTimeMillis()+".png"));
   	       }	 
   	catch (IOException e)	 
   	{	 
   	System.out.println(e.getMessage());	 
   	    }   
    
     }
    
     }