package pageTest;

import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.Opportunity_NewCreate;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.Opportunity_AddTeam;

 
     public class Sprint1_RTB_TC6{
    	 
    	 @AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.quit();
    	     } 
    	 
         private static WebDriver driver = null;        
         
         
    @Test(enabled=true)
       public void ART_517() throws Exception{
    	
//  Sprint-1-2	AG-80	Qualify Lead to Opportunity: Assign resources to opportunity
//	1.Test Case to create Opportunity
//	2.Add team member to opportunity
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_1.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(5).getCell(1,0).getContents();
   	 String username=wb.getSheet(5).getCell(1,1).getContents();
   	 String password=wb.getSheet(5).getCell(1,2).getContents();
   	 String opporcrncy=wb.getSheet(5).getCell(1,3).getContents();
     String oppramnt=wb.getSheet(5).getCell(1,4).getContents();  
     String opprcdate=wb.getSheet(5).getCell(1,5).getContents();     
     String opprname=wb.getSheet(5).getCell(1,6).getContents();     
     String actname=wb.getSheet(5).getCell(1,7).getContents();
     String oppronhdate=wb.getSheet(5).getCell(1,8).getContents();
     String opproffhdate=wb.getSheet(5).getCell(1,9).getContents();
     String oppprdfly=wb.getSheet(5).getCell(1,10).getContents();
     String oppldsrc=wb.getSheet(5).getCell(1,11).getContents();     
     String opprtmusr=wb.getSheet(5).getCell(1,12).getContents();
     String opprtmrole=wb.getSheet(5).getCell(1,13).getContents();
 
//-------------------------------------------------------------------------------------------------------------------------//      	

    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { } 
        Sprint1_RTB_TC6.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
        HomePage.clk_Opportunity(driver).click();
        		      
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
    
        WebElement opporelement=AccountsPage.fnd_recentoppurtunities(driver);
        System.out.println("The text "+ opporelement.getAttribute("innerHTML"));     
        String opporelementtext=opporelement.getAttribute("innerHTML"); 
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);      
        if(opporelementtext.contains("Recent Opportunities"))
        {
        	AccountsPage.clk_nwbtn(driver).click();
        }
     
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Sprint1_RTB_TC6.captureScreenShot(driver);
     
   
     Select m=new Select(Opportunity_NewCreate.sel_opporcuurency(driver));				//Opportunity Currency//
     m.selectByVisibleText(opporcrncy);
     
     Opportunity_NewCreate.typ_opporamnt(driver).sendKeys(oppramnt);					//Amount//
     
     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);    
     Opportunity_NewCreate.typ_opporcdate(driver).sendKeys(opprcdate);  				 //Close Date***//
     
     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
     Opportunity_NewCreate.typ_opporname(driver).click();
     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
     Opportunity_NewCreate.typ_opporname(driver).sendKeys(opprname);     			//   Opportunity Name//
     
     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);     
     Select n=new Select(Opportunity_NewCreate.sel_opporstage(driver));
     n.selectByVisibleText("Develop");     												//Opportunity Stage
     
     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
     Sprint1_RTB_TC6.captureScreenShot(driver);  
     
     Opportunity_NewCreate.typ_opporonhdate(driver).sendKeys(oppronhdate);
     //On Hire date//
     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
     Opportunity_NewCreate.typ_opporacname(driver).sendKeys(actname);			  //Account Name//	
     
     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
     Opportunity_NewCreate.typ_opporoffhdate(driver).sendKeys(opproffhdate);			  //Off hire date//
     
     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
     Opportunity_NewCreate.sel_opporprdfly(driver).click();									 //Product family// 
     Opportunity_NewCreate.sel_opporprdfly(driver).sendKeys(oppprdfly);
     
     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
     Leads_NewCreate.ldsel_prdflyrbt(driver).click();										//Right click//
     
     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);						//Lead Source drop down//
     Select s=new Select(Opportunity_NewCreate.sel_opporldsrc(driver));
     s.selectByVisibleText(oppldsrc);
     
     try {
         //System.out.println("Thread Sleep: " + getName());
         Thread.sleep(3000);
     } catch (InterruptedException ex) { }  
     WebElement x=Account_NewCreate.fnd_savebtn(driver);
     x.click();  
     
     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
     Sprint1_RTB_TC6.captureScreenShot(driver);
     
 //Add team to opportunity//
    
     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
     Opportunity_AddTeam.clk_oatadd(driver).click();
     
     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
     Sprint1_RTB_TC6.captureScreenShot(driver);
     
     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
     Opportunity_AddTeam.sel_oatusr(driver).sendKeys(opprtmusr);			//team User
     
     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
     Sprint1_RTB_TC6.captureScreenShot(driver);
     
     driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 				//Team role//
     Opportunity_AddTeam.sel_oattmrl(driver).click();
     
     
     driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
     Select b=new Select(Opportunity_AddTeam.sel_oattmrl(driver));
     b.selectByVisibleText(opprtmrole);
     
          
     //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
     //Opportunity_AddTeam.sel_oatopac(driver).sendKeys("");----Read only default;Read/Write optional
     
     try {
         //System.out.println("Thread Sleep: " + getName());
         Thread.sleep(5000);
     } catch (InterruptedException ex) { }   
     WebElement y=Opportunity_AddTeam.clt_oatsv(driver);
     y.click();
         
     try {
         //System.out.println("Thread Sleep: " + getName());
         Thread.sleep(5000);
     } catch (InterruptedException ex) { } 
     Sprint1_RTB_TC6.captureScreenShot(driver);
     
     try {
         //System.out.println("Thread Sleep: " + getName());
         Thread.sleep(5000);
     } catch (InterruptedException ex) { } 
    // System.out.println("S1_Testcase6_pass..Please verify SS..");
    
     
    }
    public static void captureScreenShot(WebDriver ldriver){        	 
   	  // Take screenshot and store as a file format//
   	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
   	try {
   	  // To copy the  screenshot to desired location using copyFile method	 
   	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_1/Sprint1_TC6/screenshot_"+System.currentTimeMillis()+".png"));
   	       }	 
   	catch (IOException e)	 
   	{	 
   	System.out.println(e.getMessage());	 
   	    }  
    }
   	
   	
   	
     }
     