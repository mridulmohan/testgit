package pageTest;
 
     import java.io.File;
     import java.io.IOException;
     import java.util.concurrent.TimeUnit; 
     import org.openqa.selenium.WebDriver;
     import org.openqa.selenium.WebElement;
     import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;

 
     public class Sprint1_RTB_TC1{
    	 
    	 /*@AfterTest
    	 public void tearDown() throws Exception { 
    		 driver.close();
    		 driver.quit();
    	     }  */
    	         
    	 private static WebDriver driver = null;        
         
                  
    @Test(enabled=true)
       public void ART_512() throws Exception {
    	
//  Sprint-1-1	AG-124	Manage Customer Account: Create and edit multiple Addresses//
//	1.Test Case to create Account//
//	2.Edit the created Account with non-mandatory fields//
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_1.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(0).getCell(1,0).getContents();
   	 String username=wb.getSheet(0).getCell(1,1).getContents();
   	 String password=wb.getSheet(0).getCell(1,2).getContents();    	 
     String actname=wb.getSheet(0).getCell(1,3).getContents();     	 
   	 String actloc=wb.getSheet(0).getCell(1,4).getContents();
   	 String actaic=wb.getSheet(0).getCell(1,5).getContents();
   	 String actstat=wb.getSheet(0).getCell(1,6).getContents();
   	 String actseg=wb.getSheet(0).getCell(1,7).getContents();
   	String actst=wb.getSheet(0).getCell(1,8).getContents();
   	String actcity=wb.getSheet(0).getCell(1,9).getContents();
   	String actstate=wb.getSheet(0).getCell(1,10).getContents();
   	String actzip=wb.getSheet(0).getCell(1,11).getContents();
   	String actctry=wb.getSheet(0).getCell(1,12).getContents();
 
 //-------------------------------------------------------------------------------------------------------------------------//   	
    	
    	//System.setProperty("driv", "D://Selenium WebDriver//webdriver.gecko.driver.exe");
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click(); 
        LoginPage.txtbx_UserName(driver).sendKeys(username); 							//Login User name//
        LoginPage.txtbx_Password(driver).sendKeys(password);        					//Login password	
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint1_RTB_TC1.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
        HomePage.clk_Account(driver).click();    
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint1_RTB_TC1.captureScreenShot(driver);
            
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { } 
        
            WebElement accelement=AccountsPage.fnd_recentaccount(driver);
            System.out.println("The text "+ accelement.getAttribute("innerHTML"));             
             String accelementtext=accelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(accelementtext.contains("Recent Accounts"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC1.captureScreenShot(driver);
              
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            Account_NewCreate.typ_actname(driver).sendKeys(actname);			//Account name//
            
          
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(2000);
            } catch (InterruptedException ex) { } 
            Select b=new Select(Account_NewCreate.sel_actaic(driver));
            b.selectByVisibleText(actaic);
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(2000);
            } catch (InterruptedException ex) { } 
            Select b1=new Select(Account_NewCreate.sel_actst(driver));
            b1.selectByVisibleText(actstat);
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(2000);
            } catch (InterruptedException ex) { } 
            Select a=new Select(Account_NewCreate.sel_aggloc(driver));
            a.selectByVisibleText(actloc);											//Location//
                     
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(2000);
            } catch (InterruptedException ex) { } 
            Select c=new Select(Account_NewCreate.sel_acttyp(driver));				//Acc Type//
            c.selectByVisibleText(actseg);
        
            driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS); 
            Account_NewCreate.typ_acPhyst(driver).sendKeys(actst);					//Address-Street//
            Account_NewCreate.typ_acPhycty(driver).sendKeys(actcity);				//City//
            Account_NewCreate.typ_acPhystate(driver).sendKeys(actstate);			//State//
            Account_NewCreate.typ_acPhyzipcode(driver).sendKeys(actzip);			//Zip-code//
            Account_NewCreate.typ_acPhyctry(driver).sendKeys(actctry);		//Country//				
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint1_RTB_TC1.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            WebElement x=Account_NewCreate.fnd_savebtn(driver);
            x.click(); 
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }  
            Sprint1_RTB_TC1.captureScreenShot(driver);
   
    //Edit-Created Account//
    		
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }  
    		 WebElement actedit=All_Edit_Clone.fnd_accountdetail(driver);
    	     System.out.println("The text "+ actedit.getAttribute("innerHTML"));    	      
    	      String actedittext=actedit.getAttribute("innerHTML");    	  
    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);     	      
    	      if(actedittext.contains("Account Detail"))
    	      {
    	    	  All_Edit_Clone.fnd_editbtn(driver).click();
    	      }
    	      
    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	        Sprint1_RTB_TC1.captureScreenShot(driver);

    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);    	      
    	     // Account_NewCreate.typ_actwsite(driver).sendKeys("www.Sprinter1114smaple.com");	//Website//
    	     // Account_NewCreate.typ_actprimphno(driver).sendKeys("427273673");					//Phone Number//
    	      //Account_NewCreate.sel_aggloc(driver).sendKeys("London UK");						//Aggreko Location//
    	      //Account_NewCreate.sel_actst(driver).sendKeys("Active");
    	     
    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	      Sprint1_RTB_TC1.captureScreenShot(driver);
    	          
    	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
              WebElement y=Account_NewCreate.fnd_savebtn(driver);
              y.click();
              
              try {
                  //System.out.println("Thread Sleep: " + getName());
                  Thread.sleep(5000);
              } catch (InterruptedException ex) { }  
              Sprint1_RTB_TC1.captureScreenShot(driver);
              
              //System.out.println("S1_Testcase1_pass"); 

    	      
    }
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_1/Sprint1_TC1/screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }         
       }
   	
    }
    	
    