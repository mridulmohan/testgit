package pageTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObjects.AccountsPage;

import java.io.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import java.util.List;  
import java.util.concurrent.TimeUnit;

public class PageObjectModel { 
 
 WebDriver driver = new FirefoxDriver();
 @BeforeTest
    public void setup() throws Exception { 
         driver.manage().window().maximize();
         driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
         driver.get("http://only-testing-blog.blogspot.in/2013/09/test.html"); 
    } 
 
  @AfterTest
 public void tearDown() throws Exception { 
   driver.quit();
     } 
  
 @Test
 public void print_data(){
	 
	 
	 
	 WebElement table_element = driver.findElement(By.id("post-body-6522850981930750493"));
     List<WebElement> tbl_rows=table_element.findElements(By.xpath("//*[@id='post-body-6522850981930750493']/div[1]/table/tbody/tr"));

     System.out.println("NUMBER OF ROWS IN THIS TABLE = "+tbl_rows.size());
     int row_num,col_num;

    row_num=1;
     col_num=1;
      

         for(WebElement trElement : tbl_rows)
         {
             List<WebElement> tbl_col=trElement.findElements(By.xpath("td"));


                for(WebElement tdElement : tbl_col)
                 {
                    
                	WebElement aname = tdElement;
                	String anametext=aname.getText();
                    System.out.println("Text is " +aname);
                	
                	if(anametext.equals("12"))

                              aname.click();
                                  
                    System.out.println(aname);
                    col_num++;
                    break; 
                }

                row_num++;
	 
	 
	 

   
 } 
 }
}
