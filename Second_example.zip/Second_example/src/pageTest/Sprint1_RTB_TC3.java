package pageTest;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.HomePage; 
import pageObjects.LoginPage;

     public class Sprint1_RTB_TC3{
    	 
         private static WebDriver driver = null;        
         
         @AfterTest
    	 public void tearDown() throws Exception { 
    		 driver.close();
    		 driver.quit();
    	     }  
    	     
    @Test(enabled=true)
       public void ART_514() throws Exception {
    	
//AG-30	Create Lead: Aggreko User Create New Lead//
//AG-33	Create Lead: Define lead type//
    	//1.Test Case for Lead creation with mandatory fields//
    	//2.Test Case for Lead creation with mandatory and non mandatory fields//
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_1.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(2).getCell(1,0).getContents();
   	 String username=wb.getSheet(2).getCell(1,1).getContents();
   	 String password=wb.getSheet(2).getCell(1,2).getContents();
   	 String ldtitle=wb.getSheet(2).getCell(1,3).getContents();
     String ldfname=wb.getSheet(2).getCell(1,4).getContents();     	 
   	 String ldlname=wb.getSheet(2).getCell(1,5).getContents();
   	 String ldstatus=wb.getSheet(2).getCell(1,6).getContents();
   	 String ldsrc=wb.getSheet(2).getCell(1,7).getContents();
   	 String ldcmpny=wb.getSheet(2).getCell(1,8).getContents();
   	 String ldloc=wb.getSheet(2).getCell(1,9).getContents();
   	 String ldmob=wb.getSheet(2).getCell(1,10).getContents();
   	 String ldmail=wb.getSheet(2).getCell(1,11).getContents();
   	 String ldphno=wb.getSheet(2).getCell(1,12).getContents();
   	 String ldweb=wb.getSheet(2).getCell(1,13).getContents();
   	 String ldst=wb.getSheet(2).getCell(1,14).getContents();
   	 String ldcity=wb.getSheet(2).getCell(1,15).getContents();
   	 String ldstate=wb.getSheet(2).getCell(1,16).getContents();
   	 String ldzip=wb.getSheet(2).getCell(1,17).getContents();
   	 String ldctry=wb.getSheet(2).getCell(1,18).getContents();
 
 //-------------------------------------------------------------------------------------------------------------------------//    	

    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
          LoginPage.txtbx_UserName(driver).sendKeys(username); 	//LOGIN USERNAME
        LoginPage.txtbx_Password(driver).sendKeys(password);        					//LOGIN PASSWORD
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint1_RTB_TC3.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { } 
        HomePage.clk_Leads(driver).click();  
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint1_RTB_TC3.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement leadelement=AccountsPage.fnd_recentleads(driver);
            System.out.println("The text "+ leadelement.getAttribute("innerHTML"));             
             String leadelementtext=leadelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(leadelementtext.contains("Recent Leads"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
       
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC3.captureScreenShot(driver);
             
             Leads_NewCreate.sel_fnameddwn(driver).sendKeys(ldtitle);
             Leads_NewCreate.typ_leadfname(driver).sendKeys(ldfname);          //Lead First name  
             Leads_NewCreate.typ_leadlname(driver).sendKeys(ldlname);			//Lead Last name
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Select m=new Select(Leads_NewCreate.sel_leadstatus(driver));				
             m.selectByVisibleText(ldstatus);             								//Lead Status
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Select n=new Select( Leads_NewCreate.sel_leadsource(driver));				//Lead Source
             n.selectByVisibleText(ldsrc); 
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.typ_leadncmpny(driver).sendKeys(ldcmpny);					//Lead Company//
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Select p1=new Select(Leads_NewCreate.sel_ldaggloc(driver));
             p1.selectByVisibleText(ldloc);										//Lead Location//
             
             //Select p=new Select(Leads_NewCreate.typ_leadtype(driver));
             //p.selectByVisibleText("Tender");
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC3.captureScreenShot(driver);
             
             //Non Mandatory fields//
             Leads_NewCreate.typ_leadmobno(driver).sendKeys(ldmob);								//Lead Mobile Number//
             Leads_NewCreate.typ_leademail(driver).sendKeys(ldmail);		//Lead Mail//
             Leads_NewCreate.typ_leadphone(driver).sendKeys(ldphno);						//Lead Phone No//
             Leads_NewCreate.typ_leadwebsite(driver).sendKeys(ldweb);				//Lead Website//             
             Leads_NewCreate.typ_leadstreet(driver).sendKeys(ldst);					//Lead Street//
             Leads_NewCreate.typ_leadcty(driver).sendKeys(ldcity);							//Lead City//
             Leads_NewCreate.typ_leadstate(driver).sendKeys(ldstate);							//Lead State//
             Leads_NewCreate. typ_leadpcode(driver).sendKeys(ldzip);							//Lead Zipcode//
             Leads_NewCreate. typ_leadctry(driver).sendKeys(ldctry);					//Lead Country//
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
             Sprint1_RTB_TC3.captureScreenShot(driver); 
                        
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 
             WebElement x=Account_NewCreate.fnd_savebtn(driver);
             x.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 
             Sprint1_RTB_TC3.captureScreenShot(driver); 
                         
             System.out.println("S1_Testcase3_pass..Please verify SS..");
             
    } 
    
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_1/Sprint1_TC3/screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }    
    }
     }
            