package pageTest;
 
     import java.io.File;
     import java.io.IOException;
     import java.util.concurrent.TimeUnit; 
     import org.openqa.selenium.WebDriver;
     import org.openqa.selenium.WebElement;
     import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     

import pageObjects.HomePage;
import pageObjects.LoginPage;


 
     public class Sprint1_RTB_TC5{
    	 
     @AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     } 
    
         private static WebDriver driver = null;        
         
         
    @Test(enabled=true)
       public void ART_516() throws Exception {
    	
//AG-38	2.x.x Create Leads-Search leads//
//Search for any terms with keywords in Search field//
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_1.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(4).getCell(1,0).getContents();
   	 String username=wb.getSheet(4).getCell(1,1).getContents();
   	 String password=wb.getSheet(4).getCell(1,2).getContents();
   	 String leadname=wb.getSheet(4).getCell(1,3).getContents();
     String actname=wb.getSheet(4).getCell(1,4).getContents();  
     String oppname=wb.getSheet(4).getCell(1,5).getContents();
     
//-------------------------------------------------------------------------------------------------------------------------//     

    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click(); 
        LoginPage.txtbx_UserName(driver).sendKeys(username); 									//login username
        LoginPage.txtbx_Password(driver).sendKeys(password);        							//login password
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint1_RTB_TC5.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { } 
        HomePage.clk_Leads(driver).click();   
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { } 
        HomePage.clk_sfsearch(driver).click();
        HomePage.clk_sfsearch(driver).sendKeys(leadname);							//Enter the search term here//
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint1_RTB_TC5.captureScreenShot(driver);
        
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { } 
        WebElement k=HomePage.clk_sfsearchbtn(driver);
        k.click();
 
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { } 
        Sprint1_RTB_TC5.captureScreenShot(driver);
        
       
//-----------------------------------------------------------------------------------------------------------------------//
 //To search and click-Leads-Use Display name//       
              										  
        int Row_count = driver.findElements(By.xpath("//*[@id='Lead_body']/table/tbody/tr")).size();
        System.out.println("Number Of Rows = "+Row_count);
        
        		String  xpath_first="//*[@id='Lead_body']/table/tbody/tr[";        
        		String xpath_last="]/th/a";

        		for (int i=2; i<=Row_count; i++)
        		{

        		String SNAME=driver.findElement(By.xpath(xpath_first+i+xpath_last)).getText();
        				if(SNAME.equalsIgnoreCase(leadname)){
        					System.out.println("Lead Seacrh term found");
        					WebElement m=driver.findElement(By.xpath(xpath_first+i+xpath_last));
        					m.click();        					
        				}else{
        					System.out.println("Search term not found..");
        				}
        		}
        		
        		 try {
        	            //System.out.println("Thread Sleep: " + getName());
        	            Thread.sleep(7000);
        	        } catch (InterruptedException ex) { } 
        	        Sprint1_RTB_TC5.captureScreenShot(driver);
        	        
 //-----------------------------------------------------------------------------------------------------------------------//
 //To search and click-Accounts-Use Display name// 
        		
        		HomePage.clk_sfsearch(driver).click();
                HomePage.clk_sfsearch(driver).sendKeys(actname);			//Enter Search term here--If Accounts to be validated//
                
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                Sprint1_RTB_TC5.captureScreenShot(driver);
                
                try {
    	            //System.out.println("Thread Sleep: " + getName());
    	            Thread.sleep(5000);
    	        } catch (InterruptedException ex) { }                 
                WebElement k2=HomePage.clk_sfsearchbtn(driver);
                k2.click();
        		
        		      					//Account Name to be clicked// 
                int Row_count1 = driver.findElements(By.xpath(".//*[@id='Account_body']/table/tbody/tr")).size();
                System.out.println("Number Of Rows = "+Row_count1);
                
                		String  xpath_first1=".//*[@id='Account_body']/table/tbody/tr[";        
                		String xpath_last1="]/th/a";
                		
                		for (int j=2; j<=Row_count1; j++)
                		{

                		String ACTNAME=driver.findElement(By.xpath(xpath_first1+j+xpath_last1)).getText();
                				if(ACTNAME.equalsIgnoreCase(actname)){
                					System.out.println("Acocunt Search term found");
                					WebElement m1=driver.findElement(By.xpath(xpath_first1+j+xpath_last1));
                					m1.click();        					
                				}else{
                					System.out.println("Search term not found..");
                				}
                		
                		}
                		
                		 try {
                	            //System.out.println("Thread Sleep: " + getName());
                	            Thread.sleep(5000);
                	        } catch (InterruptedException ex) { } 
                	        Sprint1_RTB_TC5.captureScreenShot(driver);
                	        
  
//-----------------------------------------------------------------------------------------------------------------------//
//To search and click-Opportunities-Use Display name//
                		
                		HomePage.clk_sfsearch(driver).click();
                        HomePage.clk_sfsearch(driver).sendKeys(oppname);			//Enter Opportunity name to be searched and clicked//
                        
                        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                        Sprint1_RTB_TC5.captureScreenShot(driver);
                        
                        
                        try {
            	            //System.out.println("Thread Sleep: " + getName());
            	            Thread.sleep(5000);
            	        } catch (InterruptedException ex) { } 
                        WebElement k1=HomePage.clk_sfsearchbtn(driver);
                        k1.click();
                		
                		       						//Enter Opportunity name to be clicked
                        int Row_count2 = driver.findElements(By.xpath(".//*[@id='Opportunity_body']/table/tbody/tr")).size();
                        System.out.println("Number Of Rows = "+Row_count2);
                        
                        		String  xpath_first2=".//*[@id='Opportunity_body']/table/tbody/tr[";        
                        		String xpath_last2="]/th/a";

                        		for (int p=2; p<=Row_count2; p++)
                        		{

                        		String OPPNAME=driver.findElement(By.xpath(xpath_first2+p+xpath_last2)).getText();
                        				if(OPPNAME.equalsIgnoreCase(oppname)){
                        					System.out.println("Opportunity Search term found");
                        					WebElement m2=driver.findElement(By.xpath(xpath_first1+p+xpath_last1));
                        					m2.click(); 
                        					break;
                        				}else{
                        					System.out.println("Search term not found..");
                        				}
                        		}  
                        		
                        		 try {
                        	            //System.out.println("Thread Sleep: " + getName());
                        	            Thread.sleep(5000);
                        	        } catch (InterruptedException ex) { } 
                        	        Sprint1_RTB_TC5.captureScreenShot(driver);
                        	        
 
                        	        //System.out.println("S1_Testcase5_pass..Please validate SS..");
                        	        
        
    }
    
      
    
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_1/Sprint1_TC5/TC5screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }  
     }
     }
     