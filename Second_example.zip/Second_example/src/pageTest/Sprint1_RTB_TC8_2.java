package pageTest;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.HomePage;
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;


//AG-74	Qualify Lead to Opportunity: Assign Lead Status
//Sprint1_RTB_TC8_2-Verify mandatory parameters when changing Open to On Hold//

 
     public class Sprint1_RTB_TC8_2{
    	 
    	 @AfterTest
    	 public void tearDown() throws Exception { 
    		 driver.close();
    	     driver.quit();
    	     } 
    	
         private static WebDriver driver = null;        
         
         
    @Test(enabled=true)
       public void ART_520() throws Exception{ 
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_1.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(8).getCell(1,0).getContents();
   	 String username=wb.getSheet(8).getCell(1,1).getContents();
   	 String password=wb.getSheet(8).getCell(1,2).getContents();
   	 String ldtitle=wb.getSheet(8).getCell(1,3).getContents();
     String ldfname=wb.getSheet(8).getCell(1,4).getContents();  
     String ldlname=wb.getSheet(8).getCell(1,5).getContents();     
     String ldsource=wb.getSheet(8).getCell(1,6).getContents();     
     String ldcomp=wb.getSheet(8).getCell(1,7).getContents();
     String ldonhlrsn=wb.getSheet(8).getCell(1,8).getContents();     
     String ldonhldt=wb.getSheet(8).getCell(1,9).getContents();
     
 
//-------------------------------------------------------------------------------------------------------------------------//         	

    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 							//Login Username
        LoginPage.txtbx_Password(driver).sendKeys(password);  							//Login Password      
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint1_RTB_TC8_2.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(7000);
        } catch (InterruptedException ex) { }  
        HomePage.clk_Leads(driver).click();       
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement leadelement=AccountsPage.fnd_recentleads(driver);
            System.out.println("The text "+ leadelement.getAttribute("innerHTML"));             
             String leadelementtext=leadelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(leadelementtext.contains("Recent Leads"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC8_2.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.sel_fnameddwn(driver).sendKeys(ldtitle);						//Title
             Leads_NewCreate.typ_leadfname(driver).sendKeys(ldfname);						//lead first name				       	    
             Leads_NewCreate.typ_leadlname(driver).sendKeys(ldlname);   					//lead last name
             //driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select m=new Select(Leads_NewCreate.sel_leadstatus(driver));
             m.selectByVisibleText("Open");													//lead status
           
            
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select n=new Select(Leads_NewCreate.sel_leadsource(driver));
             n.selectByVisibleText(ldsource);												//lead source
           
          
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.typ_leadncmpny(driver).sendKeys(ldcomp); 						//Lead Company
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC8_2.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  
             WebElement x=Account_NewCreate.fnd_savebtn(driver);
             x.click();
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);   
             Sprint1_RTB_TC8_2.captureScreenShot(driver);
             
//-------------------------------------------------------------------------------------------------------------------------//             
 //Edit and Change Lead to On Hold//
             
             System.out.println("Trying to change Lead status to On-Hold..");
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }    
             All_Edit_Clone.fnd_editbtn(driver).click();
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC8_2.captureScreenShot(driver);

             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  
             Select p=new Select(Leads_NewCreate.sel_leadstatus(driver));
             p.selectByVisibleText("On Hold");
           
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }   
             WebElement y=Account_NewCreate.fnd_savebtn(driver);
             y.click();    
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);   
             Sprint1_RTB_TC8_2.captureScreenShot(driver);
             
//Verify error-Error: You need to add an on hold end date to put the lead on hold
//Verify error: Please enter an On Hold reason to save the record.
             
             System.out.println("Entering On Hold reason..");
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
             Leads_NewCreate.typ_leadonhldrsn(driver).sendKeys(ldonhlrsn);
               
             Sprint1_RTB_TC8_2.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  
             WebElement a=Account_NewCreate.fnd_savebtn(driver);
             a.click();   
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);   
             Sprint1_RTB_TC8_2.captureScreenShot(driver);
             
 //Verify error-Error: You need to add an on hold end date to put the lead on hold
             System.out.println("Entering On Hold Date..");
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.sel_leadonhlddat(driver).sendKeys(ldonhldt);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC8_2.captureScreenShot(driver);

             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }    
             WebElement c=Account_NewCreate.fnd_savebtn(driver);
             c.click();   
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);   
             Sprint1_RTB_TC8_2.captureScreenShot(driver);
             
            // System.out.println("S1_Testcase8_2_pass..Please validate screenshots..");
 
    }
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_1/Sprint1_TC8_2/screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }   
    }
     }
     