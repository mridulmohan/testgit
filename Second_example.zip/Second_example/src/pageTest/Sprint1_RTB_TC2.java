package pageTest;
 
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Contacts_NewCreate;
import pageObjects.HomePage; 
import pageObjects.LoginPage;

     public class Sprint1_RTB_TC2 {
    	 
    	 
    	 @AfterTest
    	 public void tearDown() throws Exception { 
    		 driver.close();
    	   driver.quit();
    	     }   	 
    	
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void ART_513() throws Exception {
    	
//AG-129	Creating Customer Contact//
//Create a contact with mandatory fields only + optional fields//
//Edit the Same contact created// 
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_1.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(1).getCell(1,0).getContents();
   	 String username=wb.getSheet(1).getCell(1,1).getContents();
   	 String password=wb.getSheet(1).getCell(1,2).getContents();
   	 String conttitle=wb.getSheet(1).getCell(1,3).getContents();
     String contfname=wb.getSheet(1).getCell(1,4).getContents();     	 
   	 String contlname=wb.getSheet(1).getCell(1,5).getContents();
   	 String actname=wb.getSheet(1).getCell(1,6).getContents();
   	 String contphno=wb.getSheet(1).getCell(1,7).getContents();
   	 String contmail=wb.getSheet(1).getCell(1,8).getContents();
   	 String contseg=wb.getSheet(1).getCell(1,9).getContents();
   	 String contst=wb.getSheet(1).getCell(1,10).getContents();
   	 String contcity=wb.getSheet(1).getCell(1,11).getContents();
   	 String contstate=wb.getSheet(1).getCell(1,12).getContents();
   	 String contzip=wb.getSheet(1).getCell(1,13).getContents();
   	 String contctry=wb.getSheet(1).getCell(1,14).getContents();
 
 //-------------------------------------------------------------------------------------------------------------------------//  
    	
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click();
        LoginPage.txtbx_UserName(driver).sendKeys(username); 							//LOGIN USERNAME
        LoginPage.txtbx_Password(driver).sendKeys(password);        					//LOGIN PASSWORD
        LoginPage.btn_LogIn(driver).click();
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
        Sprint1_RTB_TC2.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
            HomePage.clk_Contacts(driver).click();
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint1_RTB_TC2.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement conelement=AccountsPage.fnd_recentcontact(driver);
            System.out.println("The text "+ conelement.getAttribute("innerHTML"));             
             String conelementtext=conelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(conelementtext.contains("Recent Contacts"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC2.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
            Contacts_NewCreate.clk_cntfnamedrpdwn(driver).sendKeys(conttitle);
            Contacts_NewCreate.typ_cntfname(driver).sendKeys(contfname);			//CONTACT FIRST NAME
            Contacts_NewCreate.typ_cntlname(driver).sendKeys(contlname);			//CONATCT LAST NAME
            Contacts_NewCreate.typ_cntaccno(driver).sendKeys(actname); 			//ACCOUNT NAME
            Contacts_NewCreate.typ_cntphno(driver).sendKeys(contphno);			//CONTACT PHONE NO
            Contacts_NewCreate.typ_cntemail(driver).sendKeys(contmail);	//CONTACT EMAIL//
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint1_RTB_TC2.captureScreenShot(driver);
            
            Select q=new Select(Contacts_NewCreate.sel_cntseg(driver));					//CONTACT SEGMENT//
            q.selectByVisibleText(contseg);
            
            //Contacts_NewCreate.typ_cntphno(driver).sendKeys("7282820646");
            //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
            //Select m=new Select(Contacts_NewCreate.sel_cntlang(driver));
            //m.selectByVisibleText("GB");
          
            //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
            //Contacts_NewCreate.sel_cntseg(driver).sendKeys("Business Partner");
            
            Contacts_NewCreate.typ_cntmailstreet(driver).sendKeys(contst);		//CONTACT STREET		
            Contacts_NewCreate.typ_cntmailcty(driver).sendKeys(contcity);					//CONTACT CITY
            Contacts_NewCreate.typ_cntmailstate(driver).sendKeys(contstate);				//CONTACT STATE
            Contacts_NewCreate.typ_cntmailpcode(driver).sendKeys(contzip);					//CONTACT ZIPCODE
            Contacts_NewCreate.typ_cntmailctry(driver).sendKeys(contctry);			//CONATCT COUNTRY
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            Sprint1_RTB_TC2.captureScreenShot(driver);     
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }    
            WebElement x=Account_NewCreate.fnd_savebtn(driver);
            x.click(); 
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }   
            Sprint1_RTB_TC2.captureScreenShot(driver); 
           
            //System.out.println("S1_Testcase2_pass");
    	      
            
    }
    
    public static void captureScreenShot(WebDriver ldriver){        	 
   	  // Take screenshot and store as a file format//
   	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
   	try {
   	  // To copy the  screenshot to desired location using copyFile method	 
   	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_1/Sprint1_TC2/screenshot_"+System.currentTimeMillis()+".png"));
   	       }	 
   	catch (IOException e)	 
   	{	 
   	System.out.println(e.getMessage());	 
   	    }    
    
    }
     }