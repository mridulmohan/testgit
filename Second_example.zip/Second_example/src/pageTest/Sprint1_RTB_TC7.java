package pageTest;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;


 
     public class Sprint1_RTB_TC7{
    	 
    	/* @AfterTest
    	 public void tearDown() throws Exception { 
    		 driver.close();
    		 driver.quit();
    	     } */
    	     
         private static WebDriver driver = null;        
        
         
    @Test(enabled=true)
       public void ART_518() throws Exception {
    	
// AG-63	Manage Customer Account: Update customer
//	1.Test Case to create Account//
//	2.Edit the created Account with non-mandatory fields-Mail to be triggered to primary contact//
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_1.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(6).getCell(1,0).getContents();
   	 String username=wb.getSheet(6).getCell(1,1).getContents();
   	 String password=wb.getSheet(6).getCell(1,2).getContents();
   	 String actname=wb.getSheet(6).getCell(1,3).getContents();
     String actpcnt=wb.getSheet(6).getCell(1,4).getContents();  
     String actloc=wb.getSheet(6).getCell(1,5).getContents();     
     String actaic=wb.getSheet(6).getCell(1,6).getContents();     
     String actseg=wb.getSheet(6).getCell(1,7).getContents();
     String actst=wb.getSheet(6).getCell(1,8).getContents();
     String actcity=wb.getSheet(6).getCell(1,9).getContents();
     String actstate=wb.getSheet(6).getCell(1,10).getContents();
     String actzip=wb.getSheet(6).getCell(1,11).getContents();     
     String actctry=wb.getSheet(6).getCell(1,12).getContents();
     String editst=wb.getSheet(6).getCell(1,13).getContents();     
     String editweb=wb.getSheet(6).getCell(1,14).getContents();
     String editloc=wb.getSheet(6).getCell(1,15).getContents();
     String editzip=wb.getSheet(6).getCell(1,16).getContents();
 
//-------------------------------------------------------------------------------------------------------------------------// 
    	
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click(); 
        LoginPage.txtbx_UserName(driver).sendKeys(username); 								//Login User name
        LoginPage.txtbx_Password(driver).sendKeys(password);        						//Login Password
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint1_RTB_TC7.captureScreenShot(driver);
        
        try {
           
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }   
        HomePage.clk_Account(driver).click();       
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement accelement=AccountsPage.fnd_recentaccount(driver);
            System.out.println("The text "+ accelement.getAttribute("innerHTML"));             
             String accelementtext=accelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(accelementtext.contains("Recent Accounts"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint1_RTB_TC7.captureScreenShot(driver);
              
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            Account_NewCreate.typ_actname(driver).sendKeys(actname);						//Account name
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
            Account_NewCreate.typ_acpricon(driver).sendKeys(actpcnt);						//Primary Contact//
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Select a=new Select(Account_NewCreate.sel_aggloc(driver));
            a.selectByVisibleText(actloc);													//Aggrekko Location//
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Select b=new Select(Account_NewCreate.sel_actaic(driver));
            b.selectByVisibleText(actaic);													//AIC//
         
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Select c=new Select(Account_NewCreate.sel_acttyp(driver));
            c.selectByVisibleText(actseg);													//Segment//
            
            Account_NewCreate.typ_acPhyst(driver).click();
            Account_NewCreate.typ_acPhyst(driver).sendKeys(actst);							//Street
            Account_NewCreate.typ_acPhycty(driver).sendKeys(actcity);						//City							
            Account_NewCreate.typ_acPhystate(driver).sendKeys(actstate);					//State
            Account_NewCreate.typ_acPhyzipcode(driver).sendKeys(actzip);					//ZipCode
            Account_NewCreate.typ_acPhyctry(driver).sendKeys(actctry);						//Country		
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint1_RTB_TC7.captureScreenShot(driver);
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }    
            WebElement x=Account_NewCreate.fnd_savebtn(driver);
            x.click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }  
            Sprint1_RTB_TC7.captureScreenShot(driver);
 
//--------------------------------------------------------------------------------------------------------------------------------//
//Edit Account created above//
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }    
            All_Edit_Clone.fnd_editbtn(driver).click();
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
            
            Account_NewCreate.typ_acPhyst(driver).sendKeys(editst);								//Street
            Account_NewCreate.typ_actwsite(driver).sendKeys(editweb);							//Website//
            
            Select v=new Select(Account_NewCreate.sel_aggloc(driver));
            v.selectByVisibleText(editloc);														//Location
            Account_NewCreate.typ_acPhyzipcode(driver).click();									
            Account_NewCreate.typ_acPhyzipcode(driver).sendKeys(editzip);						//Zipcode
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint1_RTB_TC7.captureScreenShot(driver);
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }    
            WebElement y=Account_NewCreate.clk_snudcb(driver);
            y.click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }    
            WebElement z=Account_NewCreate.fnd_savebtn(driver);
            z.click();               
          
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }  
            Sprint1_RTB_TC7.captureScreenShot(driver);
            
           // System.out.println("S1_Testcase7_pass...Validate Mail sent to User Mail for Account Updates...Check mailowner in the user details..");
          
            
    }
    
    public static void captureScreenShot(WebDriver ldriver){        	 
   	  // Take screenshot and store as a file format//
   	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
   	try {
   	  // To copy the  screenshot to desired location using copyFile method	 
   	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_1/Sprint1_TC7/screenshot_"+System.currentTimeMillis()+".png"));
   	       }	 
   	catch (IOException e)	 
   	{	 
   	System.out.println(e.getMessage());	 
   	    }   
    }
     }
     