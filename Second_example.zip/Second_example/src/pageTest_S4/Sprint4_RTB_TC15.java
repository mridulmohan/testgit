package pageTest_S4;
 
     import java.io.File;
     import java.io.IOException;
     import java.util.concurrent.TimeUnit; 
     import org.openqa.selenium.WebDriver;
     import org.openqa.selenium.WebElement;
     import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.Sales_Target_New;
import pageObjects.All_Edit_Clone;

 
     public class Sprint4_RTB_TC15{
    	 
    	 /*@AfterTest
    	 public void tearDown() throws Exception { 
    		 driver.close();
    	     driver.quit();
    	     }  */
    	 
         private static WebDriver driver = null;        
         
                  
    @Test(enabled=true)
       public void testcase15() throws Exception {   	
   	
//Sprint 4 Generic System Featur	AG-105	Generic System Features: Warn user of (potential) existing duplicate record
//Sprint4_RTB_TC15-Account duplicate-Fuzzy logic
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_4.xls");
      	 System.out.println("Excel located..");        	 
      	 Workbook wb=Workbook.getWorkbook(src);        	 
      	 System.out.println("Excel loaded..");
      	 String url=wb.getSheet(13).getCell(1,0).getContents();
      	 String username=wb.getSheet(13).getCell(1,1).getContents();
      	 String password=wb.getSheet(13).getCell(1,2).getContents();    	 
        String actname=wb.getSheet(13).getCell(1,3).getContents();     	 
      	 String actloc=wb.getSheet(13).getCell(1,4).getContents();
      	 String actaic=wb.getSheet(13).getCell(1,5).getContents();
      	 String actstat=wb.getSheet(13).getCell(1,6).getContents();
      	 String actseg=wb.getSheet(13).getCell(1,7).getContents();
      	String actst=wb.getSheet(13).getCell(1,8).getContents();
      	String actcity=wb.getSheet(13).getCell(1,9).getContents();
      	String actstate=wb.getSheet(13).getCell(1,10).getContents();
      	String actzip=wb.getSheet(13).getCell(1,11).getContents();
      	String actctry=wb.getSheet(13).getCell(1,12).getContents();
    
 //-------------------------------------------------------------------------------------------------------------------------//     	

    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                 LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint4_RTB_TC15.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
        HomePage.clk_Account(driver).click();    
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint4_RTB_TC15.captureScreenShot(driver);
            
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { } 
        
            WebElement accelement=AccountsPage.fnd_recentaccount(driver);
            System.out.println("The text "+ accelement.getAttribute("innerHTML"));             
             String accelementtext=accelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(accelementtext.contains("Recent Accounts"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint4_RTB_TC15.captureScreenShot(driver);
              
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            Account_NewCreate.typ_actname(driver).sendKeys(actname);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Select a=new Select(Account_NewCreate.sel_aggloc(driver));
            a.selectByVisibleText(actloc);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Select b=new Select(Account_NewCreate.sel_actaic(driver));
            b.selectByVisibleText(actaic);
         
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Select c=new Select(Account_NewCreate.typ_acsegmnt(driver));
            c.selectByVisibleText(actseg);
            
            driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS); 
            Account_NewCreate.typ_acPhyst(driver).sendKeys(actst);
            Account_NewCreate.typ_acPhycty(driver).sendKeys(actcity);	
            Account_NewCreate.typ_acPhystate(driver).sendKeys(actstate);			
            Account_NewCreate.typ_acPhyzipcode(driver).sendKeys(actzip);			
            Account_NewCreate.typ_acPhyctry(driver).sendKeys(actctry);				
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint4_RTB_TC15.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            WebElement x=Account_NewCreate.fnd_savebtn(driver);
            x.click(); 
            
              
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }  
            HomePage.clk_Account(driver).click();
            System.out.println("Account 1 created..");
            System.out.println("Startting to create duplicate account..");
            
            //*********Create Second Account*****using same values of Act 1//              
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }             
                WebElement acc1element=AccountsPage.fnd_recentaccount(driver);
                System.out.println("The text "+ acc1element.getAttribute("innerHTML"));             
                 String acc1elementtext=acc1element.getAttribute("innerHTML");         
                 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
                 if(acc1elementtext.contains("Recent Accounts"))
                 {
                	AccountsPage.clk_nwbtn(driver).click();
                 }
                
                 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                 Sprint4_RTB_TC15.captureScreenShot(driver);
                  
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                Account_NewCreate.typ_actname(driver).sendKeys(actname);
                
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                Select a1=new Select(Account_NewCreate.sel_aggloc(driver));
                a1.selectByVisibleText(actloc);
                
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                Select b1=new Select(Account_NewCreate.sel_actaic(driver));
                b1.selectByVisibleText(actaic);
             
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                Select c1=new Select(Account_NewCreate.typ_acsegmnt(driver));
                c1.selectByVisibleText(actseg);
                
                driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS); 
                Account_NewCreate.typ_acPhyst(driver).sendKeys(actst);
                Account_NewCreate.typ_acPhycty(driver).sendKeys(actcity);	
                Account_NewCreate.typ_acPhystate(driver).sendKeys(actstate);			
                Account_NewCreate.typ_acPhyzipcode(driver).sendKeys(actzip);			
                Account_NewCreate.typ_acPhyctry(driver).sendKeys(actctry);				
                
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                Sprint4_RTB_TC15.captureScreenShot(driver);
                
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                WebElement x1=Account_NewCreate.fnd_savebtn(driver);
                x1.click(); 
                
                try {
                    //System.out.println("Thread Sleep: " + getName());
                    Thread.sleep(5000);
                } catch (InterruptedException ex) { }
                Sprint4_RTB_TC15.captureScreenShot(driver); 
                
                ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
                
                try {
                    //System.out.println("Thread Sleep: " + getName());
                    Thread.sleep(5000);
                } catch (InterruptedException ex) { }
                Sprint4_RTB_TC15.captureScreenShot(driver); 
                
                System.out.println("Duplicate Account of .."+actname);
                System.out.println("Sprint4_RTB_TC15 pass..verify SS...");
   
    	      
    }
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_4/Sprint4_TC15/screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }         
       }
   	
    }
    	
    