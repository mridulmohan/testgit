package pageTest_S4;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.HomePage;
import pageObjects.Lead_Convert;
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;
import pageObjects.Reports_New;

 
     public class Sprint4_RTB_TC8{
    	
    	 @AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     } 
    	 
         private static WebDriver driver = null;        
         
         
    @Test(enabled=true)
       public void testcase8() throws Exception{

//Sprint 4 Generic System Feature	AG-130	Generic System Features: Contacts 'Marked for Delete' Report
//Sprint4_RTB_TC8-Mark for delete Opportunities
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_4.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(6).getCell(1,0).getContents();
   	 String username=wb.getSheet(6).getCell(1,1).getContents();
   	 String password=wb.getSheet(6).getCell(1,2).getContents();
   	 String oppname=wb.getSheet(6).getCell(1,3).getContents();
   	 
   //-------------------------------------------------------------------------------------------------------------------------//     	


   	 	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 							//User Name
        LoginPage.txtbx_Password(driver).sendKeys(password);        					//Password
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint4_RTB_TC8.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }    
        HomePage.clk_reports(driver).click(); 
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint4_RTB_TC8.captureScreenShot(driver);
            

        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }           
        Reports_New.typ_repsrch(driver).sendKeys("Marked for Delete - Oppor");

        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }
        
        Reports_New.clk_opprept(driver).click();
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }
        Sprint4_RTB_TC8.captureScreenShot(driver);
        
        ((JavascriptExecutor)driver).executeScript("scroll(0,400)");        
        Sprint4_RTB_TC8.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { }
        ((JavascriptExecutor)driver).executeScript("scroll(0,400)");        
        Sprint4_RTB_TC8.captureScreenShot(driver);
        
        
//Search for mark for delete Opportunities//
        
        int Row_count = driver.findElements(By.xpath("//*[@id='fchArea']/table/tbody/tr")).size();
        System.out.println("Number Of Rows = "+Row_count);
        
        		String  xpath_first="//*[@id='fchArea']/table/tbody/tr[";        
        		String xpath_last="]/td[1]/a";

        		for (int i=2; i<=Row_count; i++)
        		{

        		String OPPNAME=driver.findElement(By.xpath(xpath_first+i+xpath_last)).getText();
        				if(OPPNAME.equalsIgnoreCase(oppname)){
        					System.out.println("Opportunity marked for delete found in Reports");
        					WebElement m=driver.findElement(By.xpath(xpath_first+i+xpath_last));
        					m.click(); 
        					break;
        				}else{
        					System.out.println("Opportunity marked for delete not found in Reports");        					
        				}
        		}
        
        System.out.println("Sprint_4 test case 8 successful..");
    }
    
    
    public static void captureScreenShot(WebDriver ldriver){        	 
   	  // Take screenshot and store as a file format//
   	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
   	try {
   	  // To copy the  screenshot to desired location using copyFile method	 
   	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_4/Sprint4_TC8/screenshot_"+System.currentTimeMillis()+".png"));
   	       }	 
   	catch (IOException e)	 
   	{	 
   	System.out.println(e.getMessage());	 
   	    }         
     }
    
     }