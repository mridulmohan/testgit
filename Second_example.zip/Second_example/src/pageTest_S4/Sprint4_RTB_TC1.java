package pageTest_S4;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import java.util.ArrayList;

// Import package pageObject//     

import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Calendar_event;
import pageObjects.HomePage;
import pageObjects.Leads_NewCreate;
import pageObjects.LoginPage;
import pageObjects.Opportunity_NewCreate;
import pageObjects.SalesPlan_Account;
import pageObjects.Sales_Plan_New;
import pageObjects.Sales_Target_New;
import pageObjects.All_Edit_Clone;
import pageTest_S2.Sprint2_RTB_TC1;
import pageObjects.Sales_Plan_Postcreation;
import pageObjects.Sales_Territory_New;

 
     public class Sprint4_RTB_TC1 {
    	 
    	 @AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     }     	 
    	
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void testcase1() {
    	
//Sprint 4 Generic System Featur	AG-388	Add Aggreko Logo
 	
 //Login As Admin//
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get("https://aggreko--CI2.cs82.my.salesforce.com");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        //Profile 2 � Test Manager 
        //Username - sf.systestmanager@aggreko.trial.ci2
        //Password � Mercury@123

        //Profile 3 � Sales Rep
        //Username - sf.systestrep@aggreko.trial.ci2
        //Password � Welcome1
        
        
        LoginPage.txtbx_UserName(driver).sendKeys("salesforce.systester@aggreko.trial.ci2"); 
        LoginPage.txtbx_Password(driver).sendKeys("Sftestadm1n@123");        
        LoginPage.btn_LogIn(driver).click();
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(7000);
        } catch (InterruptedException ex) { }  
        //ArrayList<String> s = new ArrayList<String>(driver.getWindowHandles());
        
        String a=driver.findElement(By.xpath(".//*[@id='phHeaderLogoImage']")).getText();
        System.out.println("Logo name is"+a);
        Sprint4_RTB_TC1.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
        
             		
                     
    }
  //Screenshot  
    public static void captureScreenShot(WebDriver ldriver){        	 
  	  // Take screenshot and store as a file format//
  	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
  	try {
  	  // To copy the  screenshot to desired location using copyFile method	 
  	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_4/Sprint4_TC1/screenshot_"+System.currentTimeMillis()+".png"));
  	       }	 
  	catch (IOException e)	 
  	{	 
  	System.out.println(e.getMessage());	 
  	    }         
    }
   


}

  