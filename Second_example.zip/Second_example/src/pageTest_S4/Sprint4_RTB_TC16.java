package pageTest_S4;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.JavascriptExecutor;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Contacts_NewCreate;
import pageObjects.Leads_NewCreate;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageTest.Sprint1_RTB_TC2;


     public class Sprint4_RTB_TC16{
    	 
         private static WebDriver driver = null;        
         
         /*@AfterTest
    	 public void tearDown() throws Exception { 
    		 driver.close();
    	   driver.quit();
    	     } */ 
    	    
    @Test(enabled=true)
       public void testcase16() throws Exception{
    	
//Sprint 4 Generic System Featur	AG-105	Generic System Features: Warn user of (potential) existing duplicate record
//Sprint4_RTB_TC16-Contact duplicate-Fuzzy logic
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_4.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(14).getCell(1,0).getContents();
   	 String username=wb.getSheet(14).getCell(1,1).getContents();
   	 String password=wb.getSheet(14).getCell(1,2).getContents();
   	 String conttitle=wb.getSheet(14).getCell(1,3).getContents();
     String contfname=wb.getSheet(14).getCell(1,4).getContents();     	 
   	 String contlname=wb.getSheet(14).getCell(1,5).getContents();
   	 String actname=wb.getSheet(14).getCell(1,6).getContents();
   	 String contphno=wb.getSheet(14).getCell(1,7).getContents();
   	 String contmail=wb.getSheet(14).getCell(1,8).getContents();
   	 String contseg=wb.getSheet(14).getCell(1,9).getContents();
   	 String contst=wb.getSheet(14).getCell(1,10).getContents();
   	 String contcity=wb.getSheet(14).getCell(1,11).getContents();
   	 String contstate=wb.getSheet(14).getCell(1,12).getContents();
   	 String contzip=wb.getSheet(14).getCell(1,13).getContents();
   	 String contctry=wb.getSheet(14).getCell(1,14).getContents();
 
 //-------------------------------------------------------------------------------------------------------------------------//      	
    	
    	
    	
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
        Sprint4_RTB_TC16.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
            HomePage.clk_Contacts(driver).click();
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            Sprint4_RTB_TC16.captureScreenShot(driver);
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }               
            WebElement conelement=AccountsPage.fnd_recentcontact(driver);
            System.out.println("The text "+ conelement.getAttribute("innerHTML"));             
             String conelementtext=conelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(conelementtext.contains("Recent Contacts"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint4_RTB_TC16.captureScreenShot(driver);
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);           
            
            Contacts_NewCreate.clk_cntfnamedrpdwn(driver).sendKeys(conttitle);
            Contacts_NewCreate.typ_cntfname(driver).sendKeys(contfname);
            Contacts_NewCreate.typ_cntlname(driver).sendKeys(contlname);
            Contacts_NewCreate.typ_cntaccno(driver).sendKeys(actname); 
            Contacts_NewCreate.typ_cntphno(driver).sendKeys(contphno);
            Contacts_NewCreate.typ_cntemail(driver).sendKeys(contmail);
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           
            Select m=new Select(Contacts_NewCreate.sel_cntseg(driver));
            m.selectByVisibleText(contseg);

            Sprint4_RTB_TC16.captureScreenShot(driver);
            
            Contacts_NewCreate.typ_cntmailstreet(driver).sendKeys(contst);
            Contacts_NewCreate.typ_cntmailcty(driver).sendKeys(contcity);
            Contacts_NewCreate.typ_cntmailstate(driver).sendKeys(contstate);
            Contacts_NewCreate.typ_cntmailpcode(driver).sendKeys(contzip);
            Contacts_NewCreate.typ_cntmailctry(driver).sendKeys(contctry);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
            Sprint4_RTB_TC16.captureScreenShot(driver);     
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }    
            WebElement x=Account_NewCreate.fnd_savebtn(driver);
            x.click(); 
            
            System.out.println("Contact 1 created..Duplicate Contact creation in progress..");
            
 //  Second Contact getting created//           
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }  
                HomePage.clk_Contacts(driver).click();
                
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                Sprint4_RTB_TC16.captureScreenShot(driver);
                
                try {
                    //System.out.println("Thread Sleep: " + getName());
                    Thread.sleep(5000);
                } catch (InterruptedException ex) { }               
                WebElement con1element=AccountsPage.fnd_recentcontact(driver);
                System.out.println("The text "+ con1element.getAttribute("innerHTML"));             
                 String con1elementtext=con1element.getAttribute("innerHTML");         
                 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
                 if(con1elementtext.contains("Recent Contacts"))
                 {
                	AccountsPage.clk_nwbtn(driver).click();
                 }
                
                 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                 Sprint4_RTB_TC16.captureScreenShot(driver);
                 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);           
                
                Contacts_NewCreate.clk_cntfnamedrpdwn(driver).sendKeys(conttitle);
                Contacts_NewCreate.typ_cntfname(driver).sendKeys(contfname);
                Contacts_NewCreate.typ_cntlname(driver).sendKeys(contlname);
                Contacts_NewCreate.typ_cntaccno(driver).sendKeys(actname); 
                Contacts_NewCreate.typ_cntphno(driver).sendKeys(contphno);
                Contacts_NewCreate.typ_cntemail(driver).sendKeys(contmail);
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
               
                Select n=new Select(Contacts_NewCreate.sel_cntseg(driver));
                n.selectByVisibleText(contseg);

                Sprint4_RTB_TC16.captureScreenShot(driver);
                
                       Contacts_NewCreate.typ_cntmailstreet(driver).sendKeys(contst);
                Contacts_NewCreate.typ_cntmailcty(driver).sendKeys(contcity);
                Contacts_NewCreate.typ_cntmailstate(driver).sendKeys(contstate);
                Contacts_NewCreate.typ_cntmailpcode(driver).sendKeys(contzip);
                Contacts_NewCreate.typ_cntmailctry(driver).sendKeys(contctry);
                
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);  
                Sprint4_RTB_TC16.captureScreenShot(driver);     
                
                try {
                    //System.out.println("Thread Sleep: " + getName());
                    Thread.sleep(5000);
                } catch (InterruptedException ex) { }    
                WebElement x1=Account_NewCreate.fnd_savebtn(driver);
                x1.click(); 
                
                try {
                    //System.out.println("Thread Sleep: " + getName());
                    Thread.sleep(5000);
                } catch (InterruptedException ex) { }
                Sprint4_RTB_TC16.captureScreenShot(driver); 
                
                ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
                
                try {
                    //System.out.println("Thread Sleep: " + getName());
                    Thread.sleep(5000);
                } catch (InterruptedException ex) { }
                Sprint4_RTB_TC16.captureScreenShot(driver);
                
                System.out.println("Duplicate Account found..");
                System.out.println("Sprint4-test case 16 sucessful..Please verify SS");
    	
    } 
    
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_4/Sprint4_TC16/screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }    
    }
     }
            