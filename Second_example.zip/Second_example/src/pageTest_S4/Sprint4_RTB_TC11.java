package pageTest_S4;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.By;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.Opportunity_NewCreate;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;

 
     public class Sprint4_RTB_TC11 {
    	 
    	 
    	@AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     } 
    	 
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void testcase11() throws Exception {
    	
//Sprint 4 Generic System Feature-AG-97	Generic System Features: System guided data capture
//ART-530
//Sprint4_RTB_TC11-Verify if  'Convert button is not seen-in Build 
    	
//---------------------------------------------------------------------------------------------------//
     	 
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_4.xls");
     	 System.out.println("Excel located");        	 
     	 Workbook wb=Workbook.getWorkbook(src);        	 
     	 System.out.println("Excel loaded");
     	 String url=wb.getSheet(9).getCell(1,0).getContents();
    	 String username=wb.getSheet(9).getCell(1,1).getContents();
    	 String password=wb.getSheet(9).getCell(1,2).getContents();
    	 String oppname=wb.getSheet(9).getCell(1,3).getContents();
    	 String accname=wb.getSheet(9).getCell(1,4).getContents();
    	 String ocdate=wb.getSheet(9).getCell(1,5).getContents();
    	 String Currency=wb.getSheet(9).getCell(1,6).getContents();    	 
    	 String onhdate=wb.getSheet(9).getCell(1,7).getContents();
    	 String ofhdate=wb.getSheet(9).getCell(1,8).getContents();
    	 String prodcty=wb.getSheet(9).getCell(1,9).getContents();
    	 String oppsource=wb.getSheet(9).getCell(1,10).getContents();

//--------------------------------------------------------------------------------------------------//       	
 
//validating Build Stage//  
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click();
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().setScriptTimeout(20,TimeUnit.SECONDS);
        Sprint4_RTB_TC11.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(3000);
        } catch (InterruptedException ex) { } 
            HomePage.clk_Opportunity(driver).click();
            
            try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(5000);
            } catch (InterruptedException ex) { }              
            Sprint4_RTB_TC11.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement opporelement=AccountsPage.fnd_recentoppurtunities(driver);
            System.out.println("The text "+ opporelement.getAttribute("innerHTML"));             
             String opporelementtext=opporelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(opporelementtext.contains("Recent Opportunities"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
          
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }              
             Sprint4_RTB_TC11.captureScreenShot(driver);
             
             Opportunity_NewCreate.typ_opporname(driver).sendKeys(oppname);
             Opportunity_NewCreate.typ_opporacname(driver).sendKeys(accname);
             Opportunity_NewCreate.typ_opporcdate(driver).sendKeys(ocdate);
             Opportunity_NewCreate.sel_opporcuurency(driver).click();
            
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select a=new Select(Opportunity_NewCreate.sel_opporcuurency(driver));
             a.selectByVisibleText(Currency);
             Opportunity_NewCreate.typ_opporonhdate(driver).sendKeys(onhdate);
             //Probability of develop-10//      
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Select b=new Select(Opportunity_NewCreate.sel_opporstage(driver));
             b.selectByVisibleText("Build");
             Opportunity_NewCreate.typ_opporoffhdate(driver).sendKeys(ofhdate);
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
             Opportunity_NewCreate.typ_opporacname(driver).click();
             
             Select e=new Select(Opportunity_NewCreate.sel_opporprdfly(driver));
             e.selectByVisibleText(prodcty);
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Leads_NewCreate.ldsel_prdflyrbt(driver).click();
             
             Select f=new Select(Opportunity_NewCreate.sel_opporldsrc(driver));
             f.selectByVisibleText(oppsource);
             
      	
     		try {
                //System.out.println("Thread Sleep: " + getName());
                Thread.sleep(3000);
            } catch (InterruptedException ex) { }              
            Sprint4_RTB_TC11.captureScreenShot(driver);
	
             
             driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
             Account_NewCreate.fnd_savebtn(driver).click();
             
            
//Check presence of Convert Button//             
             
             try
             {
             if(All_Edit_Clone.fnd_ldconvrt(driver).isDisplayed())
             {
            	 System.out.println("**Error***Convert Button found for Build Stage");    
             }
             }
             catch(Exception e1)
             {
            	 System.out.println("Convert Button Not found");
             }
             
             
                                      
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }              
             Sprint4_RTB_TC11.captureScreenShot(driver);
             
            
             //All_Edit_Clone.fnd_editbtn(driver).click();          
             System.out.println("Sprint4_testcase11 successful-verify SS");
        
             
    }
             public static void captureScreenShot(WebDriver ldriver){        	 
            	  // Take screenshot and store as a file format//
            	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
            	try {
            	  // To copy the  screenshot to desired location using copyFile method	 
            	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_4/Sprint4_TC11/screenshot_"+System.currentTimeMillis()+".png"));
            	       }	 
            	catch (IOException e)	 
            	{	 
            	System.out.println(e.getMessage());	 
            	    }         
              }
             
   
     
     }
     
            