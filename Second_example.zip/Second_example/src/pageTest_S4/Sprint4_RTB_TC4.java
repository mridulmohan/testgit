package pageTest_S4;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Leads_NewCreate;
import pageObjects.HomePage;
import pageObjects.Lead_Convert;
import pageObjects.LoginPage;
import pageObjects.All_Edit_Clone;

 
     public class Sprint4_RTB_TC4{
    	
    	 /*@AfterTest
    	 public void tearDown() throws Exception { 
    	   driver.close();
    	   driver.quit();
    	     } */
    	 
         private static WebDriver driver = null;        
         
         
    @Test(enabled=true)
       public void testcase4() throws Exception{

//Sprint 4 Generic System Feature	AG-328	Add 'Aggreko Location' pick-list to Lead
//Sprint4_RTB_TC4-With non-Aberdeen location-Convert Lead to Opportunity
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_4.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(2).getCell(1,0).getContents();
   	 String username=wb.getSheet(2).getCell(1,1).getContents();
   	 String password=wb.getSheet(2).getCell(1,2).getContents();
   	 String ldtitle=wb.getSheet(2).getCell(1,3).getContents();
     String ldfname=wb.getSheet(2).getCell(1,4).getContents();     	 
   	 String ldlname=wb.getSheet(2).getCell(1,5).getContents();   	 
   	 String ldsrc=wb.getSheet(2).getCell(1,6).getContents();
   	 String ldcmpny=wb.getSheet(2).getCell(1,7).getContents();
   	 String ldaic=wb.getSheet(2).getCell(1,8).getContents();   	   	 
   	 String ldmobno=wb.getSheet(2).getCell(1,9).getContents();
   	 String ldphno=wb.getSheet(2).getCell(1,10).getContents(); 
   	 String ldaggloc=wb.getSheet(2).getCell(1,11).getContents();
   	String opptype=wb.getSheet(2).getCell(1,12).getContents();
  
 //-------------------------------------------------------------------------------------------------------------------------// 
    	
    	
    	
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 							//User Name
        LoginPage.txtbx_Password(driver).sendKeys(password);        					//Password
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint4_RTB_TC4.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }    
        HomePage.clk_Leads(driver).click(); 
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint4_RTB_TC4.captureScreenShot(driver);
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement leadelement=AccountsPage.fnd_recentleads(driver);
            System.out.println("The text "+ leadelement.getAttribute("innerHTML"));             
             String leadelementtext=leadelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(leadelementtext.contains("Recent Leads"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint4_RTB_TC4.captureScreenShot(driver);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.sel_fnameddwn(driver).sendKeys(ldtitle);
             Leads_NewCreate.typ_leadfname(driver).sendKeys(ldfname);    		//Lead First name  //     
             Leads_NewCreate.typ_leadlname(driver).sendKeys(ldlname);    		//Lead last name	//
         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Select a=new Select( Leads_NewCreate.sel_leadstatus(driver));
             a.selectByVisibleText("Qualified");									//Lead status
             
             Leads_NewCreate.typ_leadphone(driver).sendKeys(ldphno); 
             Leads_NewCreate.typ_leadmobno(driver).sendKeys(ldmobno);
             
             Select b=new Select(Leads_NewCreate.sel_leadaic(driver));
             b.selectByVisibleText(ldaic);											//Lead AIC//
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Select n=new Select( Leads_NewCreate.sel_leadsource(driver));
             n.selectByVisibleText(ldsrc);											//Lead Source//
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.typ_leadncmpny(driver).sendKeys(ldcmpny); 
             
             Select c=new Select( Leads_NewCreate.sel_ldaggloc(driver));			//Aggreko Location
             c.selectByVisibleText(ldaggloc);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint4_RTB_TC4.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }   
             WebElement x=Account_NewCreate.fnd_savebtn(driver);
             x.click();
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint4_RTB_TC4.captureScreenShot(driver);
             
             System.out.println("Lead creation successful..Converting to opportunity..Please wait..");
          
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint4_RTB_TC4.captureScreenShot(driver);
       
//*****************Converting to Opportunity********************//
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }  
              All_Edit_Clone.fnd_ldconvrt(driver).click();
              
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint4_RTB_TC4.captureScreenShot(driver);
           
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Lead_Convert.typ_actytyp(driver).sendKeys(opptype);
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  
             WebElement g=Lead_Convert.clk_ldcnrtbtn(driver);
             g.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  
             Sprint4_RTB_TC4.captureScreenShot(driver);
 
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             WebElement k=Lead_Convert.clk_ldcnrtbtn(driver);
             k.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { }  
            Sprint4_RTB_TC4.captureScreenShot(driver);
           
             System.out.println("S4_Testcase4_pass..Pleaseverify SS...");
             
    }
    
    
    public static void captureScreenShot(WebDriver ldriver){        	 
   	  // Take screenshot and store as a file format//
   	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
   	try {
   	  // To copy the  screenshot to desired location using copyFile method	 
   	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_4/Sprint4_TC4/screenshot_"+System.currentTimeMillis()+".png"));
   	       }	 
   	catch (IOException e)	 
   	{	 
   	System.out.println(e.getMessage());	 
   	    }         
     }
    
     }