package pageTest_S4;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.JavascriptExecutor;

  // Import package pageObject//     
import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Contacts_NewCreate;
import pageObjects.Leads_NewCreate;
import pageObjects.HomePage; 
import pageObjects.LoginPage;
import pageTest.Sprint1_RTB_TC2;
import pageTest.Sprint1_RTB_TC3;


     public class Sprint4_RTB_TC17{
    	 
         private static WebDriver driver = null;        
         
         @AfterTest
    	 public void tearDown() throws Exception { 
    		 driver.close();
    	   driver.quit();
    	     }  
    	     
    @Test(enabled=true)
       public void testcase17() throws Exception{
    	
//Sprint 4 Generic System Featur	AG-105	Generic System Features: Warn user of (potential) existing duplicate record
//Sprint4_RTB_TC16-Leads duplicate-Fuzzy logic
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_4.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(15).getCell(1,0).getContents();
   	 String username=wb.getSheet(15).getCell(1,1).getContents();
   	 String password=wb.getSheet(15).getCell(1,2).getContents();
   	 String ldtitle=wb.getSheet(15).getCell(1,3).getContents();
     String ldfname=wb.getSheet(15).getCell(1,4).getContents();     	 
   	 String ldlname=wb.getSheet(15).getCell(1,5).getContents();   	 
   	 String ldsrc=wb.getSheet(15).getCell(1,6).getContents();
   	 String ldcmpny=wb.getSheet(15).getCell(1,7).getContents();   	 
   	 String ldmob=wb.getSheet(15).getCell(1,8).getContents();
   	 String ldmail=wb.getSheet(15).getCell(1,9).getContents();
   	 String ldphno=wb.getSheet(15).getCell(1,10).getContents();
   	 String ldweb=wb.getSheet(15).getCell(1,11).getContents();
   	 String ldst=wb.getSheet(15).getCell(1,12).getContents();
   	 String ldcity=wb.getSheet(15).getCell(1,13).getContents();
   	 String ldstate=wb.getSheet(15).getCell(1,14).getContents();
   	 String ldzip=wb.getSheet(15).getCell(1,15).getContents();
   	 String ldctry=wb.getSheet(15).getCell(1,16).getContents();
 
 //-------------------------------------------------------------------------------------------------------------------------//       	
    	
    	
    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
           //HomePage.lnk_MyAccount(driver).click(); 
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint4_RTB_TC17.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { } 
        HomePage.clk_Leads(driver).click();  
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint4_RTB_TC17.captureScreenShot(driver);
                    
            
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
            WebElement leadelement=AccountsPage.fnd_recentleads(driver);
            System.out.println("The text "+ leadelement.getAttribute("innerHTML"));             
             String leadelementtext=leadelement.getAttribute("innerHTML");         
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
             if(leadelementtext.contains("Recent Leads"))
             {
            	AccountsPage.clk_nwbtn(driver).click();
             }
       
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint4_RTB_TC17.captureScreenShot(driver);
             
             Leads_NewCreate.sel_fnameddwn(driver).sendKeys(ldtitle);
             Leads_NewCreate.typ_leadfname(driver).sendKeys(ldfname);           
             Leads_NewCreate.typ_leadlname(driver).sendKeys(ldlname);
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Select m=new Select(Leads_NewCreate.sel_leadstatus(driver));
             m.selectByVisibleText("Open");   
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Select n=new Select( Leads_NewCreate.sel_leadsource(driver));
             n.selectByVisibleText(ldsrc); 
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Leads_NewCreate.typ_leadncmpny(driver).sendKeys(ldcmpny);
             
             Select p=new Select(Leads_NewCreate.typ_leadtype(driver));
             p.selectByVisibleText("Tender");
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint4_RTB_TC17.captureScreenShot(driver);
             
//Non Mandatory fields//
             Leads_NewCreate.typ_leadmobno(driver).sendKeys(ldmob);
             Leads_NewCreate.typ_leademail(driver).sendKeys(ldmail);
             Leads_NewCreate.typ_leadphone(driver).sendKeys(ldphno);
             Leads_NewCreate.typ_leadwebsite(driver).sendKeys(ldweb);
            Leads_NewCreate.typ_leadstreet(driver).sendKeys(ldst);
             Leads_NewCreate.typ_leadcty(driver).sendKeys(ldcity);
             Leads_NewCreate.typ_leadstate(driver).sendKeys(ldstate);
             Leads_NewCreate. typ_leadpcode(driver).sendKeys(ldzip);
             Leads_NewCreate. typ_leadctry(driver).sendKeys(ldctry);	
            
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
             Sprint4_RTB_TC17.captureScreenShot(driver); 
                        
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 
             WebElement x=Account_NewCreate.fnd_savebtn(driver);
             x.click();
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 
             Sprint4_RTB_TC17.captureScreenShot(driver);
             
//Second Lead Creation//
                      
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 
             HomePage.clk_Leads(driver).click();  
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint4_RTB_TC17.captureScreenShot(driver);
                         
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 
                 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);             
                 WebElement lead1element=AccountsPage.fnd_recentleads(driver);
                 System.out.println("The text "+ lead1element.getAttribute("innerHTML"));             
                  String lead1elementtext=lead1element.getAttribute("innerHTML");         
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);              
                  if(lead1elementtext.contains("Recent Leads"))
                  {
                 	AccountsPage.clk_nwbtn(driver).click();
                  }
            
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                  Sprint4_RTB_TC17.captureScreenShot(driver);
                  
                  Leads_NewCreate.sel_fnameddwn(driver).sendKeys(ldtitle);
                  Leads_NewCreate.typ_leadfname(driver).sendKeys(ldfname);           
                  Leads_NewCreate.typ_leadlname(driver).sendKeys(ldlname);
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                  Select m1=new Select(Leads_NewCreate.sel_leadstatus(driver));
                  m1.selectByVisibleText("Open");             
                  
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                  Select n1=new Select( Leads_NewCreate.sel_leadsource(driver));
                  n1.selectByVisibleText(ldsrc); 
                  
                 
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                  Leads_NewCreate.typ_leadncmpny(driver).sendKeys(ldcmpny);
                  
                  Select p1=new Select(Leads_NewCreate.typ_leadtype(driver));
                  p1.selectByVisibleText("Tender");
                  
                  
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                  Sprint4_RTB_TC17.captureScreenShot(driver);
                  
                  //Non Mandatory fields//
                  Leads_NewCreate.typ_leadmobno(driver).sendKeys(ldmob);
                  Leads_NewCreate.typ_leademail(driver).sendKeys(ldmail);
                  Leads_NewCreate.typ_leadphone(driver).sendKeys(ldphno);
                  Leads_NewCreate.typ_leadwebsite(driver).sendKeys(ldweb);
                  
                
                 Leads_NewCreate.typ_leadstreet(driver).sendKeys(ldst);
                  Leads_NewCreate.typ_leadcty(driver).sendKeys(ldcity);
                  Leads_NewCreate.typ_leadstate(driver).sendKeys(ldstate);
                  Leads_NewCreate. typ_leadpcode(driver).sendKeys(ldzip);
                  Leads_NewCreate. typ_leadctry(driver).sendKeys(ldctry);	
                 
                  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
                  Sprint4_RTB_TC17.captureScreenShot(driver); 
                             
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { } 
                  WebElement x1=Account_NewCreate.fnd_savebtn(driver);
                  x1.click();
                  
                  try {
                      //System.out.println("Thread Sleep: " + getName());
                      Thread.sleep(5000);
                  } catch (InterruptedException ex) { } 
                  Sprint4_RTB_TC17.captureScreenShot(driver);
                  
                  System.out.println("Duplicate lead creation...");
                  System.out.println("Sprint4_Test Case 17 successfull..Please verify SS");
                  
    	
    } 
    
    public static void captureScreenShot(WebDriver ldriver){        	 
     	  // Take screenshot and store as a file format//
     	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
     	try {
     	  // To copy the  screenshot to desired location using copyFile method	 
     	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_4/Sprint4_TC17/screenshot_"+System.currentTimeMillis()+".png"));
     	       }	 
     	catch (IOException e)	 
     	{	 
     	System.out.println(e.getMessage());	 
     	    }    
    }
     }
            