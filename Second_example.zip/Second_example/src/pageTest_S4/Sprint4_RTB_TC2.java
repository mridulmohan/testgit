package pageTest_S4;
 
import java.util.concurrent.TimeUnit; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import jxl.Workbook;

import java.io.File;
import java.io.IOException;     
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;    
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import java.util.ArrayList;

// Import package pageObject//     

import pageObjects.Account_NewCreate;
import pageObjects.AccountsPage;
import pageObjects.Calendar_event;
import pageObjects.HomePage;
import pageObjects.Leads_NewCreate;
import pageObjects.LoginPage;
import pageObjects.Opportunity_NewCreate;
import pageObjects.SalesPlan_Account;
import pageObjects.Sales_Plan_New;
import pageObjects.Sales_Target_New;
import pageObjects.All_Edit_Clone;
import pageObjects.Projects_New;
import pageObjects.Sales_Plan_Postcreation;
import pageObjects.Sales_Territory_New;


 
     public class Sprint4_RTB_TC2 {
    	 
    	/* @AfterTest
    	 public void tearDown() throws Exception { 
    		 
    		 try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(3000);
             } catch (InterruptedException ex) { } 
    		driver.close(); 
    	    driver.quit();
    	     }    */ 	 
    	
         private static WebDriver driver = null;
    @Test(enabled=true)
       public void testcase2() throws Exception {
    	
//Sprint 4 TC2	
//Sprint 4 Generic System Feature	AG-344	Mark for Delete � substory of Mark Accounts/Leads/Opportunities/Projects for Delete 
    	
//-------------------------------------------------------------------------------------------------------------------------//
    	
    	File src=new File("D:/AGGREKKO/Parameterisation Sheet/Data_4.xls");
   	 System.out.println("Excel located..");        	 
   	 Workbook wb=Workbook.getWorkbook(src);        	 
   	 System.out.println("Excel loaded..");
   	 String url=wb.getSheet(0).getCell(1,0).getContents();
   	 String username=wb.getSheet(0).getCell(1,1).getContents();
   	 String password=wb.getSheet(0).getCell(1,2).getContents();
   	 String leadname=wb.getSheet(0).getCell(1,3).getContents();
     String opporname=wb.getSheet(0).getCell(1,4).getContents();  
     String accountname=wb.getSheet(0).getCell(1,5).getContents();     
     String projname=wb.getSheet(0).getCell(1,6).getContents();     
     String ldrsn=wb.getSheet(0).getCell(1,7).getContents();
     String opprsn=wb.getSheet(0).getCell(1,8).getContents();     
     String accrsn=wb.getSheet(0).getCell(1,9).getContents();
     String projrsn=wb.getSheet(0).getCell(1,10).getContents();
     
 
//-------------------------------------------------------------------------------------------------------------------------//    
   	

    	System.setProperty("webdriver.gecko.driver","D://Selenium WebDriver//geckodriver.exe");
    	driver = new FirefoxDriver(); 
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        LoginPage.txtbx_UserName(driver).sendKeys(username); 
        LoginPage.txtbx_Password(driver).sendKeys(password);        
        LoginPage.btn_LogIn(driver).click();
        
                
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(2000);
        } catch (InterruptedException ex) { }  
        Sprint4_RTB_TC1.captureScreenShot(driver);
        
  //********************************************************************************************************//
 

      //Search and Update lead//
        
      //To search and click-Leads-Use Display name//     
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }   
        HomePage.clk_Leads(driver).click();  
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { }  
        HomePage.clk_sfsearch(driver).click();
        HomePage.clk_sfsearch(driver).sendKeys(leadname);
        
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Sprint4_RTB_TC2.captureScreenShot(driver);
  
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(2000);
        } catch (InterruptedException ex) { } 
        WebElement k=HomePage.clk_sfsearchbtn(driver);
        k.click();
        
 
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(2000);
        } catch (InterruptedException ex) { } 
        Sprint4_RTB_TC2.captureScreenShot(driver);
        
        try {
            //System.out.println("Thread Sleep: " + getName());
            Thread.sleep(5000);
        } catch (InterruptedException ex) { } 

        
               
        int Row_count = driver.findElements(By.xpath("//*[@id='Lead_body']/table/tbody/tr")).size();
        System.out.println("Number Of Rows = "+Row_count);
        
        		String  xpath_first="//*[@id='Lead_body']/table/tbody/tr[";        
        		String xpath_last="]/th/a";

        		for (int i=2; i<=Row_count; i++)
        		{

        		String LEADNAME=driver.findElement(By.xpath(xpath_first+i+xpath_last)).getText();
        				if(LEADNAME.equalsIgnoreCase(leadname)){
        					System.out.println("Lead Seacrh Successful....");
        					WebElement m=driver.findElement(By.xpath(xpath_first+i+xpath_last));
        					m.click();   
        					
        					try {
        	                    //System.out.println("Thread Sleep: " + getName());
        	                    Thread.sleep(5000);
        	                } catch (InterruptedException ex) { }  
        	                All_Edit_Clone.fnd_editbtn(driver).click();
        	                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
        	                
        	                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        	                Sprint4_RTB_TC2.captureScreenShot(driver);
        	                
        	                //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); 
        	                //Select h=new Select(Leads_NewCreate.sel_leadstatus(driver));
        	                //h.selectByVisibleText("Qualified");
        	                
        	                WebElement v=Leads_NewCreate.clk_ldmkdel(driver);
        	                v.click();
        	                
        	                Leads_NewCreate.typ_ldmkdelrsn(driver).sendKeys(ldrsn);
        	                
        	                try {
        	                    //System.out.println("Thread Sleep: " + getName());
        	                    Thread.sleep(5000);
        	                } catch (InterruptedException ex) { }   
        	                WebElement y=Account_NewCreate.fnd_savebtn(driver);
        	                y.click();  
        	                
        	                try {
        	                    //System.out.println("Thread Sleep: " + getName());
        	                    Thread.sleep(5000);
        	                } catch (InterruptedException ex) { }  
        	                
        	                ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
        	                Sprint4_RTB_TC2.captureScreenShot(driver);
        					
        					
        				}else{
        					System.out.println("Lead not found..");
        				}
        		}
       		
                
 //************************************************************************************************************//       		
//Search and update Opportunity//
                
                
                try {
                    //System.out.println("Thread Sleep: " + getName());
                    Thread.sleep(5000);
                } catch (InterruptedException ex) { }  
                HomePage.clk_sfsearch(driver).click();
                HomePage.clk_sfsearch(driver).sendKeys(opporname);
                
                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                Sprint4_RTB_TC2.captureScreenShot(driver);
          
                
                try {
                    //System.out.println("Thread Sleep: " + getName());
                    Thread.sleep(2000);
                } catch (InterruptedException ex) { } 
                WebElement k1=HomePage.clk_sfsearchbtn(driver);
                k1.click();
                
         
                try {
                    //System.out.println("Thread Sleep: " + getName());
                    Thread.sleep(2000);
                } catch (InterruptedException ex) { } 
                Sprint4_RTB_TC2.captureScreenShot(driver);
                
                try {
                    //System.out.println("Thread Sleep: " + getName());
                    Thread.sleep(5000);
                } catch (InterruptedException ex) { } 

                
                       
                int Row_count1 = driver.findElements(By.xpath(".//*[@id='Opportunity_body']/table/tbody/tr")).size();
                System.out.println("Number Of Rows = "+Row_count1);
                
                		String  xpath_first1=".//*[@id='Opportunity_body']/table/tbody/tr[";        
                		String xpath_last1="]/th/a";

                		for (int i=2; i<=Row_count1; i++)
                		{

                		String OPPORNAME=driver.findElement(By.xpath(xpath_first1+i+xpath_last1)).getText();
                				if(OPPORNAME.equalsIgnoreCase(opporname)){
                					System.out.println("Opportunity found successfully...");
                					WebElement m=driver.findElement(By.xpath(xpath_first1+i+xpath_last1));
                					m.click();    
                					
                					
                					try {
                                        //System.out.println("Thread Sleep: " + getName());
                                        Thread.sleep(5000);
                                    } catch (InterruptedException ex) { }  
                                    All_Edit_Clone.fnd_editbtn(driver).click();
                                    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
                                    
                                    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                                    Sprint4_RTB_TC2.captureScreenShot(driver);
                                    
                                    try {
                                        //System.out.println("Thread Sleep: " + getName());
                                        Thread.sleep(5000);
                                    } catch (InterruptedException ex) { }
                                    
                                    WebElement k2=Opportunity_NewCreate.clk_oppmkdel(driver);
                                    k2.click();
                                    
                                    try {
                                        //System.out.println("Thread Sleep: " + getName());
                                        Thread.sleep(2000);
                                    } catch (InterruptedException ex) { }
                                    Opportunity_NewCreate.typ_oppmkdlreason(driver).sendKeys(opprsn);
                                    
                                    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                                    Sprint4_RTB_TC2.captureScreenShot(driver);
                                    
                                    WebElement k3=Account_NewCreate.fnd_savebtn(driver);
                                    k3.click();
                    
                                    try {
                                        //System.out.println("Thread Sleep: " + getName());
                                        Thread.sleep(5000);
                                    } catch (InterruptedException ex) { } 
                                    
                                    ((JavascriptExecutor)driver).executeScript("scroll(0,400)");
                                    Sprint4_RTB_TC2.captureScreenShot(driver);
                                    
                					
                				}else{
                					System.out.println("Opportunity not found...");
                				}
                		}
                		
                		
                        
//__________-----------------------_______________________-------------------------________________________//       		
 //Search and update Account//
     
      try {
          //System.out.println("Thread Sleep: " + getName());
          Thread.sleep(5000);
      } catch (InterruptedException ex) { }  
      HomePage.clk_sfsearch(driver).click();
      HomePage.clk_sfsearch(driver).sendKeys(accountname);
      
      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
      Sprint4_RTB_TC2.captureScreenShot(driver);

      
      try {
          //System.out.println("Thread Sleep: " + getName());
          Thread.sleep(2000);
      } catch (InterruptedException ex) { } 
      WebElement k8=HomePage.clk_sfsearchbtn(driver);
      k8.click();
      

      try {
          //System.out.println("Thread Sleep: " + getName());
          Thread.sleep(2000);
      } catch (InterruptedException ex) { } 
      Sprint4_RTB_TC2.captureScreenShot(driver);
      
      try {
          //System.out.println("Thread Sleep: " + getName());
          Thread.sleep(5000);
      } catch (InterruptedException ex) { } 

      
             
      int Row_count2 = driver.findElements(By.xpath(".//*[@id='Account_body']/table/tbody/tr")).size();
      System.out.println("Number Of Rows = "+Row_count2);
      
      		String  xpath_first2=".//*[@id='Account_body']/table/tbody/tr[";        
      		String xpath_last2="]/th/a";

      		for (int i=2; i<=Row_count2; i++)
      		{

      		String ACCOUNTNAME=driver.findElement(By.xpath(xpath_first2+i+xpath_last2)).getText();
      				if(ACCOUNTNAME.equalsIgnoreCase(accountname)){
      					System.out.println("Account found successfully...");
      					WebElement m=driver.findElement(By.xpath(xpath_first2+i+xpath_last2));
      					m.click(); 
      					
      					try {
      	                  //System.out.println("Thread Sleep: " + getName());
      	                  Thread.sleep(5000);
      	              } catch (InterruptedException ex) { }  
      	              All_Edit_Clone.fnd_editbtn(driver).click();
      	              driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
      	              
      	              driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
      	              Sprint4_RTB_TC2.captureScreenShot(driver);
      	              
      	              try {
      	                  //System.out.println("Thread Sleep: " + getName());
      	                  Thread.sleep(5000);
      	              } catch (InterruptedException ex) { }
      	              
      	              WebElement k9=Account_NewCreate.clk_accmkdel(driver);
      	              k9.click();
      	              
      	              try {
      	                  //System.out.println("Thread Sleep: " + getName());
      	                  Thread.sleep(2000);
      	              } catch (InterruptedException ex) { }
      	              Account_NewCreate.typ_accmkdlreason(driver).sendKeys(accrsn);
      	              
      	              driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
      	              Sprint4_RTB_TC2.captureScreenShot(driver);
      	              
      	              WebElement k4=Account_NewCreate.fnd_savebtn(driver);
      	              k4.click();
      	              
      	              try {
      	                  //System.out.println("Thread Sleep: " + getName());
      	                  Thread.sleep(5000);
      	              } catch (InterruptedException ex) { }
      	              
      	              ((JavascriptExecutor)driver).executeScript("scroll(0,400)");

      	             Sprint4_RTB_TC2.captureScreenShot(driver);
      					
      					
      				}else{
      					System.out.println("Account not found...");
      				}
      		}
      		
      		
              
   
        
//*****************************Search and update Project*********************************// 
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { }
             
             HomePage.clk_sfsearch(driver).click();
             HomePage.clk_sfsearch(driver).sendKeys(projname);
             
             driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
             Sprint4_RTB_TC2.captureScreenShot(driver);

             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { } 
             WebElement k5=HomePage.clk_sfsearchbtn(driver);
             k5.click();
             

             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(2000);
             } catch (InterruptedException ex) { } 
             Sprint4_RTB_TC2.captureScreenShot(driver);
             
             try {
                 //System.out.println("Thread Sleep: " + getName());
                 Thread.sleep(5000);
             } catch (InterruptedException ex) { } 

             
                    
             int Row_count3 = driver.findElements(By.xpath(".//*[@id='CAP_AG_Project__c_body']/table/tbody/tr")).size();
             System.out.println("Number Of Rows = "+Row_count3);
             
             		String  xpath_first3=".//*[@id='CAP_AG_Project__c_body']/table/tbody/tr[";        
             		String xpath_last3="]/th/a";

             		for (int i=2; i<=Row_count3; i++)
             		{

             		String PROJNAME=driver.findElement(By.xpath(xpath_first3+i+xpath_last3)).getText();
             				if(PROJNAME.equalsIgnoreCase(projname)){
             					System.out.println("Project Seacrh term found");
             					WebElement m=driver.findElement(By.xpath(xpath_first3+i+xpath_last3));
             					m.click();  
             					
             					try {
                                    //System.out.println("Thread Sleep: " + getName());
                                    Thread.sleep(5000);
                                } catch (InterruptedException ex) { }  
                                All_Edit_Clone.fnd_editbtn(driver).click();
                                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); 
                                
                                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                                Sprint4_RTB_TC2.captureScreenShot(driver);
                                
                                try {
                                    //System.out.println("Thread Sleep: " + getName());
                                    Thread.sleep(5000);
                                } catch (InterruptedException ex) { }
                                
                                WebElement k6=Projects_New.clk_promkdel(driver);
                                k6.click();
                                
                                try {
                                    //System.out.println("Thread Sleep: " + getName());
                                    Thread.sleep(2000);
                                } catch (InterruptedException ex) { }
                                Projects_New.typ_promkdelrsn(driver).sendKeys(projrsn);
                                
                                driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
                                Sprint4_RTB_TC2.captureScreenShot(driver);
                                
                                WebElement k7=Account_NewCreate.fnd_savebtn(driver);
                                k7.click();
                                
                                try {
                                    //System.out.println("Thread Sleep: " + getName());
                                    Thread.sleep(5000);
                                } catch (InterruptedException ex) { }
                                
                                ((JavascriptExecutor)driver).executeScript("scroll(0,400)");

                               Sprint4_RTB_TC2.captureScreenShot(driver);
                                
             					             					
             				}else{
             					System.out.println("Project not found..");
             				}
             		}
             		
             		
             			System.out.println("Sprint4_test case_2 Successfull..Please validate screenshots..");
             		
                     
    }
  //Screenshot  
    public static void captureScreenShot(WebDriver ldriver){        	 
  	  // Take screenshot and store as a file format//
  	  File src= ((TakesScreenshot)ldriver).getScreenshotAs(OutputType.FILE);
  	try {
  	  // To copy the  screenshot to desired location using copyFile method	 
  	 FileUtils.copyFile(src, new File("D:/Salesforce_Screenshots/Sprint_4/Sprint4_TC2/screenshot_"+System.currentTimeMillis()+".png"));
  	       }	 
  	catch (IOException e)	 
  	{	 
  	System.out.println(e.getMessage());	 
  	    }         
    }
   


}

  