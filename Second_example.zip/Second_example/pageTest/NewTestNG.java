package pageTest;

import org.testng.annotations.Test;

public class NewTestNG {
  @Test
  public void f() {
  }
}
